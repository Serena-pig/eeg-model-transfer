"""Source empirical-evidence grouped logistic fusion and Laplace posterior averaging.
No outer hyperparameter tuning or base refits. Posterior integration preserves
4of8 group prior. Empirical Bayes estimation is training, not validation scoring.
"""
import os
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='1'
import json,traceback
import numpy as np,joblib
from scipy.special import expit,logit
from scipy.optimize import minimize
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits
import driver
from context_rank_v34 import fit_context,context_features
from inner_calibration_round import calibrate
from common import batches
from postflight import pair_matrix
OUT=driver.JOB/'cached_evidence_logistic_20261030';OUT.mkdir(exist_ok=True)
NAMES=['evidence_MAP','evidence_posterior_group']
def features(bank,groups):
 x=np.clip(logit(np.clip(bank,1e-6,1-1e-6)),-10,10).T;std=np.empty_like(x)
 for group in np.unique(groups):m=groups==group;std[m]=x[m].std(0)
 return np.column_stack([x,std])
def main():
 threadpool_limits(limits=1);p=driver.protocol();spec=dict(variants=NAMES,initial_precision_inherited=100.,automatic_source_evidence_groups=['86scores','86confidences','context_and_clinical_interactions'],evidence_iterations_fixed=8,evidence_log_damping=.5,likelihood_tempering_fixed=.2,posterior_samples_fixed=16,antithetic_sampling=True,conditional_BCE_mix_fixed=.5,base_models_retrained=0,no_outer_parameter_search=True,source_inner_prediction_fit_only=True,script_sha256=driver.sha(__file__))
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==spec
 else:driver.save(OUT/'protocol.json',spec)
 with np.load(driver.ART/'features.npz') as a:d={k:a[k] for k in ['subject','label','diagnosis','trial','crop','train','powers','quality']}
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:full={k:a[k] for k in a.files}
 with np.load(driver.JOB/'dualbranch_source_stack_20261028/clinical_stack_calibrated_oof.npz') as a:anchor=a['probability']
 out={n:anchor.copy() for n in NAMES};out.update({n+'_calibrated':anchor.copy() for n in NAMES});audits=[];baseix=np.r_[np.arange(83),np.arange(104,107)]
 for f in p['folds']:
  with np.load(driver.JOB/f'cached_group_diagnostics_20261030/fold{f["fold"]}_aligned_banks.npz') as a:tr=a['inner_indices'];va=a['outer_indices'];inside=a['inner_probability'][baseix];outside=a['outer_probability'][baseix]
  old=joblib.load(driver.JOB/f'dualbranch_source_stack_20261028/fold{f["fold"]}.joblib');source=dict(d);source['label']=np.full_like(d['label'],-1);source['diagnosis']=np.full_like(d['diagnosis'],-1);source['diagnosis'][tr]=d['diagnosis'][tr];context,e=fit_context(source,tr);x=old['scaler'].transform(np.column_stack([features(inside,batches(d)[tr]),e]));gx=np.column_stack([x,.5*(2*e[:,6]-1)[:,None]*x[:,[83,84,85]]]);blind=dict(d);blind['label']=np.full_like(d['label'],-1);blind['diagnosis']=np.full_like(d['diagnosis'],-1);ev=context_features(blind,va,context);xv=old['scaler'].transform(np.column_stack([features(outside,batches(d)[va]),ev]));gv=np.column_stack([xv,.5*(2*ev[:,6]-1)[:,None]*xv[:,[83,84,85]]]);mode=json.loads((driver.JOB/f'inner_calibration_20261028/fold{f["fold"]}_selection.json').read_text())['chosen'];reference=calibrate(old['models']['clinical_stack'][0].predict_proba(gv)[:,1],batches(d)[va],mode);error=float(abs(reference-anchor[full['model_row_to_full_row'][va]]).max());assert error<1e-9,error
  y=d['label'][tr];diag=d['diagnosis'][tr];w=np.ones(len(tr))
  for v in (0,1):w[diag==v]=len(tr)/(2*np.sum(diag==v))
  wn=w/w.sum();reg=1/(.01*w.sum());start=np.r_[old['models']['clinical_stack'][0].coef_[0],old['models']['clinical_stack'][0].intercept_[0]]
  def objective(theta):
   z=gx@theta[:-1]+theta[-1];err=(expit(z)-y)*wn;return float(np.dot(wn,np.logaddexp(0,z)-y*z)+.5*reg*np.dot(theta[:-1],theta[:-1])),np.r_[gx.T@err+reg*theta[:-1],err.sum()]
  from scipy.special import logsumexp,softmax
  from scipy.linalg import cho_factor,cho_solve
  from select_ensemble import ASSIGNMENTS,postprocess
  X=np.column_stack([gx,np.ones(len(gx))]);XV=np.column_stack([gv,np.ones(len(gv))]);nb=gx.shape[1];blocks=[np.arange(86),np.arange(86,172),np.arange(172,nb)];rr=np.stack([np.flatnonzero(batches(d)[tr]==g) for g in np.unique(batches(d)[tr])]);gw=w[rr].mean(1);gw/=gw.sum();A=ASSIGNMENTS;power=.2;theta=start.copy();alphas=np.full(3,100.);history=[]
  def likelihood(theta,needH=False):
   z=X@theta;pv=expit(z);bce=np.dot(wn,np.logaddexp(0,z)-y*z);zz=z[rr];ss=zz@A.T;posterior=softmax(ss,axis=1);prob=posterior@A;closs=np.dot(gw,(logsumexp(ss,axis=1)-(zz*y[rr]).sum(1))/8);ce=np.zeros(len(y));ce[rr.ravel()]=((prob-y[rr])*gw[:,None]/8).ravel();gradient=.5*wn*(pv-y)+.5*ce;value=.5*bce+.5*closs
   if not needH:return float(value),X.T@gradient
   cov=np.einsum('ga,ai,aj->gij',posterior,A,A,optimize=True)-prob[:,:,None]*prob[:,None,:];hb=X.T@(X*(w*pv*(1-pv))[:,None]);hc=np.einsum('gip,gij,gjq,g->pq',X[rr],cov,X[rr],w[rr].mean(1),optimize=True);H=power*(.5*hb+.5*hc);return (H+H.T)/2
  def precision_vector(alphas):
   v=np.zeros(nb+1)
   for a,block in zip(alphas,blocks):v[block]=a
   v[-1]=1e-8;return v
  for iteration in range(8):
   prec=precision_vector(alphas)
   def obj(t):
    loss,grad=likelihood(t);return power*len(y)*loss+.5*np.dot(prec*t,t),power*len(y)*grad+prec*t
   if f['fold']==1 and iteration==0:
    grad=obj(theta)[1]
    for j in [0,86,nb-1,nb]:
     aa=theta.copy();bb=theta.copy();aa[j]+=1e-6;bb[j]-=1e-6;assert abs((obj(aa)[0]-obj(bb)[0])/2e-6-grad[j])<1e-4
   fit=minimize(obj,theta,jac=True,method='L-BFGS-B',options=dict(maxiter=1000,ftol=1e-12,gtol=1e-6));assert fit.success,fit.message;theta=fit.x;H=likelihood(theta,True);factor=cho_factor(H+np.diag(prec));sigma=cho_solve(factor,np.eye(nb+1));updated=[]
   for a,block in zip(alphas,blocks):
    effective=max(float(np.sum(1-a*np.diag(sigma)[block])),1e-6);v=effective/max(float(np.dot(theta[block],theta[block])),1e-12);updated.append(float(np.clip(v,1e-3,1e6)))
   history.append(dict(iteration=iteration+1,precision=alphas.tolist(),updated=updated));alphas=np.exp(.5*np.log(alphas)+.5*np.log(updated))
  prec=precision_vector(alphas)
  def obj(t):
   loss,grad=likelihood(t);return power*len(y)*loss+.5*np.dot(prec*t,t),power*len(y)*grad+prec*t
  fit=minimize(obj,theta,jac=True,method='L-BFGS-B',options=dict(maxiter=1000,ftol=1e-12,gtol=1e-6));assert fit.success;theta=fit.x;H=likelihood(theta,True);sigma=cho_solve(cho_factor(H+np.diag(prec)),np.eye(nb+1));sigma=(sigma+sigma.T)/2;L=np.linalg.cholesky(sigma);rng=np.random.default_rng(1030+f['fold']);noise=rng.standard_normal((8,nb+1))@L.T;draws=theta[None]+np.vstack([noise,-noise]);artifact=dict(theta=theta,draws=draws,posterior_covariance=sigma,precision=alphas,evidence_history=history,reference_artifact=old,context=context,source_subjects=f['training_subjects'],protocol=spec);path=OUT/f'fold{f["fold"]}.joblib';joblib.dump(artifact,path,compress=3);saved=joblib.load(path);per=np.random.default_rng(f['fold']).permutation(len(va));groups=batches(d)[va]
  def predict(art,xx,group,name):
   if name=='evidence_MAP':return expit(xx@art['theta'])
   return np.mean([postprocess(xx@draw,group,'conditional',1.) for draw in art['draws']],axis=0)
  preds={name:predict(artifact,XV,groups,name) for name in NAMES};replays={name:predict(saved,XV[per],np.char.add('opaque_',groups[per]),name) for name in NAMES}
  for name,q in preds.items():
   delta=float(abs(replays[name]-q[per]).max());assert delta<1e-10;out[name][full['model_row_to_full_row'][va]]=np.round(q,12);out[name+'_calibrated'][full['model_row_to_full_row'][va]]=np.round(q if name=='evidence_posterior_group' else calibrate(q,batches(d)[va],mode),12);audits.append(dict(fold=f['fold'],model=name,anchor_reconstruction_delta=error,native_order_delta=delta))
  print('CACHED EVIDENCE OUTER',f['fold'],'/5',flush=True)
 y=full['label'];g=full['subject'];dep=full['diagnosis']==1;ids=np.unique(g);ref=pair_matrix(y,anchor,g,ids);rng=np.random.default_rng(1030);counts=np.zeros((2000,len(ids)))
 for j in range(len(counts)):
  for mask in [np.char.startswith(ids,'DEP'),np.char.startswith(ids,'HC')]:
   ix=np.flatnonzero(mask);counts[j]+=np.bincount(rng.choice(ix,len(ix),replace=True),minlength=len(ids))
 results={}
 for name,q in out.items():
  delta=pair_matrix(y,q,g,ids)-ref;boot=np.einsum('bi,ij,bj->b',counts,delta,counts,optimize=True)/counts.sum(1)**2;results[name]=dict(pooled_auc=float(roc_auc_score(y,q)),DEP_auc=float(roc_auc_score(y[dep],q[dep])),paired_person_delta_95CI=np.quantile(boot,[.025,.975]).tolist());np.savez_compressed(OUT/(name+'_oof.npz'),labels=y,subjects=g,probability=q)
 driver.save(OUT/'summary.json',dict(results=results,anchor_auc=float(roc_auc_score(y,anchor)),base_models_retrained=0,baseline_preserved=True,cohort_reused=True,multiple_search_uncorrected=True,official_score_unknown=True));driver.save(OUT/'verification.json',dict(checks_passed=True,all5outer_complete=True,source_inner_only_fit=True,audits=audits,calibration_policy_inherited_not_new_nested_meta_search=True,analytic_gradients_verified=True,holdout_and_test_not_read=True,submissions_performed=False));print('CACHED EVIDENCE COMPLETE',json.dumps(results),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException:driver.save(OUT/'failure.json',dict(traceback=traceback.format_exc()));raise
