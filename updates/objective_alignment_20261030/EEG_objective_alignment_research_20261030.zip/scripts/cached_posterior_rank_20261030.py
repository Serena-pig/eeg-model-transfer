"""Three fixed source-only fusion objectives on the exact86-member anchor design.
No outer-selected hyperparameters, no new base training, no proxy weight transfer.
Original source-inner calibration policy inherited, not a new calibration search.
"""
import os
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='1'
import json,traceback
import numpy as np,joblib
from scipy.special import expit,logit
from scipy.optimize import minimize
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits
import driver
from context_rank_v34 import fit_context,context_features
from inner_calibration_round import calibrate
from common import batches
from postflight import pair_matrix
OUT=driver.JOB/'cached_posterior_rank_20261030';OUT.mkdir(exist_ok=True)
NAMES=['conditional_only','posterior_pair_conditional']
def features(bank,groups):
 x=np.clip(logit(np.clip(bank,1e-6,1-1e-6)),-10,10).T;std=np.empty_like(x)
 for group in np.unique(groups):m=groups==group;std[m]=x[m].std(0)
 return np.column_stack([x,std])
def main():
 threadpool_limits(limits=1);p=driver.protocol();spec=dict(variants=NAMES,C_inherited=.01,pair_count_fixed=20000,pair_seed=1030,posterior_pair_conditional_mix_fixed=.5,posterior_temperature_fixed=1.,conditioned_positives_per8_fixed=4,base_models_retrained=0,new_parameters_prespecified_no_outer_search=True,source_inner_prediction_fit_only=True,calibration='Inherited prior policy for matched comparison; conditional control fixed at temperature1',script_sha256=driver.sha(__file__),note='Differentiates exact grouped posterior covariance to optimize global pairwise rank loss after calibration')
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==spec
 else:driver.save(OUT/'protocol.json',spec)
 with np.load(driver.ART/'features.npz') as a:d={k:a[k] for k in ['subject','label','diagnosis','trial','crop','train','powers','quality']}
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:full={k:a[k] for k in a.files}
 with np.load(driver.JOB/'dualbranch_source_stack_20261028/clinical_stack_calibrated_oof.npz') as a:anchor=a['probability']
 out={n:anchor.copy() for n in NAMES};out.update({n+'_calibrated':anchor.copy() for n in NAMES});audits=[];baseix=np.r_[np.arange(83),np.arange(104,107)]
 for f in p['folds']:
  with np.load(driver.JOB/f'cached_group_diagnostics_20261030/fold{f["fold"]}_aligned_banks.npz') as a:tr=a['inner_indices'];va=a['outer_indices'];inside=a['inner_probability'][baseix];outside=a['outer_probability'][baseix]
  old=joblib.load(driver.JOB/f'dualbranch_source_stack_20261028/fold{f["fold"]}.joblib');source=dict(d);source['label']=np.full_like(d['label'],-1);source['diagnosis']=np.full_like(d['diagnosis'],-1);source['diagnosis'][tr]=d['diagnosis'][tr];context,e=fit_context(source,tr);x=old['scaler'].transform(np.column_stack([features(inside,batches(d)[tr]),e]));gx=np.column_stack([x,.5*(2*e[:,6]-1)[:,None]*x[:,[83,84,85]]]);blind=dict(d);blind['label']=np.full_like(d['label'],-1);blind['diagnosis']=np.full_like(d['diagnosis'],-1);ev=context_features(blind,va,context);xv=old['scaler'].transform(np.column_stack([features(outside,batches(d)[va]),ev]));gv=np.column_stack([xv,.5*(2*ev[:,6]-1)[:,None]*xv[:,[83,84,85]]]);mode=json.loads((driver.JOB/f'inner_calibration_20261028/fold{f["fold"]}_selection.json').read_text())['chosen'];reference=calibrate(old['models']['clinical_stack'][0].predict_proba(gv)[:,1],batches(d)[va],mode);error=float(abs(reference-anchor[full['model_row_to_full_row'][va]]).max());assert error<1e-9,error
  y=d['label'][tr];diag=d['diagnosis'][tr];w=np.ones(len(tr))
  for v in (0,1):w[diag==v]=len(tr)/(2*np.sum(diag==v))
  wn=w/w.sum();reg=1/(.01*w.sum());start=np.r_[old['models']['clinical_stack'][0].coef_[0],old['models']['clinical_stack'][0].intercept_[0]]
  def objective(theta):
   z=gx@theta[:-1]+theta[-1];err=(expit(z)-y)*wn;return float(np.dot(wn,np.logaddexp(0,z)-y*z)+.5*reg*np.dot(theta[:-1],theta[:-1])),np.r_[gx.T@err+reg*theta[:-1],err.sum()]
  from scipy.special import logsumexp,softmax
  from select_ensemble import ASSIGNMENTS
  groups=batches(d)[tr];rr=np.stack([np.flatnonzero(groups==g) for g in np.unique(groups)]);assert rr.shape[1]==8 and np.all(y[rr].sum(1)==4);gw=w[rr].mean(1);gw/=gw.sum();A=ASSIGNMENTS
  rng=np.random.default_rng(1030+f['fold']);pos=np.flatnonzero(y==1);neg=np.flatnonzero(y==0);pp=rng.choice(pos,20000,p=w[pos]/w[pos].sum());nn=rng.choice(neg,20000,p=w[neg]/w[neg].sum());models={};fit_audits=[]
  for name in NAMES:
   def obj(theta):
    beta=theta[:-1];z=gx@beta+theta[-1];zz=z[rr];scores=zz@A.T;post=softmax(scores,axis=1);prob=post@A;closs=np.dot(gw,(logsumexp(scores,axis=1)-(zz*y[rr]).sum(1))/8);delta=(prob-y[rr])*gw[:,None]/8;ce=np.zeros(len(y));ce[rr.ravel()]=delta.ravel();loss=closs;gradient=ce
    if name=='posterior_pair_conditional':
     safe=np.clip(prob,1e-8,1-1e-8);lp=np.log(safe)-np.log1p(-safe);flat=np.zeros(len(y));flat[rr.ravel()]=lp.ravel();margin=flat[pp]-flat[nn];ploss=np.logaddexp(0,-margin).mean();e=expit(-margin)/len(pp);gl=np.bincount(pp,weights=-e,minlength=len(y))+np.bincount(nn,weights=e,minlength=len(y));expected=np.einsum('ga,ai,aj->gij',post,A,A,optimize=True);cov=expected-prob[:,:,None]*prob[:,None,:];v=gl[rr]/(safe*(1-safe));v[(prob<=1e-8)|(prob>=1-1e-8)]=0.;gz=np.einsum('gij,gi->gj',cov,v,optimize=True);pe=np.zeros(len(y));pe[rr.ravel()]=gz.ravel();loss=.5*closs+.5*ploss;gradient=.5*ce+.5*pe
    gb=gx.T@gradient;gi=gradient.sum();return float(loss+.5*reg*np.dot(beta,beta)),np.r_[gb+reg*beta,gi]
   if f['fold']==1:
    grad=obj(start)[1]
    for j in (0,len(start)//2,len(start)-1):
     aa=start.copy();bb=start.copy();aa[j]+=1e-6;bb[j]-=1e-6;delta=abs((obj(aa)[0]-obj(bb)[0])/2e-6-grad[j]);assert delta<1e-5,(name,j,delta)
   fit=minimize(obj,start,jac=True,method='L-BFGS-B',options=dict(maxiter=1000,ftol=1e-12,gtol=1e-7));assert fit.success,(name,fit.message);models[name]=fit.x;fit_audits.append(dict(name=name,optimizer_success=True,iterations=int(fit.nit)))
  artifact=dict(models=models,reference_artifact=old,context=context,source_subjects=f['training_subjects'],protocol=spec);path=OUT/f'fold{f["fold"]}.joblib';joblib.dump(artifact,path,compress=3);saved=joblib.load(path);per=np.random.default_rng(f['fold']).permutation(len(va));preds={name:expit(gv@theta[:-1]+theta[-1]) for name,theta in models.items()};replays={name:expit(gv[per]@theta[:-1]+theta[-1]) for name,theta in saved['models'].items()}
  for name,q in preds.items():
   delta=float(abs(replays[name]-q[per]).max());assert delta<1e-10;out[name][full['model_row_to_full_row'][va]]=np.round(q,12);out[name+'_calibrated'][full['model_row_to_full_row'][va]]=np.round(calibrate(q,batches(d)[va],mode),12);audits.append(dict(fold=f['fold'],model=name,anchor_reconstruction_delta=error,native_order_delta=delta))
  print('CACHED POSTERIOR RANK OUTER',f['fold'],'/5',flush=True)
 y=full['label'];g=full['subject'];dep=full['diagnosis']==1;ids=np.unique(g);ref=pair_matrix(y,anchor,g,ids);rng=np.random.default_rng(1030);counts=np.zeros((2000,len(ids)))
 for j in range(len(counts)):
  for mask in [np.char.startswith(ids,'DEP'),np.char.startswith(ids,'HC')]:
   ix=np.flatnonzero(mask);counts[j]+=np.bincount(rng.choice(ix,len(ix),replace=True),minlength=len(ids))
 results={}
 for name,q in out.items():
  delta=pair_matrix(y,q,g,ids)-ref;boot=np.einsum('bi,ij,bj->b',counts,delta,counts,optimize=True)/counts.sum(1)**2;results[name]=dict(pooled_auc=float(roc_auc_score(y,q)),DEP_auc=float(roc_auc_score(y[dep],q[dep])),paired_person_delta_95CI=np.quantile(boot,[.025,.975]).tolist());np.savez_compressed(OUT/(name+'_oof.npz'),labels=y,subjects=g,probability=q)
 driver.save(OUT/'summary.json',dict(results=results,anchor_auc=float(roc_auc_score(y,anchor)),base_models_retrained=0,baseline_preserved=True,cohort_reused=True,multiple_search_uncorrected=True,official_score_unknown=True));driver.save(OUT/'verification.json',dict(checks_passed=True,all5outer_complete=True,source_inner_only_fit=True,audits=audits,calibration_policy_inherited_not_new_nested_meta_search=True,analytic_gradients_verified=True,holdout_and_test_not_read=True,submissions_performed=False));print('CACHED POSTERIOR RANK COMPLETE',json.dumps(results),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException:driver.save(OUT/'failure.json',dict(traceback=traceback.format_exc()));raise
