"""Group-of8 unlabeled Euclidean covariance alignment + matrix log features.
Source59 only; grouping exactly matches8x10s queries. No clinical/label inputs.
Inspired by He&Hu/Wu EA (arxiv1808.05464); independent filter-bank implementation.
"""
import os
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='1'
import json,time
import numpy as np
from scipy.signal import butter,sosfiltfilt
from threadpoolctl import threadpool_limits
import driver
OUT=driver.JOB/'regional_covariance_20261030';OUT.mkdir(exist_ok=True)
BANDS=[(1,4),(4,8),(8,13),(13,20),(20,30),(30,45)]
REGIONS=[[0,2,3],[4,9],[1,5,6],[7,8,12,13],[14,19],[10,11,15,16],[17,18,22,23,27],[24,28],[20,21,25,26,29]]
assert sorted(sum(REGIONS,[]))==list(range(30))
I,J=np.triu_indices(9);SCALE=np.where(I==J,1.,np.sqrt(2.))
def extract(x):
 assert x.shape==(8,30,1250) and np.isfinite(x).all();x=np.stack([x[:,ix].mean(1) for ix in REGIONS],axis=1);full=[];diag=[]
 for lo,hi in BANDS:
  v=sosfiltfilt(butter(4,[lo,hi],fs=125,btype='bandpass',output='sos'),x.astype('float64'),axis=-1);v-=v.mean(-1,keepdims=True);c=np.einsum('bit,bjt->bij',v,v,optimize=True)/(v.shape[-1]-1);trace=np.trace(c,axis1=1,axis2=2)/9;c=.95*c+.05*np.maximum(trace,1e-12)[:,None,None]*np.eye(9);ref=c.mean(0);w,u=np.linalg.eigh(ref);assert w.min()>0;wh=(u*(1/np.sqrt(w))[None])@u.T;aligned=np.einsum('ij,bjk,kl->bil',wh,c,wh,optimize=True);aligned=(aligned+aligned.transpose(0,2,1))/2;wv,uv=np.linalg.eigh(aligned);assert wv.min()>0;logs=np.einsum('bij,bj,bkj->bik',uv,np.log(wv),uv,optimize=True);full.append(logs[:,I,J]*SCALE);diag.append(np.log(np.maximum(np.diagonal(aligned,axis1=1,axis2=2),1e-12)))
 return np.column_stack(full).astype('float32'),np.column_stack(diag).astype('float32')
def main():
 threadpool_limits(limits=1);spec=dict(regions=REGIONS,regions_cover30channels_exactly_once=True,bands=BANDS,shrinkage=.05,group='One subject and one crop:8recordings,10s each',source_data_only=True,labels_not_used=True,alignment='Arithmetic covariance mean whitening, matrix log at identity',paper='https://arxiv.org/abs/1808.05464',script_sha256=driver.sha(__file__),raw_sha256=driver.sha(driver.ART/'raw_125hz.npy'))
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==spec
 else:driver.save(OUT/'protocol.json',spec)
 with np.load(driver.ART/'features.npz') as a:d={k:a[k] for k in ['subject','trial','crop']}
 raw=np.load(driver.ART/'raw_125hz.npy',mmap_mode='r');groups=np.char.add(np.char.add(d['subject'],':'),d['crop'].astype(str));names=np.unique(groups);full=np.zeros((len(groups),270),dtype='float32');diag=np.zeros((len(groups),54),dtype='float32');audits=[]
 for j,g in enumerate(names):
  ix=np.flatnonzero(groups==g);assert len(ix)==8 and len(np.unique(d['trial'][ix]))==8;path=OUT/(str(j).zfill(3)+'.npz')
  if path.exists():
   with np.load(path) as a:assert np.array_equal(a['indices'],ix);f=a['matrix_log'];v=a['diagonal']
  else:
   f,v=extract(raw[ix]);np.savez_compressed(path,indices=ix,matrix_log=f,diagonal=v)
  full[ix]=f;diag[ix]=v
  if j==0:
   perm=np.array([4,0,7,1,3,2,6,5]);fp,dp=extract(raw[ix][perm]);fa,da=extract(raw[ix]*3);pe=float(abs(fp-f[perm]).max());se=float(abs(fa-f).max());assert pe<1e-5 and se<1e-5,(pe,se);audits.append(dict(real_group=g,permutation_delta=pe,global_amplitude_gain3_delta=se))
  if (j+1)%20==0:driver.save(OUT/'progress.json',dict(groups_completed=j+1,total_groups=len(names)));print('REGIONAL COVARIANCE',j+1,'/',len(names),flush=True)
 assert np.isfinite(full).all() and np.isfinite(diag).all();np.savez_compressed(OUT/'features.npz',matrix_log=full,diagonal=diag,**d);driver.save(OUT/'verification.json',dict(checks_passed=True,source_people=59,source_windows=2360,query_groups_exact8=True,permutation_scale_audits=audits,no_labels_or_diagnosis_used=True,official_and_holdout_not_read=True));print('REGIONAL COVARIANCE COMPLETE',full.shape,flush=True)
if __name__=='__main__':main()
