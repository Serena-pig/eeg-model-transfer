"""Reconstruct source-only SPD matrices from stored symmetric matrix-log features."""
import os
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[key]='1'
import numpy as np,json
from threadpoolctl import threadpool_limits
import driver

def main():
 threadpool_limits(limits=1);out=driver.JOB/'csp_covariance_features_20261030';out.mkdir(exist_ok=True);values={};reference=None;audits=[]
 for view,name,n in [('full30','aligned_covariance_20261030',30),('regional9','regional_covariance_20261030',9)]:
  with np.load(driver.JOB/name/'features.npz') as a:x=a['matrix_log'];meta={k:a[k] for k in ['subject','trial','crop']}
  if reference is None:reference=meta
  else:
   for k in meta:assert np.array_equal(meta[k],reference[k])
  ii,jj=np.triu_indices(n);scale=np.where(ii==jj,1.,np.sqrt(2.));x=x.reshape(len(x),6,len(ii))/scale;log=np.zeros((len(x),6,n,n));log[:,:,ii,jj]=x;log[:,:,jj,ii]=x;w,u=np.linalg.eigh(log);values[view]=np.einsum('...ij,...j,...kj->...ik',u,np.exp(w),u,optimize=True).astype('float32');assert np.isfinite(values[view]).all();audits.append(dict(view=view,all_positive_log_eigenvalues=True))
 np.savez_compressed(out/'features.npz',**values,**reference);(out/'verification.json').write_text(json.dumps(dict(checks_passed=True,labels_not_used=True,source_only=True,audits=audits)))
if __name__=='__main__':main()
