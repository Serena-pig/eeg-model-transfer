"""Jointly learn a small subject confidence-temperature gate and fusion weights.
All parameters fitted on source inner base predictions; same rule at inference.
No outer selected temperature grid or in-sample posthoc calibration claim.
"""
import os
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='1'
import json,traceback
import numpy as np,joblib
from scipy.special import expit,logit
from scipy.optimize import minimize
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits
import driver
from context_rank_v34 import fit_context,context_features
from inner_calibration_round import calibrate
from common import batches
from postflight import pair_matrix
OUT=driver.JOB/'cached_joint_temperature_20261030';OUT.mkdir(exist_ok=True)
NAMES=['uncertainty_temperature','uncertainty_clinical_temperature']
def features(bank,groups):
 x=np.clip(logit(np.clip(bank,1e-6,1-1e-6)),-10,10).T;std=np.empty_like(x)
 for group in np.unique(groups):m=groups==group;std[m]=x[m].std(0)
 return np.column_stack([x,std])
def main():
 threadpool_limits(limits=1);p=driver.protocol();spec=dict(variants=NAMES,C_inherited=.01,temperature_range_fixed=[.5,2.],temperature_prior='SameL2asfusionweights; no intercept in logtemperature',temperature_features=['expert_disagreement','expert_entropy','consensus_top4_bottom4_gap','optional_sourceCFclinical'],conditional_BCE_mix_fixed=.5,base_models_retrained=0,source_inner_prediction_fit_only=True,no_outer_parameter_search=True,calibration='Temperature jointly learned as model parameter; previous final group policy inherited',script_sha256=driver.sha(__file__))
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==spec
 else:driver.save(OUT/'protocol.json',spec)
 with np.load(driver.ART/'features.npz') as a:d={k:a[k] for k in ['subject','label','diagnosis','trial','crop','train','powers','quality']}
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:full={k:a[k] for k in a.files}
 with np.load(driver.JOB/'dualbranch_source_stack_20261028/clinical_stack_calibrated_oof.npz') as a:anchor=a['probability']
 out={n:anchor.copy() for n in NAMES};out.update({n+'_calibrated':anchor.copy() for n in NAMES});audits=[];baseix=np.r_[np.arange(83),np.arange(104,107)]
 for f in p['folds']:
  with np.load(driver.JOB/f'cached_group_diagnostics_20261030/fold{f["fold"]}_aligned_banks.npz') as a:tr=a['inner_indices'];va=a['outer_indices'];inside=a['inner_probability'][baseix];outside=a['outer_probability'][baseix]
  old=joblib.load(driver.JOB/f'dualbranch_source_stack_20261028/fold{f["fold"]}.joblib');source=dict(d);source['label']=np.full_like(d['label'],-1);source['diagnosis']=np.full_like(d['diagnosis'],-1);source['diagnosis'][tr]=d['diagnosis'][tr];context,e=fit_context(source,tr);x=old['scaler'].transform(np.column_stack([features(inside,batches(d)[tr]),e]));gx=np.column_stack([x,.5*(2*e[:,6]-1)[:,None]*x[:,[83,84,85]]]);blind=dict(d);blind['label']=np.full_like(d['label'],-1);blind['diagnosis']=np.full_like(d['diagnosis'],-1);ev=context_features(blind,va,context);xv=old['scaler'].transform(np.column_stack([features(outside,batches(d)[va]),ev]));gv=np.column_stack([xv,.5*(2*ev[:,6]-1)[:,None]*xv[:,[83,84,85]]]);mode=json.loads((driver.JOB/f'inner_calibration_20261028/fold{f["fold"]}_selection.json').read_text())['chosen'];reference=calibrate(old['models']['clinical_stack'][0].predict_proba(gv)[:,1],batches(d)[va],mode);error=float(abs(reference-anchor[full['model_row_to_full_row'][va]]).max());assert error<1e-9,error
  y=d['label'][tr];diag=d['diagnosis'][tr];w=np.ones(len(tr))
  for v in (0,1):w[diag==v]=len(tr)/(2*np.sum(diag==v))
  wn=w/w.sum();reg=1/(.01*w.sum());start=np.r_[old['models']['clinical_stack'][0].coef_[0],old['models']['clinical_stack'][0].intercept_[0]]
  def objective(theta):
   z=gx@theta[:-1]+theta[-1];err=(expit(z)-y)*wn;return float(np.dot(wn,np.logaddexp(0,z)-y*z)+.5*reg*np.dot(theta[:-1],theta[:-1])),np.r_[gx.T@err+reg*theta[:-1],err.sum()]
  from scipy.special import logsumexp,softmax
  from sklearn.preprocessing import StandardScaler
  from select_ensemble import ASSIGNMENTS
  groups=batches(d)[tr];rr=np.stack([np.flatnonzero(groups==g) for g in np.unique(groups)]);assert np.all(y[rr].sum(1)==4);gw=w[rr].mean(1);gw/=gw.sum();A=ASSIGNMENTS;nb=len(start);models={};preds={};replays={};per=np.random.default_rng(f['fold']).permutation(len(va))
  def hfeatures(bank,group,extra,clinical):
   p=np.clip(bank.T,1e-6,1-1e-6);dis=p.std(1);ent=-(p*np.log(p)+(1-p)*np.log1p(-p)).mean(1);mean=p.mean(1);out=np.zeros((len(mean),4 if clinical else 3))
   for g in np.unique(group):
    ix=np.flatnonzero(group==g);v=np.sort(mean[ix]);row=[dis[ix].mean(),ent[ix].mean(),v[4:].mean()-v[:4].mean()]
    if clinical:row.append(extra[ix,6].mean())
    out[ix]=row
   return out
  for name in NAMES:
   clinical=name=='uncertainty_clinical_temperature';hs=hfeatures(inside,groups,e,clinical);hv=hfeatures(outside,batches(d)[va],ev,clinical);scalerH=StandardScaler().fit(hs);hh=np.clip(scalerH.transform(hs),-5,5);hvv=np.clip(scalerH.transform(hv),-5,5);theta0=np.r_[start,np.zeros(hh.shape[1])]
   def obj(theta):
    beta=theta[:nb-1];intercept=theta[nb-1];gamma=theta[nb:];t=np.tanh(hh@gamma);inverse=np.exp(-np.log(2)*t);z=(gx@beta+intercept)*inverse;err=wn*(expit(z)-y);bce=np.dot(wn,np.logaddexp(0,z)-y*z);zz=z[rr];ss=zz@A.T;post=softmax(ss,axis=1);closs=np.dot(gw,(logsumexp(ss,axis=1)-(zz*y[rr]).sum(1))/8);ce=np.zeros(len(y));ce[rr.ravel()]=((post@A-y[rr])*gw[:,None]/8).ravel();gradient=.5*err+.5*ce;gb=gx.T@(gradient*inverse)+reg*beta;gi=np.sum(gradient*inverse);gg=hh.T@(-gradient*z*np.log(2)*(1-t*t))+reg*gamma;loss=.5*bce+.5*closs+.5*reg*(np.dot(beta,beta)+np.dot(gamma,gamma));return float(loss),np.r_[gb,gi,gg]
   if f['fold']==1:
    grad=obj(theta0)[1]
    for j in (0,nb//2,nb-1,nb,nb+hh.shape[1]-1):
     aa=theta0.copy();bb=theta0.copy();aa[j]+=1e-6;bb[j]-=1e-6;err=abs((obj(aa)[0]-obj(bb)[0])/2e-6-grad[j]);assert err<1e-5,(name,j,err)
   fit=minimize(obj,theta0,jac=True,method='L-BFGS-B',options=dict(maxiter=1000,ftol=1e-12,gtol=1e-7));assert fit.success,(name,fit.message);models[name]=dict(theta=fit.x,hscaler=scalerH,clinical=clinical,nb=nb)
  artifact=dict(models=models,reference_artifact=old,context=context,source_subjects=f['training_subjects'],protocol=spec);path=OUT/f'fold{f["fold"]}.joblib';joblib.dump(artifact,path,compress=3);saved=joblib.load(path)
  def score(artifact,name,xx,bank,group,extra):
   model=artifact['models'][name];theta=model['theta'];nb=model['nb'];hh=np.clip(model['hscaler'].transform(hfeatures(bank,group,extra,model['clinical'])),-5,5);inverse=np.exp(-np.log(2)*np.tanh(hh@theta[nb:]));return expit((xx@theta[:nb-1]+theta[nb-1])*inverse)
  for name in NAMES:
   preds[name]=score(artifact,name,gv,outside,batches(d)[va],ev);replays[name]=score(saved,name,gv[per],outside[:,per],np.char.add('opaque_',batches(d)[va][per]),ev[per])
  for name,q in preds.items():
   delta=float(abs(replays[name]-q[per]).max());assert delta<1e-10;out[name][full['model_row_to_full_row'][va]]=np.round(q,12);out[name+'_calibrated'][full['model_row_to_full_row'][va]]=np.round(calibrate(q,batches(d)[va],mode),12);audits.append(dict(fold=f['fold'],model=name,anchor_reconstruction_delta=error,native_order_delta=delta))
  print('CACHED JOINT TEMPERATURE OUTER',f['fold'],'/5',flush=True)
 y=full['label'];g=full['subject'];dep=full['diagnosis']==1;ids=np.unique(g);ref=pair_matrix(y,anchor,g,ids);rng=np.random.default_rng(1030);counts=np.zeros((2000,len(ids)))
 for j in range(len(counts)):
  for mask in [np.char.startswith(ids,'DEP'),np.char.startswith(ids,'HC')]:
   ix=np.flatnonzero(mask);counts[j]+=np.bincount(rng.choice(ix,len(ix),replace=True),minlength=len(ids))
 results={}
 for name,q in out.items():
  delta=pair_matrix(y,q,g,ids)-ref;boot=np.einsum('bi,ij,bj->b',counts,delta,counts,optimize=True)/counts.sum(1)**2;results[name]=dict(pooled_auc=float(roc_auc_score(y,q)),DEP_auc=float(roc_auc_score(y[dep],q[dep])),paired_person_delta_95CI=np.quantile(boot,[.025,.975]).tolist());np.savez_compressed(OUT/(name+'_oof.npz'),labels=y,subjects=g,probability=q)
 driver.save(OUT/'summary.json',dict(results=results,anchor_auc=float(roc_auc_score(y,anchor)),base_models_retrained=0,baseline_preserved=True,cohort_reused=True,multiple_search_uncorrected=True,official_score_unknown=True));driver.save(OUT/'verification.json',dict(checks_passed=True,all5outer_complete=True,source_inner_only_fit=True,audits=audits,calibration_policy_inherited_not_new_nested_meta_search=True,analytic_gradients_verified=True,holdout_and_test_not_read=True,submissions_performed=False));print('CACHED JOINT TEMPERATURE COMPLETE',json.dumps(results),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException:driver.save(OUT/'failure.json',dict(traceback=traceback.format_exc()));raise
