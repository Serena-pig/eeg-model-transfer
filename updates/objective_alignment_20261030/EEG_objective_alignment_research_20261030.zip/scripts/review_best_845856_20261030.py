"""Independent saved-fusion replay with labels/diagnosis/flags/IDs hidden."""
import os
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='1'
import json,hashlib
from pathlib import Path
import numpy as np,joblib
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits
import driver
from common import batches,center
from context_rank_v34 import context_features
from cached_fixed_fusion_20261030 import features
from select_ensemble import postprocess
from inner_calibration_round import calibrate
OUT=driver.JOB/'aligned_covariance_fusion_20261030'
def main():
 threadpool_limits(limits=1);p=driver.protocol();baseix=np.r_[np.arange(83),np.arange(104,107)]
 with np.load(driver.ART/'features.npz') as a:d={k:a[k] for k in ['subject','trial','crop','label','diagnosis','train','powers','quality']}
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:full={k:a[k] for k in a.files}
 with np.load(OUT/'conditional_BCE87_calibrated_oof.npz') as a:reference=a['probability'];assert np.array_equal(a['labels'],full['label'])
 out=np.full(len(reference),.5);audits=[]
 for f in p['folds']:
  art=joblib.load(OUT/f'fold{f["fold"]}.joblib');saved_theta=art['models']['conditional_BCE87']
  with np.load(driver.JOB/f'cached_group_diagnostics_20261030/fold{f["fold"]}_aligned_banks.npz') as a:va=a['outer_indices'];bank=a['outer_probability'][baseix]
  with np.load(driver.JOB/f'aligned_covariance_svm_20261030/fold{f["fold"]}_outer.npz') as a:assert np.array_equal(a['validation'],va);z=a['logits']
  perm=np.random.default_rng(845856+f['fold']).permutation(len(va));ix=va[perm];query=dict(d);query['label']=np.full_like(d['label'],-1);query['diagnosis']=np.full_like(d['diagnosis'],-1);query['train']=np.zeros_like(d['train']);query['subject']=np.char.add('opaque_',d['subject']);query['trial']=np.zeros_like(d['trial']);g=batches(query)[ix];expert=postprocess(center(z[perm],g)/art['SPD_source_scale'],g,'conditional',.6);bank=np.vstack([bank[:,perm],expert]);e=context_features(query,ix,art['context']);x=art['scaler'].transform(np.column_stack([features(bank,g),e]));xx=np.column_stack([x,.5*(2*e[:,6]-1)[:,None]*x[:,[83,84,85,86]]]);from scipy.special import expit
  q=expit(xx@saved_theta[:-1]+saved_theta[-1]);mode=json.loads((driver.JOB/f'inner_calibration_20261028/fold{f["fold"]}_selection.json').read_text())['chosen'];q=calibrate(q,g,mode);rows=full['model_row_to_full_row'][ix];error=float(abs(q-reference[rows]).max());assert error<1e-9,error;out[rows]=q;audits.append(dict(fold=f['fold'],native_hidden_metadata_reordered_replay_delta=error))
 rounding={str(n):float(roc_auc_score(full['label'],np.round(reference,n))) for n in (10,12,14)};assert max(rounding.values())-min(rounding.values())<1e-6;delta=float(abs(out-reference).max());assert delta<1e-9
 receipt=dict(checks_passed=True,source_evaluation_people=60,windows10s=2400,all5outer_saved_fusion_replayed=True,query_labels_diagnoses_flags_trial_ids_hidden=True,query_subject_ids_opaque=True,query_rows_shuffled=True,maximum_prediction_delta=delta,rounding_auc=rounding,audits=audits,base_classifiers_previously_native_replayed=True,official_and_holdout_not_read=True)
 driver.save(OUT/'independent_review_20261030.json',receipt);print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
