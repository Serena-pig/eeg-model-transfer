"""Six aligned-SPD SVM configs, selected only on3source-inner folds.
Both input representation and C chosen inside each outer-training split.
Caches source-inner forecasts for subsequent source-only fusion refits.
"""
import os
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='1'
import json,traceback,hashlib
import numpy as np,joblib
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics.pairwise import rbf_kernel
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits
import driver
from common import batches
from select_ensemble import postprocess
OUT=driver.JOB/'aligned_covariance_svm_20261030';OUT.mkdir(exist_ok=True)
CONFIGS=[dict(view=v,C=c) for v in ['matrix_log','diagonal'] for c in [.1,1.,10.]]
def weights(diag):
 w=np.ones(len(diag))
 for v in [0,1]:w[diag==v]=len(diag)/(2*np.sum(diag==v))
 return w
def make_design(x,tr,va):
 scaler=StandardScaler().fit(x[tr]);xt=scaler.transform(x[tr]).astype('float64');xv=scaler.transform(x[va]).astype('float64');gamma=1/x.shape[1];return scaler,xt,xv,rbf_kernel(xt,xt,gamma=gamma),rbf_kernel(xv,xt,gamma=gamma)
def fit_selected(x,d,tr,va,cfg,path):
 scaler,xt,xv,kt,kv=make_design(x,tr,va);model=SVC(C=cfg['C'],kernel='precomputed',cache_size=256).fit(kt,d['label'][tr],sample_weight=weights(d['diagnosis'][tr]));sd=max(float(model.decision_function(kt).std()),.1);z=model.decision_function(kv)/sd;artifact=dict(model=model,scaler=scaler,train_indices=tr,config=cfg,score_scale=sd,source_subjects=np.unique(d['subject'][tr]).tolist(),feature_matrix_sha256=hashlib.sha256(np.ascontiguousarray(x).tobytes()).hexdigest());joblib.dump(artifact,path,compress=3);saved=joblib.load(path);perm=np.random.default_rng(1030).permutation(len(va));xx=saved['scaler'].transform(x[va[perm]]).astype('float64');tt=saved['scaler'].transform(x[saved['train_indices']]).astype('float64');replay=saved['model'].decision_function(rbf_kernel(xx,tt,gamma=1/x.shape[1]))/saved['score_scale'];error=float(abs(replay-z[perm]).max());assert error<1e-9,error;return z,error

def main():
 threadpool_limits(limits=1);p=driver.protocol();fp=driver.JOB/'aligned_covariance_20261030/features.npz';assert json.loads((fp.parent/'verification.json').read_text())['checks_passed'];spec=dict(configs=CONFIGS,selection='Mean3inner pooledAUC minus.1std; DEPfloor diagonalC1 mean minus.002',normalization='StandardScaler fit source train only',kernel='RBF gamma1/d, precomputed to reuse kernels acrossC',score='conditional4of8, source train decision std',base_models_are_new_SVM_only=True,no_new_deep_training=True,script_sha256=driver.sha(__file__),features_sha256=driver.sha(fp))
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==spec
 else:driver.save(OUT/'protocol.json',spec)
 with np.load(fp) as a:xs={v:a[v] for v in ['matrix_log','diagonal']};subjects=a['subject']
 with np.load(driver.ART/'features.npz') as a:d={k:a[k] for k in ['subject','trial','crop','label','diagnosis','train']}
 assert np.array_equal(subjects,d['subject'])
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:full={k:a[k] for k in a.files}
 groups=batches(d);out=np.full(len(full['label']),.5);audits=[]
 for f in p['folds']:
  metrics={i:[] for i in range(len(CONFIGS))};depmetrics={i:[] for i in range(len(CONFIGS))}
  for part in range(3):
   sp=f['inner'][part];tr=np.flatnonzero(np.isin(subjects,sp['training_subjects']));va=np.flatnonzero(np.isin(subjects,sp['validation_subjects']));assert not set(subjects[tr])&set(subjects[va]);dep=d['diagnosis'][va]==1
   for view in ['matrix_log','diagonal']:
    scaler,xt,xv,kt,kv=make_design(xs[view],tr,va)
    for i,cfg in enumerate(CONFIGS):
     if cfg['view']!=view:continue
     cache=OUT/f'fold{f["fold"]}_inner{part}_config{i}.npz'
     if cache.exists():
      with np.load(cache) as a:assert np.array_equal(a['validation'],va);q=a['probability']
     else:
      model=SVC(C=cfg['C'],kernel='precomputed',cache_size=256).fit(kt,d['label'][tr],sample_weight=weights(d['diagnosis'][tr]));sd=max(float(model.decision_function(kt).std()),.1);z=model.decision_function(kv)/sd;q=postprocess(z,groups[va],'conditional',1.);np.savez_compressed(cache,validation=va,logits=z,probability=q)
     metrics[i].append(float(roc_auc_score(d['label'][va],q)));depmetrics[i].append(float(roc_auc_score(d['label'][va][dep],q[dep])))
   driver.save(OUT/'progress.json',dict(stage='inner_selection',outer=f['fold'],inner=part+1,total_outer=5));print('ALIGNED SPD INNER',f['fold'],part+1,'/3',flush=True)
  reference=CONFIGS.index(dict(view='diagonal',C=1.));floor=np.mean(depmetrics[reference])-.002;eligible=[i for i in metrics if np.mean(depmetrics[i])>=floor];chosen=max(eligible,key=lambda i:np.mean(metrics[i])-.1*np.std(metrics[i]));cfg=CONFIGS[chosen];driver.save(OUT/f'fold{f["fold"]}_selection.json',dict(config=cfg,index=chosen,pooled_inner=metrics,DEP_inner=depmetrics,source_inner_labels_only=True))
  tr=np.flatnonzero(np.isin(subjects,f['training_subjects']));va=np.flatnonzero(np.isin(subjects,f['validation_subjects']));z,error=fit_selected(xs[cfg['view']],d,tr,va,cfg,OUT/f'fold{f["fold"]}_outer.joblib');q=postprocess(z,groups[va],'conditional',1.);out[full['model_row_to_full_row'][va]]=q;np.savez_compressed(OUT/f'fold{f["fold"]}_outer.npz',validation=va,logits=z,probability=q)
  # Preserve selected native inner models, while reusing their already-heldout forecasts.
  for j,sp in enumerate(f['inner']):
   tt=np.flatnonzero(np.isin(subjects,sp['training_subjects']));vv=np.flatnonzero(np.isin(subjects,sp['validation_subjects']));zz,err=fit_selected(xs[cfg['view']],d,tt,vv,cfg,OUT/f'fold{f["fold"]}_inner{j}.joblib')
   with np.load(OUT/f'fold{f["fold"]}_inner{j}_config{chosen}.npz') as a:assert np.array_equal(a['validation'],vv);delta=float(abs(a['logits']-zz).max());assert delta<1e-9
   np.savez_compressed(OUT/f'fold{f["fold"]}_inner{j}.npz',validation=vv,logits=zz,probability=postprocess(zz,groups[vv],'conditional',1.));audits.append(dict(fold=f['fold'],part=j,native_permutation_delta=err,selected_forecast_replay_delta=delta))
  audits.append(dict(fold=f['fold'],part='outer',native_permutation_delta=error));print('ALIGNED SPD OUTER',f['fold'],'/5 CHOSEN',cfg,flush=True)
 y=full['label'];dep=full['diagnosis']==1;np.savez_compressed(OUT/'selected_oof.npz',labels=y,subjects=full['subject'],probability=out);summary=dict(pooled_auc=float(roc_auc_score(y,out)),DEP_auc=float(roc_auc_score(y[dep],out[dep])),all5outer3inner=True,source_only_representation_and_C_selection=True,cohort_reused=True,official_score_unknown=True);driver.save(OUT/'summary.json',summary);driver.save(OUT/'verification.json',dict(checks_passed=True,audits=audits,all_selected_models_native_replayed=True,holdout_and_official_not_read=True,submissions_performed=False));driver.save(OUT/'progress.json',dict(stage='complete',outer=5,total_outer=5));print('ALIGNED SPD SVM COMPLETE',json.dumps(summary),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException:driver.save(OUT/'failure.json',dict(traceback=traceback.format_exc()));raise
