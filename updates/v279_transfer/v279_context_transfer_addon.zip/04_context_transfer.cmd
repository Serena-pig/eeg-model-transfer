@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Copy this addon into the original EEG_BEST_AUC_20261025 model folder first.
  pause
  exit /b 1
)
set "EEG_BASE_FOLDS=%~1"
if not defined EEG_BASE_FOLDS (
  for /f "delims=" %%F in ('dir /b /a-d /o-d "predictions\submission_best_*.folds.npz" 2^>nul') do if not defined EEG_BASE_FOLDS set "EEG_BASE_FOLDS=predictions\%%F"
)
if not defined EEG_BASE_FOLDS (
  echo Run 02_generate_submission.cmd in the original model folder first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -X utf8 context_transfer_runtime.py --base-folds "%EEG_BASE_FOLDS%"
pause
