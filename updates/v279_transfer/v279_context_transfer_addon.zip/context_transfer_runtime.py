"""Portable inference for source-trained contextual emotion directions; no fitting."""
from pathlib import Path
import itertools,json,hashlib,argparse
import numpy as np,joblib
from scipy.signal import butter,sosfiltfilt
from scipy.special import logsumexp
ASSIGN=np.zeros((70,8))
for j,c in enumerate(itertools.combinations(range(8),4)):ASSIGN[j,list(c)]=1

def absolute_de(windows):
    x=np.asarray(windows,dtype='float32');assert x.shape[1:]==(30,2500) and np.isfinite(x).all();x=x-x.mean(-1,keepdims=True);v=[]
    for lo,hi in [(1,4),(4,8),(8,13),(13,20),(20,30),(30,45)]:
        a=sosfiltfilt(butter(4,[lo,hi],fs=250,btype='bandpass',output='sos'),x,axis=-1);v.append(a.var(-1).clip(1e-30))
    return (.5*np.log(2*np.pi*np.e*np.stack(v,axis=1))).reshape(len(x),180)

def inputs(de,keys):
    de=np.asarray(de,dtype=float);keys=np.asarray(keys);context=np.empty((len(de),360));center=np.empty_like(de);z=np.empty_like(de)
    for key in np.unique(keys):
        rr=np.flatnonzero(keys==key);assert len(rr)==8;a=de[rr];mean=a.mean(0);context[rr]=np.r_[mean-mean.mean(),np.log(np.maximum(a.std(0),.05))];center[rr]=a-mean;z[rr]=center[rr]/np.maximum(a.std(0),.1)
    return dict(context=context,center=center,z=z,good=np.exp(np.median(de-.5*np.log(2*np.pi*np.e),axis=1))>=1e-5)

def predict_model(artifact,x,keys):
    context=artifact['context'];c=context['pca'].transform(context['scaler'].transform(x['context']))/context['scale'];c=artifact['context_scaler'].transform(c);v=artifact['scaler'].transform(x[artifact['normalization']]);z=np.c_[v,(v[:,:,None]*c[:,None,:]).reshape(len(v),-1)]@artifact['coef'];p=np.empty(len(z))
    for key in np.unique(keys):
        rr=np.flatnonzero(keys==key);a=z[rr]-z[rr].mean();energy=a@ASSIGN.T;p[rr]=np.exp(energy-logsumexp(energy))@ASSIGN
    p=np.clip(p,1e-8,1-1e-8);p[~x['good']]=.5;return p

def predict_folds(de,keys,base_folds,model_dir):
    x=inputs(de,keys);byfold=[];models=Path(model_dir);manifest=json.loads((models/'manifest.json').read_text());assert np.shape(base_folds)==(5,len(keys))
    for fold in range(1,6):
        info=manifest['folds'][str(fold)];p=models/info['file'];assert hashlib.sha256(p.read_bytes()).hexdigest()==info['sha256'];a=joblib.load(p);new=predict_model(a,x,keys);base=np.asarray(base_folds[fold-1]).copy();base[~x['good']]=.5;byfold.append((1-info['blend'])*base+info['blend']*new)
    byfold=np.array(byfold);return byfold.mean(0),byfold

def main():
    from threadpoolctl import threadpool_limits
    import predict_best as original
    parser=argparse.ArgumentParser();parser.add_argument('--base-folds',required=True,type=Path);parser.add_argument('--test-dir',default=original.ROOT/'test_data',type=Path);parser.add_argument('--output',type=Path);args=parser.parse_args();limits=threadpool_limits(limits=1)
    audit=args.base_folds.with_name(args.base_folds.name.replace('.folds.npz','.audit.json'));info=json.loads(audit.read_text('utf-8'));assert info['model_family']==original.release_predictor.BEST
    with np.load(args.base_folds) as a:base=a['fold_probabilities'];assert base.shape==(5,80) and np.allclose(base.mean(0),a['probability'],atol=1e-12,rtol=0)
    entries=original.files(args.test_dir);de=[];keys=[]
    for subject in original.EXPECTED:
        raw,digest=entries[subject];assert digest==info['test_raw_sha256'][subject],('Base predictions refer to different raw data',subject);de.append(absolute_de(original.load_windows(raw)));keys.extend([subject+':0']*8)
    probability,byfold=predict_folds(np.concatenate(de),np.array(keys),base,Path(__file__).resolve().parent/'context_transfer_models');destination=args.output or args.base_folds.with_name(args.base_folds.name.replace('.folds.npz','_context_v279.xlsx'));assert not destination.exists(),'Output already exists; refusing overwrite.'
    original.write_output(probability,destination,original.ROOT/'submission_template.xlsx');np.savez_compressed(destination.with_suffix('.context_folds.npz'),fold_probabilities=byfold,probability=probability)
    destination.with_suffix('.audit.json').write_text(json.dumps(dict(source_base_fold_file=str(args.base_folds),base_fold_sha256=hashlib.sha256(args.base_folds.read_bytes()).hexdigest(),calibration='Source-selected per-fold contextual conditional logistic direction; fixed arithmetic fold average; low-signal0.5 rule',official_test_labels_used=False,submission_performed=False,official_auc_unknown=True,internal_validation_not_fresh=True),ensure_ascii=False,indent=2),'utf-8');print('LOCAL CANDIDATE READY:',destination)
if __name__=='__main__':main()
