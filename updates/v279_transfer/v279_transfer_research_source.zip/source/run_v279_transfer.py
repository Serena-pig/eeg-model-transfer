"""Matched 5x3 source-person validation; no submitted weights/test-signal access."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from datetime import datetime
import argparse,json,hashlib,time
import numpy as np,joblib
from scipy.special import expit,logit
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits
import run_leaderboard_calibration_v2 as cal
import v279_transfer_models as m
import auc_cluster_bootstrap as boot
ROOT=cal.ROOT

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):cal.r.r.base.save(p,v)

def load():
    import run_group_auc as raw
    x,y,g,split=raw.load();keys=raw.group_ids(g)
    fine=[]
    for s in split['development']:
        with np.load(ROOT/'expanded_features/development'/(s+'.npz')) as a:
            assert np.array_equal(a['y'],y[g==s]);fine.append(a['fine_psd'])
    d=dict(y=y,g=g,keys=keys,crop=np.tile(np.arange(40)%5,len(split['development'])))
    d['context']=m.contexts(x['absolute_de'],keys)
    d['de_center']=m.group_transform(x['absolute_de'],keys)
    d['de_z']=m.group_transform(x['absolute_de'],keys,'z')
    d['spec_rank']=m.group_transform(np.concatenate(fine),keys,'rank')
    with np.load(cal.CHAMPION/'person_bagged_oof.npz') as a:
        assert np.array_equal(y,a['labels']) and np.array_equal(g,a['subjects']);p=a['probability'];rep=a['representative']
    return d,split,p,rep

CONFIGS={**{'conditional_'+n+'_r'+str(a):dict(kind='logistic',normalization=n,alpha=a) for n in ['center','z'] for a in [.3,3.]},
         'context_kernel_de':dict(kind='kernel',feature='de_z'),
         'context_kernel_spectrum':dict(kind='kernel',feature='spec_rank'),
         'time_de_experts':dict(kind='time')}

def fit_predict(d,tr,va,cfg,path):
    if path.exists():
        obj=joblib.load(path)
    else:
        assert set(d['g'][tr]).isdisjoint(d['g'][va])
        if cfg['kind']=='logistic':obj=[m.ContextLogistic(cfg['normalization'],'conditional',cfg['alpha']).fit(d,tr)]
        elif cfg['kind']=='kernel':obj=[m.ContextKernel(cfg['feature']).fit(d,tr)]
        else:
            crops=[[i] for i in range(5)]+[[i,i+1] for i in range(4)]
            obj=[m.ContextKernel(crops=c).fit(d,tr) for c in crops]
        joblib.dump(obj,path,compress=3)
    preds=[]
    for model in obj:
        assert set(model.training_subjects)==set(d['g'][tr])
        z=model.predict(d,va);preds.append(m.posterior(z,d['keys'][va]))
    # Fixed equal probability average of all nine time experts, never choose by query timing.
    return np.mean(preds,axis=0)

def base_bank(fold,expected_g):
    plan=json.loads((cal.CHAMPION/'plan.json').read_text());base={k:ROOT/'runs'/v for k,v in plan['base_sources'].items()};new={k:ROOT/'runs'/v for k,v in plan['new_sources'].items()}
    iy,ig,ip,cols,outs,names=cal.fusion.components(base,new,fold)
    assert np.array_equal(ig,expected_g)
    _,_,champion=cal.source(fold)
    return np.array([champion]+cols),np.array(outs),['champion']+names

def run(out,mode):
    limits=threadpool_limits(limits=1);d,split,anchor,rep=load();y=d['y'];g=d['g'];keys=d['keys']
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    plan=dict(mode=mode,configurations=CONFIGS,rank_policies=['plain','context','context_bag5'],rank_iterations=400,rank_depth=2,rank_l2=1000,rank_cross_pairs=100000,primary='context_bag5' if mode=='rank' else 'inner_selected_fusion',source='Supplied v279 code ideas only; supplied final69-person weights NOT loaded',provided_official_score_user_reported=85.,provided_internal_auc=.8296841820987655,provided_development_people=56,matched_development_people=60,outer=5,inner=3,script_sha256=digest(__file__),models_sha256=digest(ROOT/'v279_transfer_models.py'),holdout_not_loaded=split['holdout'],official_test_loaded=False,submission_performed=False,not_fresh_validation=True,source_inner_caveat='Existing base source OOF settings and coefficients reuse source labels; meta-training loss is not an unbiased score. Outer persons excluded. Long-term reused development; no independent confirmation.',source_context='Per anonymous8trial DE mean with recordinggainremoved and logstd; PCA6 fitted source people only. FinePSD660 not original v27944Hz spectrum; CPU adaptation not exact reproduction.',time_protocol='All nine single/adjacent source crop experts, fixed equal average; source crop offsets never applied to query rows.')
    if (out/'plan.json').exists():assert json.loads((out/'plan.json').read_text())==plan
    else:save(out/'plan.json',plan)
    records=[]
    for fold,(aa,bb) in enumerate(cal.r.r.base.folds(split['development']),1):
        if (out/f'fold{fold}.json').exists():records.append(json.loads((out/f'fold{fold}.json').read_text()));continue
        start=time.time();tr=np.flatnonzero(np.isin(g,aa));va=np.flatnonzero(np.isin(g,bb));inner=[(np.flatnonzero(np.isin(g,a)),np.flatnonzero(np.isin(g,b))) for a,b in cal.r.r.base.folds(aa,n=3)]
        innerix=np.concatenate([v for _,v in inner]);iy=y[innerix];ig=g[innerix];ik=keys[innerix];_,gg,ip=cal.source(fold);assert np.array_equal(ig,gg)
        assert set(aa).isdisjoint(bb) and set(aa).isdisjoint(split['holdout'])
        predictions={};inner_predictions={};choices={};rows=[]
        if mode=='rank':
            bank,outs,names=base_bank(fold,ig);outerbank=np.r_[anchor[va][None,:],outs[:,va]]
            for name,context,members in [('plain',False,1),('context',True,1),('context_bag5',True,5)]:
                path=out/f'fold{fold}_{name}.joblib'
                if path.exists():model=joblib.load(path)
                else:model=m.ContextRank(context,members).fit(d,innerix,bank);joblib.dump(model,path,compress=3)
                assert set(model.training_subjects)==set(aa)
                predictions[name]=model.predict(d,va,outerbank)
                print('V279 RANK POLICY',fold,name,'seconds',round(time.time()-start,1),flush=True)
            np.savez_compressed(out/f'fold{fold}_replay.npz',validation_indices=va,outer_bank=outerbank,source_bank=bank,source_indices=innerix)
        else:
            for name,cfg in CONFIGS.items():
                parts=[]
                for j,(it,iv) in enumerate(inner):
                    path=out/f'fold{fold}_inner{j}_{name}.joblib';parts.append(fit_predict(d,it,iv,cfg,path))
                p=np.concatenate(parts);inner_predictions[name]=p
                predictions[name]=fit_predict(d,tr,va,cfg,out/f'fold{fold}_{name}.joblib')
                print('V279 SOURCE MODEL',fold,name,'seconds',round(time.time()-start,1),flush=True)
            def objective(p):return float(np.mean([boot.evaluation(iy[np.isin(ig,b)],p[np.isin(ig,b)],ig[np.isin(ig,b)],ik[np.isin(ig,b)])['auc'] for _,b in cal.r.r.base.folds(aa,n=3)]))
            rows=[dict(model='baseline',blend=0.,score=objective(ip))]
            for name,p in inner_predictions.items():
                for blend in [.1,.25,.5,1.]:rows.append(dict(model=name,blend=blend,score=objective((1-blend)*ip+blend*p)))
            choice=max(rows,key=lambda r:r['score']);choices['inner_selected_fusion']=choice
            predictions['inner_selected_fusion']=anchor[va] if choice['model']=='baseline' else (1-choice['blend'])*anchor[va]+choice['blend']*predictions[choice['model']]
            predictions['fixed_time_blend25']=.75*anchor[va]+.25*predictions['time_de_experts']
            np.savez_compressed(out/f'fold{fold}_inner.npz',labels=iy,subjects=ig,baseline_probability=ip,**inner_predictions)
        np.savez_compressed(out/f'fold{fold}_outer.npz',validation_indices=va,**predictions)
        record=dict(fold=fold,training_subjects=aa.tolist(),validation_subjects=bb.tolist(),choices=choices,candidates=rows,seconds=time.time()-start)
        save(out/f'fold{fold}.json',record);records.append(record);print('V279 FOLD COMPLETE',mode,fold,round(time.time()-start,1),flush=True)
    names=None;allpred={};counts=np.zeros(len(y),int)
    for fold in range(1,6):
        with np.load(out/f'fold{fold}_outer.npz') as a:
            va=a['validation_indices'];counts[va]+=1
            for name in a.files:
                if name=='validation_indices':continue
                if name not in allpred:allpred[name]=np.full(len(y),np.nan)
                allpred[name][va]=a[name]
    assert np.all(counts==1)
    summary=dict(folds=records);allpred['baseline']=anchor;allpred['fixed4_baseline']=cal.transform(anchor,keys,'posterior',1.)
    for name,p in allpred.items():
        assert np.isfinite(p).all();summary[name]=cal.r.summarize(y,p,g,keys,rep)
        np.savez_compressed(out/(name+'_oof.npz'),labels=y,subjects=g,group_ids=keys,representative=rep,probability=p)
    save(out/'summary.json',summary)
    save(out/'bootstrap.json',{name:boot.compare(y,p,allpred['fixed4_baseline'],g,rep,keys) for name,p in allpred.items() if name not in ['baseline','fixed4_baseline']})
    print('V279 COMPLETE',out,flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['rank','context']);parser.add_argument('--root',type=Path);a=parser.parse_args()
    out=a.root or ROOT/'runs'/('v279_transfer_'+a.mode+'_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    (ROOT/('CURRENT_V279_TRANSFER_'+a.mode.upper()+'.txt')).write_text(str(out));run(out,a.mode)
