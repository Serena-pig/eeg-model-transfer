"""Independent portable replay of every outer head, matched source sets."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import json,numpy as np,joblib
from threadpoolctl import threadpool_limits
import run_v279_transfer as r

def main():
    limits=threadpool_limits(limits=1);root=Path((r.ROOT/'CURRENT_V279_CBRAMOD_HEADS.txt').read_text().strip());d,split,anchor,rep=r.load();g=d['g'];keys=d['keys'];y=d['y'];manifest=json.loads((root/'plan.json').read_text())['pretrained_feature_manifest'];feature_root=r.ROOT/'foundation_features/v279_cbramod/development';flat=[];glob=[]
    for s in split['development']:
        p=feature_root/(s+'.npz');assert r.digest(p)==manifest['files'][s]
        with np.load(p) as a:flat.append(a['flat']);glob.append(a['global_mean'])
    x=dict(flat_center=r.m.group_transform(np.concatenate(flat),keys),flat_z=r.m.group_transform(np.concatenate(flat),keys,'z'),global_z=r.m.group_transform(np.concatenate(glob),keys,'z'))
    import run_group_auc as raw
    original,_,_,_=raw.load();good=np.exp(np.median(original['absolute_de']-.5*np.log(2*np.pi*np.e),axis=1))>=1e-5;maximum=0.;permutation=0.;headcount=0
    for fold,(aa,bb) in enumerate(r.cal.r.r.base.folds(split['development']),1):
        va=np.flatnonzero(np.isin(g,bb));perm=np.random.default_rng(42+fold).permutation(len(va));rec=json.loads((root/f'fold{fold}.json').read_text())
        with np.load(root/f'fold{fold}_outer.npz') as a:
            for name in a.files:
                if name in ['validation_indices','pure_selected','inner_selected_fusion']:continue
                m=joblib.load(root/f'fold{fold}_outer_{name}.joblib');assert set(m['training_subjects'])==set(g[np.isin(g,aa)&good]);assert set(m['training_subjects']).isdisjoint(bb) and set(m['training_subjects']).isdisjoint(split['holdout'])
                def predict(ix):
                    z=m['pca'].transform(m['scaler'].transform(x[m['feature']][ix]))/m['scale'];de=m['de_scaler'].transform(d['de_z'][ix]);xx=np.c_[z,de*np.sqrt(64/180)*.5];p=r.m.posterior(m['model'].decision_function(xx)/m['score_scale'],keys[ix]);p[~good[ix]]=.5;return p
                q=predict(va);pq=predict(va[perm]);maximum=max(maximum,float(abs(q-a[name]).max()));permutation=max(permutation,float(abs(q[perm]-pq).max()));headcount+=1
            c=rec['choice'];base=anchor[va].copy();base[~good[va]]=.5;q=base if c['model']=='baseline' else (1-c['blend'])*base+c['blend']*a[c['model']];maximum=max(maximum,float(abs(q-a['inner_selected_fusion']).max()))
        with np.load(root/f'fold{fold}_inner.npz') as cache:
            iy=cache['labels'];ig=cache['subjects'];ik=r.cal.r.r.group_ids(ig);ip=cache['baseline_probability']
            def objective(p):return float(np.mean([r.boot.evaluation(iy[np.isin(ig,b)],p[np.isin(ig,b)],ig[np.isin(ig,b)],ik[np.isin(ig,b)])['auc'] for _,b in r.cal.r.r.base.folds(aa,n=3)]))
            rows=[dict(model='baseline',blend=0.,score=objective(ip))]
            for name in cache.files:
                if name in ['labels','subjects','baseline_probability']:continue
                for blend in [.1,.25,.5,1.]:rows.append(dict(model=name,blend=blend,score=objective((1-blend)*ip+blend*cache[name])))
            assert rows==rec['candidates'];assert max(rows,key=lambda v:v['score'])==rec['choice']
    assert headcount==60 and maximum<1e-9 and permutation<1e-8,(headcount,maximum,permutation)
    r.save(root/'verification.json',dict(checks_passed=True,outer_heads_replayed=headcount,max_prediction_delta=maximum,max_permutation_error=permutation,source_sets_and_inner_choices_verified=True,frozen_backbone_hash_verified=True,provided69person_heads_loaded=False,holdout_loaded=False,official_test_loaded=False,submissions_performed=False,not_fresh_validation=True));print('CBRAMOD HEAD VERIFIED',maximum,permutation,flush=True)
if __name__=='__main__':main()
