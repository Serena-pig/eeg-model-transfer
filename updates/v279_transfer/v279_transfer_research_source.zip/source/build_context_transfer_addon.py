"""Export only selected verified source models, preserving original package."""
from pathlib import Path
import hashlib,json,shutil,joblib,numpy as np
import run_v279_transfer as r
import context_transfer_runtime as runtime
ROOT=r.ROOT
def main():
    folder=Path((ROOT/'CURRENT_V279_QUALITY_TRANSFER.txt').read_text().strip());assert json.loads((folder/'verification.json').read_text())['checks_passed'];out=ROOT/'v279_context_addon';out.mkdir(exist_ok=True);models=out/'context_transfer_models';models.mkdir(exist_ok=True);d,split,anchor,rep=r.load();manifest=dict(primary='quality_controlled_inner_selected_fusion',folds={},official_auc_unknown=True,not_fresh_validation=True);maximum=0.;max_fusion=0.
    for fold,(aa,bb) in enumerate(r.cal.r.r.base.folds(split['development']),1):
        rec=json.loads((folder/f'fold{fold}.json').read_text());c=rec['choice'];assert c['model'].startswith('conditional_');model=joblib.load(folder/f'fold{fold}_{c["model"]}.joblib')[0]
        a=dict(normalization=model.normalization,scaler=model.scaler,coef=model.coef,context_scaler=model.cs,context=dict(scaler=model.context.scaler,pca=model.context.pca,scale=model.context.scale),training_subjects=model.training_subjects)
        path=models/f'fold{fold}.joblib';joblib.dump(a,path,compress=3);manifest['folds'][str(fold)]=dict(file=path.name,sha256=r.digest(path),blend=c['blend'],model=c['model'],training_subjects=model.training_subjects)
        va=np.flatnonzero(np.isin(d['g'],bb));import run_group_auc as raw
        rawde,_,_,_=raw.load();x=runtime.inputs(rawde['absolute_de'][va],d['keys'][va]);q=runtime.predict_model(joblib.load(path),x,d['keys'][va])
        with np.load(folder/f'fold{fold}_outer.npz') as cache:
            maximum=max(maximum,float(abs(q-cache[c['model']]).max()));base=anchor[va].copy();base[~x['good']]=.5;combined=(1-c['blend'])*base+c['blend']*q;max_fusion=max(max_fusion,float(abs(combined-cache['inner_selected_fusion']).max()))
    r.save(models/'manifest.json',manifest)
    shutil.copy2(ROOT/'context_transfer_runtime.py',out/'context_transfer_runtime.py')
    r.save(out/'PORTABLE_VERIFICATION.json',dict(checks_passed=True,selected_model_reload_max_delta=maximum,fusion_max_delta=max_fusion,provided_69person_weights_loaded=False,official_test_loaded=False,submissions_performed=False));assert maximum<1e-12 and max_fusion<1e-12
    print('EXPORTED',out,'bytes',sum(p.stat().st_size for p in out.rglob('*') if p.is_file()),maximum,max_fusion)
if __name__=='__main__':main()
