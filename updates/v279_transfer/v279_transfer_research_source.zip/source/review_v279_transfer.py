"""Reload every outer model, audit source sets/decisions, query-field invariance."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import argparse,json
from pathlib import Path
import numpy as np,joblib
from threadpoolctl import threadpool_limits
import run_v279_transfer as r

def main(folder):
    limits=threadpool_limits(limits=1);folder=Path(folder);d,split,anchor,rep=r.load();plan=json.loads((folder/'plan.json').read_text())
    assert plan['script_sha256']==r.digest(r.__file__) and plan['models_sha256']==r.digest(r.ROOT/'v279_transfer_models.py')
    counts=np.zeros(len(d['y']),int);maximum=0.;permutation=0.;decisions=0
    clean={k:v for k,v in d.items() if k not in ['y','g','crop']}
    for fold,(aa,bb) in enumerate(r.cal.r.r.base.folds(split['development']),1):
        rec=json.loads((folder/f'fold{fold}.json').read_text());assert rec['training_subjects']==aa.tolist() and rec['validation_subjects']==bb.tolist()
        va=np.flatnonzero(np.isin(d['g'],bb));counts[va]+=1;perm=np.random.default_rng(1000+fold).permutation(len(va))
        with np.load(folder/f'fold{fold}_outer.npz') as a:
            assert np.array_equal(a['validation_indices'],va)
            if plan['mode']=='context':
                for name,cfg in r.CONFIGS.items():
                    models=joblib.load(folder/f'fold{fold}_{name}.joblib');q=[];pq=[]
                    for model in models:
                        assert set(model.training_subjects)==set(aa) and set(model.context.training_subjects)==set(aa)
                        assert set(model.training_subjects).isdisjoint(bb) and set(model.training_subjects).isdisjoint(split['holdout'])
                        q.append(r.m.posterior(model.predict(clean,va),d['keys'][va]));pq.append(r.m.posterior(model.predict(clean,va[perm]),d['keys'][va[perm]]))
                    q=np.mean(q,axis=0);pq=np.mean(pq,axis=0);maximum=max(maximum,float(abs(q-a[name]).max()));permutation=max(permutation,float(abs(q[perm]-pq).max()))
                with np.load(folder/f'fold{fold}_inner.npz') as cache:
                    iy=cache['labels'];ig=cache['subjects'];ip=cache['baseline_probability'];ik=r.cal.r.r.group_ids(ig)
                    def score(p):return float(np.mean([r.boot.evaluation(iy[np.isin(ig,b)],p[np.isin(ig,b)],ig[np.isin(ig,b)],ik[np.isin(ig,b)])['auc'] for _,b in r.cal.r.r.base.folds(aa,n=3)]))
                    rows=[dict(model='baseline',blend=0.,score=score(ip))]
                    for name in r.CONFIGS:
                        for blend in [.1,.25,.5,1.]:rows.append(dict(model=name,blend=blend,score=score((1-blend)*ip+blend*cache[name])))
                    assert rows==rec['candidates'];c=max(rows,key=lambda x:x['score']);assert c==rec['choices']['inner_selected_fusion'];decisions+=1
                    q=anchor[va] if c['model']=='baseline' else (1-c['blend'])*anchor[va]+c['blend']*a[c['model']]
                    maximum=max(maximum,float(abs(q-a['inner_selected_fusion']).max()))
                for j,(ia,ib) in enumerate(r.cal.r.r.base.folds(aa,n=3)):
                    for name in r.CONFIGS:
                        for model in joblib.load(folder/f'fold{fold}_inner{j}_{name}.joblib'):
                            assert set(model.training_subjects)==set(ia) and set(model.training_subjects).isdisjoint(ib) and set(model.training_subjects).isdisjoint(bb)
            else:
                with np.load(folder/f'fold{fold}_replay.npz') as cache:
                    bank=cache['outer_bank']
                    for name in ['plain','context','context_bag5']:
                        model=joblib.load(folder/f'fold{fold}_{name}.joblib');assert set(model.training_subjects)==set(aa)
                        for member in model.models:assert set(member['subjects']).issubset(aa) and set(member['subjects']).isdisjoint(bb)
                        q=model.predict(clean,va,bank);pq=model.predict(clean,va[perm],bank[:,perm]);maximum=max(maximum,float(abs(q-a[name]).max()));permutation=max(permutation,float(abs(q[perm]-pq).max()))
    assert np.all(counts==1) and maximum<1e-9 and permutation<1e-8,(maximum,permutation)
    r.save(folder/'verification.json',dict(checks_passed=True,reloaded_outer_fits=True,source_sets_and_source_choices_verified=True,decisions_recomputed=decisions,max_prediction_delta=maximum,max_permutation_error=permutation,inference_without_labels_diagnosis_or_subject_ids=True,not_fresh_validation=True,provided_69person_weights_loaded=False,holdout_loaded=False,public_test_loaded=False,submissions_performed=False))
    print('VERIFIED',folder,maximum,permutation,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('folder');a=p.parse_args();main(a.folder)
