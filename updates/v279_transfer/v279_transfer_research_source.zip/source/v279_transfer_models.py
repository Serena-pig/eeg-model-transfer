"""Independent source-only adaptations of the supplied v279 context/time/ranking ideas.

Not the submitted v279 model: different features, split, normalization and CPU
dependency versions. Its fitted 69-person weights are deliberately never loaded.
"""
import copy
import itertools
import numpy as np
from scipy.optimize import minimize
from scipy.special import expit, logsumexp, logit
from scipy.stats import rankdata, norm
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn.metrics.pairwise import rbf_kernel
from catboost import CatBoostRanker

ASSIGN = np.zeros((70, 8))
for j, subset in enumerate(itertools.combinations(range(8), 4)):
    ASSIGN[j, list(subset)] = 1

def group_transform(x, keys, mode='center'):
    out = np.empty_like(x, dtype=float)
    for k in np.unique(keys):
        rr = np.flatnonzero(keys == k); a = x[rr].astype(float)
        assert len(rr) == 8
        if mode == 'rank': out[rr] = norm.ppf((rankdata(a, axis=0)-.5)/8)
        else:
            out[rr] = a-a.mean(0)
            if mode == 'z': out[rr] /= np.maximum(a.std(0), .1)
    return out

def posterior(z, keys):
    out = np.empty(len(z))
    for k in np.unique(keys):
        rr = np.flatnonzero(keys == k); assert len(rr) == 8
        energy = z[rr] @ ASSIGN.T
        weights = np.exp(energy-logsumexp(energy))
        out[rr] = weights @ ASSIGN
    return np.clip(out, 1e-8, 1-1e-8)

def weights(g):
    dep = np.char.startswith(g, 'DEP')
    return np.where(dep, .5/dep.sum(), .5/(~dep).sum())*len(g)

def contexts(x, keys):
    out = np.empty((len(x), x.shape[1]*2))
    for k in np.unique(keys):
        rr = np.flatnonzero(keys == k); a = x[rr].astype(float)
        mean = a.mean(0); mean -= mean.mean()
        out[rr] = np.r_[mean, np.log(np.maximum(a.std(0), .05))]
    return out

class Context:
    def fit(self, d, tr):
        self.training_subjects = np.unique(d['g'][tr]).tolist()
        x = d['context'][tr]
        means = np.stack([x[d['g'][tr] == s].mean(0) for s in self.training_subjects])
        self.scaler = StandardScaler().fit(means)
        self.pca = PCA(n_components=6, svd_solver='full').fit(self.scaler.transform(means))
        self.scale = max(np.mean(self.pca.transform(self.scaler.transform(means))**2), .01)**.5
        return self
    def predict(self, d, ix):
        return self.pca.transform(self.scaler.transform(d['context'][ix]))/self.scale

class ContextLogistic:
    def __init__(self, normalization='z', objective='conditional', alpha=3.):
        self.normalization=normalization;self.objective=objective;self.alpha=alpha
    def matrix(self, d, ix):
        return d['de_'+self.normalization][ix]
    def fit(self, d, tr):
        self.training_subjects=np.unique(d['g'][tr]).tolist()
        order=np.argsort(d['keys'][tr],kind='stable');tr=np.asarray(tr)[order]
        w=weights(d['g'][tr]);w/=w.sum();gw=w.reshape(-1,8).sum(1)
        self.scaler=StandardScaler().fit(self.matrix(d,tr),sample_weight=w)
        x=self.scaler.transform(self.matrix(d,tr));self.context=Context().fit(d,tr)
        c=self.context.predict(d,tr);self.cs=StandardScaler().fit(c,sample_weight=w);c=self.cs.transform(c)
        xx=np.c_[x,(x[:,:,None]*c[:,None,:]).reshape(len(x),-1)]
        alpha=np.r_[np.full(x.shape[1],.03),np.full(xx.shape[1]-x.shape[1],self.alpha)]
        y=d['y'][tr].astype(float);assert np.all(y.reshape(-1,8).sum(1)==4)
        def objective(coef):
            z=xx@coef
            if self.objective=='conditional':
                zz=z.reshape(-1,8);energy=zz@ASSIGN.T
                pp=np.exp(energy-logsumexp(energy,axis=1,keepdims=True))
                loss=np.dot(gw,logsumexp(energy,axis=1)-(zz*y.reshape(-1,8)).sum(1))/4
                grad=((pp@ASSIGN-y.reshape(-1,8))*gw[:,None]/4).ravel()
            else:loss=np.dot(w,np.logaddexp(0,z)-y*z);grad=w*(expit(z)-y)
            return float(loss+.5*np.dot(alpha*coef,coef)),xx.T@grad+alpha*coef
        result=minimize(objective,np.zeros(xx.shape[1]),jac=True,method='L-BFGS-B',options=dict(maxiter=400,ftol=1e-11,gtol=1e-7))
        assert result.success or abs(result.jac).max()<1e-5,(result.message,abs(result.jac).max())
        self.coef=result.x;self.optimization=dict(loss=float(result.fun),gradient_max=float(abs(result.jac).max()),iterations=int(result.nit))
        return self
    def predict(self,d,ix):
        x=self.scaler.transform(self.matrix(d,ix));c=self.cs.transform(self.context.predict(d,ix))
        return group_transform((np.c_[x,(x[:,:,None]*c[:,None,:]).reshape(len(x),-1)]@self.coef)[:,None],d['keys'][ix]).ravel()

class ContextKernel:
    def __init__(self,feature='de_z',beta=.3,C=1.,crops=None):
        self.feature=feature;self.beta=beta;self.C=C;self.crops=crops
    def kernel(self,x,c):
        return (x@self.tx.T/x.shape[1])*(1+self.beta*rbf_kernel(c,self.tc,gamma=1/c.shape[1]))
    def fit(self,d,tr):
        tr=np.asarray(tr);self.training_subjects=np.unique(d['g'][tr]).tolist()
        self.context=Context().fit(d,tr)
        if self.crops is not None:tr=tr[np.isin(d['crop'][tr],self.crops)]
        w=weights(d['g'][tr]);x=d[self.feature][tr]
        self.scaler=StandardScaler().fit(x,sample_weight=w);x=self.scaler.transform(x)
        self.pca=PCA(n_components=min(128,len(tr)-1,x.shape[1]),svd_solver='randomized',random_state=88031).fit(x*np.sqrt(w[:,None]))
        x=self.pca.transform(x);self.scale=max(np.mean(x*x),.01)**.5;self.tx=x/self.scale
        c=self.context.predict(d,tr);self.cs=StandardScaler().fit(c,sample_weight=w);self.tc=self.cs.transform(c)
        C=self.C if self.crops is None else self.C*5/len(self.crops)
        self.model=SVC(C=C,kernel='precomputed',cache_size=128).fit(self.kernel(self.tx,self.tc),d['y'][tr],sample_weight=w)
        return self
    def predict(self,d,ix):
        x=self.pca.transform(self.scaler.transform(d[self.feature][ix]))/self.scale
        c=self.cs.transform(self.context.predict(d,ix));z=self.model.decision_function(self.kernel(x,c))
        return group_transform(z[:,None],d['keys'][ix]).ravel()

def rank_design(p,keys,scales=None):
    z=np.clip(logit(np.clip(p,1e-6,1-1e-6)),-10,10).T
    if scales is None:scales=np.maximum(z.std(0),.25)
    z=z/scales;std=np.empty_like(z)
    for k in np.unique(keys):
        rr=np.flatnonzero(keys==k);assert len(rr)==8;std[rr]=z[rr].std(0)
    return np.c_[z,std],scales

class ContextRank:
    def __init__(self,context=True,members=1):self.use_context=context;self.members=members
    def fit(self,d,tr,p):
        self.training_subjects=np.unique(d['g'][tr]).tolist();self.models=[]
        rng=np.random.default_rng(46031);g=d['g'][tr];ids=np.unique(g)
        for member in range(self.members):
            selected=ids
            if self.members>1:
                selected=np.concatenate([rng.choice(v,max(4,int(np.ceil(.8*len(v)))),replace=False) for v in [ids[np.char.startswith(ids,'HC')],ids[np.char.startswith(ids,'DEP')]]])
            rr=np.flatnonzero(np.isin(g,selected));ix=tr[rr];xx,scales=rank_design(p[:,rr],d['keys'][ix])
            context=None
            if self.use_context:context=Context().fit(d,ix);xx=np.c_[xx,context.predict(d,ix)]
            y=d['y'][ix];gg=d['g'][ix];keys=d['keys'][ix];w=weights(gg)
            pos=np.flatnonzero(y==1);neg=np.flatnonzero(y==0);rngpair=np.random.default_rng(22031)
            pp=[];nn=[]
            while sum(map(len,pp))<100000:
                a=rngpair.choice(pos,110000,p=w[pos]/w[pos].sum());b=rngpair.choice(neg,110000,p=w[neg]/w[neg].sum());ok=gg[a]!=gg[b];pp.append(a[ok]);nn.append(b[ok])
            pairs=np.c_[np.concatenate(pp)[:100000],np.concatenate(nn)[:100000]];pw=np.full(len(pairs),.9/len(pairs));within=[];ww=[]
            for k in np.unique(keys):
                rrk=np.flatnonzero(keys==k);a=rrk[y[rrk]==1];b=rrk[y[rrk]==0]
                within.extend(itertools.product(a,b));ww.extend([.1*w[rrk[0]]/w.sum()/2]*16)
            pairs=np.r_[pairs,np.array(within,dtype=int)];pw=np.r_[pw,ww];pw*=len(pw)/pw.sum()
            model=CatBoostRanker(iterations=400,depth=2,learning_rate=.03,l2_leaf_reg=1000.,loss_function='PairLogitPairwise',bootstrap_type='Bernoulli',subsample=.8,random_strength=0,thread_count=1,random_seed=22031+37*member,verbose=False,allow_writing_files=False)
            model.fit(xx,y,group_id=np.zeros(len(y),int),pairs=pairs,pairs_weight=pw)
            score=group_transform(model.predict(xx)[:,None],keys).ravel();scale=max(score.std(),.1)
            self.models.append(dict(model=model,scales=scales,context=context,scale=scale,subjects=selected.tolist()))
        return self
    def predict(self,d,ix,p):
        result=[]
        for m in self.models:
            x,_=rank_design(p,d['keys'][ix],m['scales'])
            if m['context'] is not None:x=np.c_[x,m['context'].predict(d,ix)]
            z=group_transform(m['model'].predict(x)[:,None],d['keys'][ix]).ravel()/m['scale'];result.append(posterior(z,d['keys'][ix]))
        return np.mean(result,axis=0)
