"""Signal-quality-controlled companion; retain all60 people in evaluation.

Median band RMS <1e-5 in the original training amplitude units identifies
numerical-residue recordings. Never remove their validation rows: emit0.5.
Same rule applied to old and new models, not a favorable subset score.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from datetime import datetime
import json,time,numpy as np,joblib
from threadpoolctl import threadpool_limits
import run_v279_transfer as r

def main():
    limits=threadpool_limits(limits=1);d,split,anchor,rep=r.load()
    import run_group_auc as raw
    x,y,g,s=raw.load();assert np.array_equal(g,d['g'])
    band_rms=np.exp(np.median(x['absolute_de']-.5*np.log(2*np.pi*np.e),axis=1));good=band_rms>=1e-5
    keys=d['keys'];original=Path(Path('CURRENT_V279_TRANSFER_CONTEXT.txt').read_text().strip())
    assert json.loads((original/'verification.json').read_text())['checks_passed']
    out=r.ROOT/'runs'/('v279_quality_transfer_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'));out.mkdir()
    (r.ROOT/'CURRENT_V279_QUALITY_TRANSFER.txt').write_text(str(out))
    r.save(out/'plan.json',dict(primary='inner_selected_fusion',rms_threshold=1e-5,criterion='Median of180 bandRMS estimated by invertible absoluteDE; original amplitude units. Source-only quality discovery, no target signal inspected.',invalid_prediction=.5,invalid_training_excluded=True,validation_rows_never_dropped=True,source='v279 supplied quality screening idea plus matched newly fitted context/time experts',scripts_sha256={p:r.digest(r.ROOT/p) for p in ['run_v279_quality_transfer.py','run_v279_transfer.py','v279_transfer_models.py']},low_signal_people=np.unique(g[~good]).tolist(),not_fresh_validation=True,holdout_not_loaded=split['holdout'],official_test_loaded=False,submissions_performed=False))
    pred={};records=[];reload_delta=0.;permutation_error=0.;count=np.zeros(len(y),int)
    clean={k:v for k,v in d.items() if k not in ['y','g','crop']}
    def fit(tr,va,name,path):
        nonlocal reload_delta,permutation_error
        tr=tr[good[tr]];q=r.fit_predict(d,tr,va,r.CONFIGS[name],path);q[~good[va]]=.5
        reload=[];perm=np.random.default_rng(27).permutation(len(va));permuted=[]
        for model in joblib.load(path):
            assert set(model.training_subjects)==set(g[tr]);assert set(g[tr]).isdisjoint(g[va]) and set(g[tr]).isdisjoint(split['holdout'])
            reload.append(r.m.posterior(model.predict(clean,va),keys[va]));permuted.append(r.m.posterior(model.predict(clean,va[perm]),keys[va[perm]]))
        q2=np.mean(reload,axis=0);qp=np.mean(permuted,axis=0);q2[~good[va]]=.5;qp[~good[va[perm]]]=.5
        reload_delta=max(reload_delta,float(abs(q-q2).max()));permutation_error=max(permutation_error,float(abs(q[perm]-qp).max()))
        return q
    for fold,(aa,bb) in enumerate(r.cal.r.r.base.folds(split['development']),1):
        start=time.time();tr=np.flatnonzero(np.isin(g,aa));va=np.flatnonzero(np.isin(g,bb));count[va]+=1
        inner=[(np.flatnonzero(np.isin(g,a)),np.flatnonzero(np.isin(g,b))) for a,b in r.cal.r.r.base.folds(aa,n=3)]
        ii=np.concatenate([b for _,b in inner]);iy=y[ii];ig=g[ii];ik=keys[ii];_,gg,ip=r.cal.source(fold);assert np.array_equal(gg,ig);ip=ip.copy();ip[~good[ii]]=.5
        def objective(p):return float(np.mean([r.boot.evaluation(iy[np.isin(ig,b)],p[np.isin(ig,b)],ig[np.isin(ig,b)],ik[np.isin(ig,b)])['auc'] for _,b in r.cal.r.r.base.folds(aa,n=3)]))
        rows=[dict(model='baseline',blend=0.,score=objective(ip))];outputs={};source={}
        for name in r.CONFIGS:
            pp=[fit(a,b,name,out/f'fold{fold}_inner{j}_{name}.joblib') for j,(a,b) in enumerate(inner)];p=np.concatenate(pp);source[name]=p
            outputs[name]=fit(tr,va,name,out/f'fold{fold}_{name}.joblib')
            for blend in [.1,.25,.5,1.]:rows.append(dict(model=name,blend=blend,score=objective((1-blend)*ip+blend*p)))
        c=max(rows,key=lambda z:z['score']);ap=anchor[va].copy();ap[~good[va]]=.5
        outputs['inner_selected_fusion']=ap if c['model']=='baseline' else (1-c['blend'])*ap+c['blend']*outputs[c['model']]
        for name,p in outputs.items():
            if name not in pred:pred[name]=np.full(len(y),np.nan)
            pred[name][va]=p
        record=dict(fold=fold,source_people=aa.tolist(),validation_people=bb.tolist(),excluded_source_people=np.unique(g[tr[~good[tr]]]).tolist(),choice=c,candidates=rows)
        records.append(record);r.save(out/f'fold{fold}.json',record);np.savez_compressed(out/f'fold{fold}_inner.npz',labels=iy,subjects=ig,baseline_probability=ip,**source);np.savez_compressed(out/f'fold{fold}_outer.npz',validation_indices=va,**outputs)
        print('QUALITY TRANSFER FOLD',fold,c,round(time.time()-start,1),flush=True)
    assert np.all(count==1)
    qc_anchor=anchor.copy();qc_anchor[~good]=.5;fixed=r.cal.transform(anchor,keys,'posterior',1.);fixed[~good]=.5
    with np.load(original/'inner_selected_fusion_oof.npz') as a:old_context=a['probability'];old_context_qc=old_context.copy();old_context_qc[~good]=.5
    pred.update(baseline=anchor,quality_baseline=qc_anchor,fixed4_quality_baseline=fixed,previous_context=old_context,previous_context_quality=old_context_qc)
    summary=dict(folds=records)
    for name,p in pred.items():
        summary[name]=r.cal.r.summarize(y,p,g,keys,rep);np.savez_compressed(out/(name+'_oof.npz'),labels=y,subjects=g,group_ids=keys,representative=rep,probability=p)
    r.save(out/'summary.json',summary);r.save(out/'bootstrap.json',{name:r.boot.compare(y,p,qc_anchor,g,rep,keys) for name,p in pred.items() if name in ['inner_selected_fusion','previous_context_quality']})
    assert reload_delta<1e-9 and permutation_error<1e-8
    r.save(out/'verification.json',dict(checks_passed=True,source_sets_verified=True,all_inner_outer_models_reloaded=True,max_reload_delta=reload_delta,max_permutation_error=permutation_error,all60_people_and2400_rows_evaluated=True,query_labels_diagnosis_and_subject_ids_absent=True,provided_69person_weights_loaded=False,holdout_loaded=False,public_test_loaded=False,submissions_performed=False))
    print('QUALITY TRANSFER COMPLETE',out,flush=True)
if __name__=='__main__':main()
