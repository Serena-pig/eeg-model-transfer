"""Reuse only hash-verified public CBraMod pretraining, never69-person classifiers."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import io,json,hashlib,importlib.util,time
from zipfile import ZipFile
import numpy as np,h5py,torch
from scipy.signal import butter,sosfiltfilt,resample_poly
ROOT=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    torch.set_num_threads(1);torch.manual_seed(42);torch.use_deterministic_algorithms(True)
    path=ROOT/'incoming_v279/EEG_AUC_v279_20261025/scripts/cbramod_features_v5.py'
    spec=importlib.util.spec_from_file_location('verified_cbra_source',path);lib=importlib.util.module_from_spec(spec);spec.loader.exec_module(lib)
    split=json.loads((ROOT/'cache/splits.json').read_text());allowed=set(split['development']);assert allowed.isdisjoint(split['holdout'])
    expected=json.loads((ROOT/'feature_ablation/development/manifest.json').read_text())['subjects'];entries={}
    for p in (ROOT/'raw_training').glob('*.zip'):
        with ZipFile(p) as z:
            for name in z.namelist():
                s=Path(name).stem
                if name.endswith('.mat') and s in allowed:assert s not in entries;entries[s]=(p,name)
    assert set(entries)==allowed
    backbone=lib.FrozenCBraMod(device='cpu',channel_mode='pretrain19');out=ROOT/'foundation_features/v279_cbramod/development';out.mkdir(parents=True,exist_ok=True)
    plan=dict(source_only=True,development_subjects=split['development'],holdout_not_loaded=split['holdout'],official_test_loaded=False,checkpoint_sha256=lib.WEIGHT_SHA256,script_sha256=sha(__file__),provided_loader_sha256=sha(path),channels=lib.PRETRAIN19,frozen=True,source_model_parameters=backbone.audit['parameter_count'],preprocessing='Original250Hz30ch float32 -> selected19common-average rereference; perrecordDC;1-45Hz4thorderbandpass;250to200polyphase; channelRMS from own8trials only;10x200patches; lastlayer mean time19x200 and channelmean200. This is an adaptation, not exact v279125Hz-cache preprocessing.',source_69person_classifier_loaded=False,files={})
    manifest=out/'manifest.json'
    if manifest.exists():
        old=json.loads(manifest.read_text());assert all(old[k]==v for k,v in plan.items() if k!='files');plan['files']=old['files']
    ix=np.array([lib.CHANNELS.index(c) for c in lib.PRETRAIN19]);start=time.time()
    for s in split['development']:
        p=out/(s+'.npz')
        if s in plan['files']:assert sha(p)==plan['files'][s];continue
        zp,name=entries[s]
        with ZipFile(zp) as z:raw=z.read(name)
        assert hashlib.sha256(raw).hexdigest()==expected[s];parts=[]
        with h5py.File(io.BytesIO(raw)) as f:
            for key in ['EEG_data_neu','EEG_data_pos']:
                a=np.asarray(f[key],dtype='float32');a=a.T if a.shape==(30,50000) else a;assert a.shape==(50000,30)
                for video in range(4):parts.append(a[video*12500:(video+1)*12500].T.reshape(30,5,2500).transpose(1,0,2))
        x=np.concatenate(parts)[:,ix].astype('float64');x-=x.mean(1,keepdims=True);x-=x.mean(-1,keepdims=True)
        x=sosfiltfilt(butter(4,[1,45],fs=250,btype='bandpass',output='sos'),x,axis=-1);x=resample_poly(x,4,5,axis=-1)
        for crop in range(5):
            rr=np.arange(crop,40,5);rms=np.sqrt(np.mean(x[rr]**2,axis=(0,2),keepdims=True)).clip(1e-8);x[rr]/=rms
        features=[]
        with torch.inference_mode():
            for a in range(0,40,4):
                h=backbone.model(torch.from_numpy(x[a:a+4].astype('float32').reshape(-1,19,10,200)))
                assert tuple(h.shape)==(4,19,10,200);features.append(h.mean(2).numpy())
        features=np.concatenate(features);assert np.isfinite(features).all()
        np.savez_compressed(p,flat=features.reshape(40,-1),global_mean=features.mean(1),raw_sha256=np.array(expected[s]))
        plan['files'][s]=sha(p);manifest.write_text(json.dumps(plan,indent=2));print('CBRAMOD NEW SOURCE',s,len(plan['files']),'/60',round(time.time()-start,1),flush=True)
    plan['complete']=True;manifest.write_text(json.dumps(plan,indent=2));print('CBRAMOD COMPLETE',out,flush=True)
if __name__=='__main__':main()
