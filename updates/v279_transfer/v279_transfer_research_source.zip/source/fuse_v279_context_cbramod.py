"""Source-only, fixed constrained fusion of two new method families."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from datetime import datetime
import json,numpy as np
from scipy.special import expit
from threadpoolctl import threadpool_limits
import run_v279_transfer as r
import fuse_reference_bendr as opt

def main():
    limits=threadpool_limits(limits=1);d,split,anchor,rep=r.load();g=d['g'];y=d['y'];keys=d['keys'];folders={name:Path((r.ROOT/p).read_text().strip()) for name,p in [('context','CURRENT_V279_QUALITY_TRANSFER.txt'),('cbramod','CURRENT_V279_CBRAMOD_HEADS.txt')]}
    assert all(json.loads((p/'verification.json').read_text())['checks_passed'] for p in folders.values());out=r.ROOT/'runs'/('v279_context_cbramod_fusion_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'));out.mkdir();(r.ROOT/'CURRENT_V279_CONTEXT_CBRAMOD_FUSION.txt').write_text(str(out));r.save(out/'plan.json',dict(primary='person_bagged',families={k:v.name for k,v in folders.items()},source_pure_choice='Highest mean source-inner50/50pooled AUC, no query labels used',max_each=.5,max_total=.75,bags=12,regularizer=.1,script_sha256=r.digest(__file__),holdout_not_loaded=split['holdout'],official_test_loaded=False,submissions_performed=False,not_fresh_validation=True))
    import run_group_auc as raw
    x,_,_,_=raw.load();good=np.exp(np.median(x['absolute_de']-.5*np.log(2*np.pi*np.e),axis=1))>=1e-5;quality=anchor.copy();quality[~good]=.5;pred={n:np.full(len(y),np.nan) for n in ['person_bagged','pairwise']};recs=[];replay=0.
    for fold,(aa,bb) in enumerate(r.cal.r.r.base.folds(split['development']),1):
        va=np.isin(g,bb);cols=[];outer=[];choices={};ig=None
        for name,p in folders.items():
            rec=json.loads((p/f'fold{fold}.json').read_text());rows=rec.get('candidates');choice=max([z for z in rows if z['blend']==1.],key=lambda z:z['score']);choices[name]=choice
            with np.load(p/f'fold{fold}_inner.npz') as a:
                if ig is None:iy=a['labels'];ig=a['subjects'];ip=a['baseline_probability']
                else:assert np.array_equal(iy,a['labels']) and np.array_equal(ig,a['subjects']) and np.array_equal(ip,a['baseline_probability'])
                cols.append(a[choice['model']])
            with np.load(p/f'fold{fold}_outer.npz') as a:outer.append(a[choice['model']])
        assert set(ig)==set(aa) and set(ig).isdisjoint(bb);fun,ids=opt.problem(iy,ig,ip,cols);rng=np.random.default_rng(20261027+fold);counts=[np.ones(len(ids))]
        for _ in range(12):
            cnt=np.zeros(len(ids))
            for mask in [np.char.startswith(ids,'HC'),np.char.startswith(ids,'DEP')]:
                ix=np.flatnonzero(mask);cnt+=np.bincount(rng.choice(ix,len(ix),replace=True),minlength=len(ids))
            counts.append(cnt)
        fits=[opt.solve(fun,c,2) for c in counts];coeff=dict(pairwise=np.array(fits[0]['coeff']),person_bagged=np.mean([f['coeff'] for f in fits[1:]],axis=0));z=opt.stack.score(quality[va]);delta=np.column_stack([opt.stack.score(p)-z for p in outer])
        for name,c in coeff.items():pred[name][va]=expit(z+delta@c)
        rec=dict(fold=fold,training_subjects=aa.tolist(),validation_subjects=bb.tolist(),choices=choices,fits=fits,coefficients={k:v.tolist() for k,v in coeff.items()});recs.append(rec);r.save(out/f'fold{fold}.json',rec);np.savez_compressed(out/f'fold{fold}_replay.npz',validation_indices=np.flatnonzero(va),prior=quality[va],components=np.array(outer));print('CBRA CONTEXT FUSION',fold,rec['coefficients'],flush=True)
    summary=dict(folds=recs)
    for name,p in {**pred,'baseline':anchor,'quality_baseline':quality}.items():summary[name]=r.cal.r.summarize(y,p,g,keys,rep);np.savez_compressed(out/(name+'_oof.npz'),labels=y,subjects=g,group_ids=keys,representative=rep,probability=p)
    r.save(out/'summary.json',summary);r.save(out/'bootstrap.json',{name:r.boot.compare(y,p,quality,g,rep,keys) for name,p in pred.items()})
    for fold in range(1,6):
        rec=json.loads((out/f'fold{fold}.json').read_text())
        with np.load(out/f'fold{fold}_replay.npz') as a:
            z=opt.stack.score(a['prior']);delta=np.column_stack([opt.stack.score(p)-z for p in a['components']])
            for name,c in rec['coefficients'].items():replay=max(replay,float(abs(expit(z+delta@c)-pred[name][a['validation_indices']]).max()))
    assert replay<1e-12;r.save(out/'verification.json',dict(checks_passed=True,max_prediction_delta=replay,source_only_fusion_coefficients=True,provided69person_heads_loaded=False,holdout_loaded=False,official_test_loaded=False,submissions_performed=False,not_fresh_validation=True));print('CBRA CONTEXT FUSION COMPLETE',out,flush=True)
if __name__=='__main__':main()
