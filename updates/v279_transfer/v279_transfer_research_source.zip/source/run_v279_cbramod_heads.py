"""Frozen supplied public CBraMod; new fold-local heads and source-only fusion."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from datetime import datetime
import json,time,numpy as np,joblib
from scipy.special import expit
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from threadpoolctl import threadpool_limits
import run_v279_transfer as r

FEATURES=['flat_center','flat_z','global_z']
HEADS=[('rbf',.3),('rbf',3.),('linear',.03),('linear',.3)]

def main():
    limits=threadpool_limits(limits=1);d,split,anchor,rep=r.load();g=d['g'];y=d['y'];keys=d['keys'];source=r.ROOT/'foundation_features/v279_cbramod/development';manifest=json.loads((source/'manifest.json').read_text());assert manifest['complete'] and manifest['development_subjects']==split['development']
    flat=[];glob=[]
    for s in split['development']:
        p=source/(s+'.npz');assert r.digest(p)==manifest['files'][s]
        with np.load(p) as a:flat.append(a['flat']);glob.append(a['global_mean'])
    flat=np.concatenate(flat);glob=np.concatenate(glob);x=dict(flat_center=r.m.group_transform(flat,keys),flat_z=r.m.group_transform(flat,keys,'z'),global_z=r.m.group_transform(glob,keys,'z'))
    import run_group_auc as raw
    original,_,_,_=raw.load();good=np.exp(np.median(original['absolute_de']-.5*np.log(2*np.pi*np.e),axis=1))>=1e-5
    out=r.ROOT/'runs'/('v279_cbramod_heads_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'));out.mkdir();(r.ROOT/'CURRENT_V279_CBRAMOD_HEADS.txt').write_text(str(out))
    r.save(out/'plan.json',dict(primary='inner_selected_fusion',features=FEATURES,heads=HEADS,pretrained_feature_manifest=manifest,encoder_frozen=True,provided69person_heads_loaded=False,training_objective='Source clinical-balanced BCE LR or RBF-SVM; source-only PCA64 + DEresidual. Source-fitted score scale, fixed4posterior.',source_quality='Exclude near numerical residue from fitting, emit0.5, retain all validation rows.',source_scaler='ClinicalbalancedStandardScaler/PCA64 on standardized embeddings; source-variance normalization; concatenate source-standardized DE180 weighted sqrt64/180*.5.',script_sha256=r.digest(__file__),quality_rule=1e-5,holdout_not_loaded=split['holdout'],official_test_loaded=False,submissions_performed=False,not_fresh_validation=True))
    def fitted(tr,va,tag):
        train=tr[good[tr]];assert set(g[train]).isdisjoint(g[va]);ww=r.m.weights(g[train]);result={};de=StandardScaler().fit(d['de_z'][train],sample_weight=ww);dt=de.transform(d['de_z'][train]);dv=de.transform(d['de_z'][va])
        for feature in FEATURES:
            scaler=StandardScaler().fit(x[feature][train],sample_weight=ww);xt=scaler.transform(x[feature][train]);xv=scaler.transform(x[feature][va]);pca=PCA(n_components=64,svd_solver='randomized',random_state=27931).fit(xt*np.sqrt(ww[:,None]));xt=pca.transform(xt);xv=pca.transform(xv);scale=max(np.mean(xt*xt),.01)**.5;xt=np.c_[xt/scale,dt*np.sqrt(64/180)*.5];xv=np.c_[xv/scale,dv*np.sqrt(64/180)*.5]
            for kind,C in HEADS:
                name=feature+'_'+kind+'_'+str(C);model=SVC(C=C,kernel='rbf',cache_size=128) if kind=='rbf' else LogisticRegression(C=C,fit_intercept=False,max_iter=2000,solver='lbfgs',random_state=27931);model.fit(xt,y[train],sample_weight=ww);s=max(float(model.decision_function(xt).std()),.1);q=r.m.posterior(model.decision_function(xv)/s,keys[va]);q[~good[va]]=.5;result[name]=q
                path=out/(tag+'_'+name+'.joblib');joblib.dump(dict(model=model,scaler=scaler,pca=pca,scale=scale,de_scaler=de,score_scale=s,feature=feature,training_subjects=np.unique(g[train]).tolist()),path,compress=3)
        return result
    pred={};counts=np.zeros(len(y),int);records=[]
    for fold,(aa,bb) in enumerate(r.cal.r.r.base.folds(split['development']),1):
        t=time.time();tr=np.flatnonzero(np.isin(g,aa));va=np.flatnonzero(np.isin(g,bb));counts[va]+=1;inner=[(np.flatnonzero(np.isin(g,a)),np.flatnonzero(np.isin(g,b))) for a,b in r.cal.r.r.base.folds(aa,n=3)];ii=np.concatenate([b for _,b in inner]);iy=y[ii];ig=g[ii];ik=keys[ii];_,gg,ip=r.cal.source(fold);assert np.array_equal(gg,ig);ip=ip.copy();ip[~good[ii]]=.5
        parts=[fitted(a,b,f'fold{fold}_inner{j}') for j,(a,b) in enumerate(inner)];outputs=fitted(tr,va,f'fold{fold}_outer');sourcep={name:np.concatenate([v[name] for v in parts]) for name in parts[0]}
        def objective(p):return float(np.mean([r.boot.evaluation(iy[np.isin(ig,b)],p[np.isin(ig,b)],ig[np.isin(ig,b)],ik[np.isin(ig,b)])['auc'] for _,b in r.cal.r.r.base.folds(aa,n=3)]))
        rows=[dict(model='baseline',blend=0.,score=objective(ip))]
        for name,p in sourcep.items():
            for blend in [.1,.25,.5,1.]:rows.append(dict(model=name,blend=blend,score=objective((1-blend)*ip+blend*p)))
        c=max(rows,key=lambda v:v['score']);pure=max([v for v in rows if v['blend']==1.],key=lambda v:v['score']);base=anchor[va].copy();base[~good[va]]=.5;outputs['pure_selected']=outputs[pure['model']];outputs['inner_selected_fusion']=base if c['model']=='baseline' else (1-c['blend'])*base+c['blend']*outputs[c['model']]
        for name,p in outputs.items():
            if name not in pred:pred[name]=np.full(len(y),np.nan)
            pred[name][va]=p
        record=dict(fold=fold,training_subjects=aa.tolist(),validation_subjects=bb.tolist(),choice=c,pure_choice=pure,candidates=rows);records.append(record);r.save(out/f'fold{fold}.json',record);np.savez_compressed(out/f'fold{fold}_inner.npz',labels=iy,subjects=ig,baseline_probability=ip,**sourcep);np.savez_compressed(out/f'fold{fold}_outer.npz',validation_indices=va,**outputs);print('CBRAMOD HEAD FOLD',fold,c,'seconds',round(time.time()-t,1),flush=True)
    assert np.all(counts==1);quality=anchor.copy();quality[~good]=.5;pred.update(baseline=anchor,quality_baseline=quality);summary=dict(folds=records)
    for name,p in pred.items():summary[name]=r.cal.r.summarize(y,p,g,keys,rep);np.savez_compressed(out/(name+'_oof.npz'),labels=y,subjects=g,group_ids=keys,representative=rep,probability=p)
    r.save(out/'summary.json',summary);r.save(out/'bootstrap.json',{name:r.boot.compare(y,p,quality,g,rep,keys) for name,p in pred.items() if name in ['pure_selected','inner_selected_fusion']});print('CBRAMOD HEAD COMPLETE',out,flush=True)
if __name__=='__main__':main()
