"""Record actual completed results; never assign an AUC to partial folds."""
from pathlib import Path
import json
import run_v279_transfer as r

def main():
    folders={name:Path((r.ROOT/p).read_text().strip()) for name,p in [('context','CURRENT_V279_TRANSFER_CONTEXT.txt'),('quality','CURRENT_V279_QUALITY_TRANSFER.txt'),('cbramod','CURRENT_V279_CBRAMOD_HEADS.txt'),('fusion','CURRENT_V279_CONTEXT_CBRAMOD_FUSION.txt'),('rank','CURRENT_V279_TRANSFER_RANK.txt')]}
    rows=[];states={}
    for family,folder in folders.items():
        verified=(folder/'verification.json').exists() and json.loads((folder/'verification.json').read_text())['checks_passed'];states[family]=dict(folder=str(folder),completed_outer_folds=sum((folder/f'fold{j}.json').exists() for j in range(1,6)),verified=verified)
        if not verified:continue
        summary=json.loads((folder/'summary.json').read_text());wanted=dict(context=['baseline','inner_selected_fusion'],quality=['quality_baseline','inner_selected_fusion','previous_context_quality'],cbramod=['pure_selected','inner_selected_fusion'],fusion=['person_bagged'],rank=['plain','context','context_bag5'])[family]
        for name in wanted:
            a=summary[name]['all_windows'];rows.append(dict(family=family,policy=name,pooled=a['pooled']['auc'],weighted=a['balanced_50_50']['auc'],DEP=a['cohorts']['DEP']['auc']))
    table='\n'.join('|'+x['family']+'/'+x['policy']+'|'+f"{x['pooled']:.4%}|{x['weighted']:.4%}|{x['DEP']:.4%}|" for x in rows)
    text=f'''# v279 方法借鉴与同划分对照

用户反馈：v279第一次官方提交85分。包内82.96841821%是固定4外折、56人开发集的两组各半加权AUC均值，不是分类准确率，也不是官方成绩。报告中的新实验使用原60人5外折/3内折；不同划分的数字不能直接比较。

|实验/策略|2400条合并AUC|两组各半加权合并AUC|抑郁症组AUC|
|---|---:|---:|---:|
{table}

本轮主要候选为quality/inner_selected_fusion，82.951875%原始合并AUC、80.936953%两组各半加权AUC、74.110000%DEP AUC。相比同样做质量处理的旧模型，原始合并AUC增加0.4780个百分点。质量规则只在源训练信号确定，验证行不删除，数值残差记录回到0.5。整人bootstrap95%区间跨零，且没有校正长期反复开发/多模型选择，不能视为新的独立确认。

更接近官方5HC+5DEP、每人8段的内部期望80条合并AUC代理：原方案80.029196%，同质量处理基线80.122775%，新候选80.691803%。固定预声明的每人8段子集加权AUC：原方案77.766602%，质量基线78.409180%，新候选79.018555%。这些是开发集代理，不是公测80条真值成绩。

已借鉴并完成：生理上下文PCA与条件逻辑回归、正半定上下文积核、9个源时间片专家固定平均、质量筛查、公开CBraMod编码器新分类头、上下文/CBraMod约束融合。单独时间专家、冻结CBraMod及其融合均没有超过上述上下文候选，因此未强行替换。更昂贵的400树/10万配对上下文排序器状态见下表；未完成时不报告其AUC。

|实验|已完成外折|完整重载复核|
|---|---:|---|
'''+ '\n'.join(f"|{k}|{v['completed_outer_folds']}/5|{v['verified']}|" for k,v in states.items())+'''

提供的v279最终104个分类器训练过69人，包含本工作区封存人群，不能拿它们给开发被试打分来宣称泛化提升。此次借鉴重训代码方法；CBraMod仅复用哈希锁定公开预训练参数，未载入69人竞赛分类头。用户提供的外层/内层预测缓存仍未在推理包里找到，两个完整模型的同划分融合尚未完成。需要缓存追溯或按同一划分重训，不能用官方85分反推测试标签/调融合权重。

可用附加包仅用于原私有GitHub EEG_BEST_AUC_20261025完整模型；不是v279官方85分原包的直接补丁。新模块导出2400条开发预测复核误差0，顺序置换误差<2e-15；6人原始MAT特征重放误差<4.7e-14；原包兼容的80行源数据格式端到端测试通过。源数据格式测试不是科学验证。

没有读取本轮公开测试信号或封存10人，没有访问比赛提交接口，没有代交。官方85分原包及私有仓库main保持不变。新候选尚无官方AUC；冻结5外折模型部署平均也没有额外独立验证分数。
'''
    path=Path('/workspace/output/EEG_v279_transfer_report.md');path.write_text(text);r.save(r.ROOT/'V279_TRANSFER_STATUS.json',dict(user_reported_official_auc=.85,official_result_for='user-supplied v279, not old GitHub main model',completed_results=rows,states=states,portable_candidate='quality/inner_selected_fusion',official_test_loaded=False,holdout_loaded=False,submissions_performed=False,new_official_auc_unknown=True))
    print(path)
if __name__=='__main__':main()
