"""Wait on the already running numerical experiment, then independently review."""
import time,subprocess,sys,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
folder=Path((ROOT/'CURRENT_V279_TRANSFER_RANK.txt').read_text().strip())
while not (folder/'summary.json').exists():
    running=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:cmd=(p/'cmdline').read_bytes()
        except (OSError,PermissionError):continue
        if b'run_v279_transfer.py\x00rank\x00' in cmd:running.append(p.name)
    if not running:raise RuntimeError('Ranking stopped before completion. Preserve partial files; no AUC.')
    done=sum((folder/f'fold{j}.json').exists() for j in range(1,6));print('RANKING IN PROGRESS',done,'/5',','.join(running),flush=True);time.sleep(30)
subprocess.run([sys.executable,str(ROOT/'review_v279_transfer.py'),str(folder)],cwd=ROOT,check=True)
subprocess.run([sys.executable,str(ROOT/'report_v279_transfer.py')],cwd=ROOT,check=True)
print('RANK COMPLETE AND VERIFIED',folder,flush=True)
