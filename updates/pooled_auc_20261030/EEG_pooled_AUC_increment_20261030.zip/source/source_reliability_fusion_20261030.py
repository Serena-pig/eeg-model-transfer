"""Add the clean-inner-selected aligned SPD expert to the frozen86 fusion.
No outer weight search: fit BCE and fixed.5conditional/BCE fusion using source
inner forecasts only, with inherited C=.01 and clinical interaction design.
"""
import os
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='1'
import json,traceback
import numpy as np,joblib
from scipy.special import expit,logsumexp,softmax
from scipy.optimize import minimize
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits
import driver
from context_rank_v34 import fit_context,context_features
from cached_fixed_fusion_20261030 import features
from common import batches,center
from select_ensemble import postprocess,ASSIGNMENTS
from inner_calibration_round import calibrate
from postflight import pair_matrix
OUT=driver.JOB/'source_reliability_fusion_20261030';OUT.mkdir(exist_ok=True)
def main():
 threadpool_limits(limits=1);p=driver.protocol();spec=dict(members=87,new_expert='Inner-selected alignedcovariance SVM',C_inherited=.01,models=['reliability_BCE87','reliability_conditional_BCE87'],training_clinical_weight='Actual frequencies preserved; each source person-class normalized',teacher_weight='Square root true-class probability from unfitted87 source-inner mean',teacher_uses_no_query_labels=True,conditional_mix_fixed=.5,new_expert_clinical_interaction=True,source_inner_weight_fit_only=True,calibration='Original source-inner policy inherited',base_deep_models_retrained=0,script_sha256=driver.sha(__file__))
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==spec
 else:driver.save(OUT/'protocol.json',spec)
 with np.load(driver.ART/'features.npz') as a:d={k:a[k] for k in ['subject','trial','crop','label','diagnosis','train','powers','quality']}
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:full={k:a[k] for k in a.files}
 with np.load(driver.JOB/'dualbranch_source_stack_20261028/clinical_stack_calibrated_oof.npz') as a:anchor=a['probability']
 baseix=np.r_[np.arange(83),np.arange(104,107)];names=['reliability_BCE87','reliability_conditional_BCE87'];out={n:anchor.copy() for n in names+[n+'_calibrated' for n in names]};audits=[]
 for f in p['folds']:
  with np.load(driver.JOB/f'cached_group_diagnostics_20261030/fold{f["fold"]}_aligned_banks.npz') as a:tr=a['inner_indices'];va=a['outer_indices'];ib=a['inner_probability'][baseix];ob=a['outer_probability'][baseix]
  lookup={v:j for j,v in enumerate(tr)};zin=np.zeros(len(tr));root=driver.JOB/'aligned_covariance_svm_20261030'
  for part in range(3):
   with np.load(root/f'fold{f["fold"]}_inner{part}.npz') as a:zin[[lookup[v] for v in a['validation']]]=a['logits']
  with np.load(root/f'fold{f["fold"]}_outer.npz') as a:assert np.array_equal(a['validation'],va);zout=a['logits']
  gin=batches(d)[tr];gout=batches(d)[va];zin=center(zin,gin);sd=max(float(zin.std()),.1);pin=postprocess(zin/sd,gin,'conditional',.6);pout=postprocess(center(zout,gout)/sd,gout,'conditional',.6);ib=np.vstack([ib,pin]);ob=np.vstack([ob,pout]);source=dict(d);source['label']=np.full_like(d['label'],-1);source['diagnosis']=np.full_like(d['diagnosis'],-1);source['diagnosis'][tr]=d['diagnosis'][tr];context,e=fit_context(source,tr);scaler=StandardScaler().fit(np.column_stack([features(ib,gin),e]));xx=scaler.transform(np.column_stack([features(ib,gin),e]));gx=np.column_stack([xx,.5*(2*e[:,6]-1)[:,None]*xx[:,[83,84,85,86]]]);blind=dict(d);blind['label']=np.full_like(d['label'],-1);blind['diagnosis']=np.full_like(d['diagnosis'],-1);ev=context_features(blind,va,context);xv=scaler.transform(np.column_stack([features(ob,gout),ev]));gv=np.column_stack([xv,.5*(2*ev[:,6]-1)[:,None]*xv[:,[83,84,85,86]]]);old=joblib.load(driver.JOB/f'dualbranch_source_stack_20261028/fold{f["fold"]}.joblib');oldraw=np.column_stack([features(ob[:86],gout),ev]);oldx=old['scaler'].transform(oldraw);oldgx=np.column_stack([oldx,.5*(2*ev[:,6]-1)[:,None]*oldx[:,[83,84,85]]]);mode=json.loads((driver.JOB/f'inner_calibration_20261028/fold{f["fold"]}_selection.json').read_text())['chosen'];qref=calibrate(old['models']['clinical_stack'][0].predict_proba(oldgx)[:,1],gout,mode);assert abs(qref-anchor[full['model_row_to_full_row'][va]]).max()<1e-9
  y=d['label'][tr];diag=d['diagnosis'][tr];w=np.ones(len(y))
  # Unit weight per record; each source subject contributes exactly40windows.
  # Training weighting only; outer metric and subject split unchanged.
  teacher=ib.mean(0);true_conf=np.where(y>0,teacher,1-teacher);w=np.sqrt(np.maximum(true_conf,.05))
  # Teacher is unfitted mean of genuinely source-inner-heldout base forecasts.
  # Preserve each training person's positive/negative total mass exactly.
  for person in np.unique(d['subject'][tr]):
   for label in (0,1):
    rrw=np.flatnonzero((d['subject'][tr]==person)&(y==label));w[rrw]*=len(rrw)/w[rrw].sum()
  assert np.isclose(w.sum(),len(w))
  model=LogisticRegression(C=.01,max_iter=2000).fit(gx,y,sample_weight=w);theta=np.r_[model.coef_[0],model.intercept_[0]];models={'reliability_BCE87':theta};rr=np.stack([np.flatnonzero(gin==g) for g in np.unique(gin)]);gw=w[rr].mean(1);gw/=gw.sum();wn=w/w.sum();reg=1/(.01*w.sum());A=ASSIGNMENTS
  def obj(theta):
   beta=theta[:-1];z=gx@beta+theta[-1];bce=np.dot(wn,np.logaddexp(0,z)-y*z);err=wn*(expit(z)-y);zz=z[rr];ss=zz@A.T;post=softmax(ss,axis=1);closs=np.dot(gw,(logsumexp(ss,axis=1)-(zz*y[rr]).sum(1))/8);ce=np.zeros(len(y));ce[rr.ravel()]=((post@A-y[rr])*gw[:,None]/8).ravel();grad=.5*err+.5*ce;return float(.5*bce+.5*closs+.5*reg*np.dot(beta,beta)),np.r_[gx.T@grad+reg*beta,grad.sum()]
  if f['fold']==1:
   grad=obj(theta)[1]
   for j in [0,len(theta)//2,len(theta)-1]:
    aa=theta.copy();bb=theta.copy();aa[j]+=1e-6;bb[j]-=1e-6;assert abs((obj(aa)[0]-obj(bb)[0])/2e-6-grad[j])<1e-5
  fit=minimize(obj,theta,jac=True,method='L-BFGS-B',options=dict(maxiter=1000,ftol=1e-12,gtol=1e-7));assert fit.success;models['reliability_conditional_BCE87']=fit.x;artifact=dict(models=models,scaler=scaler,context=context,SPD_source_scale=sd,source_subjects=f['training_subjects'],protocol=spec);path=OUT/f'fold{f["fold"]}.joblib';joblib.dump(artifact,path,compress=3);saved=joblib.load(path);per=np.random.default_rng(f['fold']).permutation(len(va))
  for name,theta in models.items():
   q=expit(gv@theta[:-1]+theta[-1]);t=saved['models'][name];replay=expit(gv[per]@t[:-1]+t[-1]);delta=float(abs(replay-q[per]).max());assert delta<1e-10;out[name][full['model_row_to_full_row'][va]]=np.round(q,12);out[name+'_calibrated'][full['model_row_to_full_row'][va]]=np.round(calibrate(q,gout,mode),12);audits.append(dict(fold=f['fold'],name=name,native_order_delta=delta,original_anchor_reconstructed=True))
  print('SOURCE RELIABILITY FUSION OUTER',f['fold'],'/5',flush=True)
 y=full['label'];g=full['subject'];dep=full['diagnosis']==1;ids=np.unique(g);ref=pair_matrix(y,anchor,g,ids);rng=np.random.default_rng(1030);counts=np.zeros((2000,len(ids)))
 for j in range(len(counts)):
  for mask in [np.char.startswith(ids,'DEP'),np.char.startswith(ids,'HC')]:
   ix=np.flatnonzero(mask);counts[j]+=np.bincount(rng.choice(ix,len(ix),replace=True),minlength=len(ids))
 results={}
 for name,q in out.items():
  delta=pair_matrix(y,q,g,ids)-ref;boot=np.einsum('bi,ij,bj->b',counts,delta,counts,optimize=True)/counts.sum(1)**2;results[name]=dict(pooled_auc=float(roc_auc_score(y,q)),DEP_auc=float(roc_auc_score(y[dep],q[dep])),paired_person_delta_95CI=np.quantile(boot,[.025,.975]).tolist());np.savez_compressed(OUT/(name+'_oof.npz'),labels=y,subjects=g,probability=q)
 driver.save(OUT/'summary.json',dict(results=results,anchor_auc=float(roc_auc_score(y,anchor)),baseline_preserved=True,cohort_reused=True,multiple_search_uncorrected=True,official_score_unknown=True));driver.save(OUT/'verification.json',dict(checks_passed=True,all5outer_complete=True,source_inner_SVM_and_weight_fit_only=True,calibration_policy_inherited=True,audits=audits,holdout_and_official_not_read=True,submissions_performed=False));print('SOURCE RELIABILITY FUSION COMPLETE',json.dumps(results),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException:driver.save(OUT/'failure.json',dict(traceback=traceback.format_exc()));raise
