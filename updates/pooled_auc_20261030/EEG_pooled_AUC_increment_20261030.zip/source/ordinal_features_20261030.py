"""Multiscale ordinal/weighted/transition entropies, amplitude-invariant stats.
Real10s source EEG only. No labels/diagnosis used in extraction or normalization.
"""
import os
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='1'
from itertools import permutations
import numpy as np,json
from threadpoolctl import threadpool_limits
import driver
from common import batches
OUT=driver.JOB/'ordinal_features_20261030';OUT.mkdir(exist_ok=True)
SCALES=[1,2,4,8]
LOOKUP=np.full(27,-1,dtype=int)
for j,p in enumerate(permutations(range(3))):LOOKUP[p[0]*9+p[1]*3+p[2]]=j

def extract(raw):
 x=raw.astype('float64');values=[]
 for scale in SCALES:
  length=x.shape[-1]//scale;v=x[...,:length*scale].reshape(*x.shape[:-1],length,scale).mean(-1);windows=np.stack([v[...,:-2],v[...,1:-1],v[...,2:]],axis=-1);order=np.argsort(windows,axis=-1,kind='stable');codes=LOOKUP[order[...,0]*9+order[...,1]*3+order[...,2]];assert np.all(codes>=0);codes=codes.reshape(-1,codes.shape[-1]);n=len(codes);offset=np.arange(n)[:,None]*6;counts=np.bincount((codes+offset).ravel(),minlength=n*6).reshape(n,6);p=counts/counts.sum(1,keepdims=True);entropy=-(p*np.log(np.maximum(p,1e-12))).sum(1)/np.log(6);var=windows.var(-1).reshape(n,-1);weighted=np.bincount((codes+offset).ravel(),weights=var.ravel(),minlength=n*6).reshape(n,6);wp=weighted/np.maximum(weighted.sum(1,keepdims=True),1e-12);we=-(wp*np.log(np.maximum(wp,1e-12))).sum(1)/np.log(6);transition=codes[:,:-1]*6+codes[:,1:];hist=np.bincount((transition+np.arange(n)[:,None]*36).ravel(),minlength=n*36).reshape(n,6,6);total=hist.sum((1,2));conditional=hist/np.maximum(hist.sum(2,keepdims=True),1);te=-(hist/np.maximum(total,1)[:,None,None]*np.log(np.maximum(conditional,1e-12))).sum((1,2))/np.log(6);values.append(np.stack([entropy,we,te],axis=-1).reshape(len(x),-1))
 sd=x.std(-1);dx=np.diff(x,axis=-1);dd=np.diff(dx,axis=-1);mob=dx.std(-1)/np.maximum(sd,1e-8);comp=(dd.std(-1)/np.maximum(dx.std(-1),1e-8))/np.maximum(mob,1e-8);line=np.abs(dx).mean(-1)/np.maximum(sd,1e-8);values.append(np.stack([mob,comp,line],axis=-1).reshape(len(x),-1));result=np.column_stack(values).astype('float32');assert result.shape[1]==450 and np.isfinite(result).all();return result

def main():
 threadpool_limits(limits=1);spec=dict(scales=SCALES,ordinal_dimension=3,features=['permutation_entropy','variance_weighted_permutation_entropy','symbol_transition_entropy','Hjorth_mobility','Hjorth_complexity','normalized_line_length'],views=['center','z'],reference='https://doi.org/10.1103/PhysRevLett.88.174102',script_sha256=driver.sha(__file__))
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==spec
 else:driver.save(OUT/'protocol.json',spec)
 with np.load(driver.ART/'features.npz') as a:d={k:a[k] for k in ['subject','trial','crop']}
 raw=np.load(driver.ART/'raw_125hz.npy',mmap_mode='r');f=np.empty((len(raw),450),dtype='float32')
 for start in range(0,len(raw),32):
  f[start:start+32]=extract(raw[start:start+32])
  if start%320==0:print('ORDINAL FEATURES',min(start+32,len(raw)),'/',len(raw),flush=True)
 a=extract(raw[:8]);b=extract(raw[:8]*3);scale_error=float(abs(a-b).max());assert scale_error<1e-4,scale_error;groups=np.char.add(np.char.add(d['subject'],':'),d['crop'].astype(str));centered=f.copy();z=f.copy()
 for g in np.unique(groups):
  m=groups==g;assert m.sum()==8;centered[m]-=f[m].mean(0);z[m]=centered[m]/np.maximum(f[m].std(0),.02)
 np.savez_compressed(OUT/'features.npz',center=centered,z=z,**d);driver.save(OUT/'verification.json',dict(checks_passed=True,source_people=59,windows10s=2360,amplitude_gain3_delta=scale_error,labels_and_diagnosis_not_used=True,each_normalization_group_exact8=True,holdout_and_official_not_read=True));print('ORDINAL FEATURES COMPLETE',f.shape,flush=True)
if __name__=='__main__':main()
