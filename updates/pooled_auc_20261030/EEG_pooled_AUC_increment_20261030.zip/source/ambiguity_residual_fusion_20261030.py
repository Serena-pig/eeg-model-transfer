"""Pool-frequency88expert fusion with source-normalized ambiguity residuals.
The gate uses unfitted old86 consensus, not in-sample learned teacher scores.
All weights fitted source-only; fixed loss/feature rules, old calibration policy.
"""
import os
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='1'
import json,traceback
import numpy as np,joblib
from scipy.special import expit,logit,softmax,logsumexp
from scipy.optimize import minimize
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits
import driver
from common import batches,center
from cached_fixed_fusion_20261030 import features
from context_rank_v34 import fit_context,context_features
from select_ensemble import postprocess,ASSIGNMENTS
from inner_calibration_round import calibrate
from postflight import pair_matrix
OUT=driver.JOB/'ambiguity_residual_fusion_20261030';OUT.mkdir(exist_ok=True)
NAMES=['linear88_conditional','gated88_conditional','linear88_posterior_pair','gated88_posterior_pair']
def main():
 threadpool_limits(limits=1);p=driver.protocol();spec=dict(models=NAMES,C_inherited=.01,gate='exp(-(centered_logit_unfitted_old86_consensus/source_median_abs)^2)',residuals='Newcov/ordinal logit minus consensus logit',gate_width_source_features_only=True,all_clinical_weights='Actual frequencies',loss_weights_fixed=[.5,.5],base_deep_models_retrained=0,no_outer_parameter_search=True,calibration='Old source-inner policy inherited',script_sha256=driver.sha(__file__))
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==spec
 else:driver.save(OUT/'protocol.json',spec)
 with np.load(driver.ART/'features.npz') as a:d={k:a[k] for k in ['subject','trial','crop','label','diagnosis','train','powers','quality']}
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:full={k:a[k] for k in a.files}
 with np.load(driver.JOB/'aligned_covariance_fusion_20261030/conditional_BCE87_calibrated_oof.npz') as a:anchor=a['probability']
 out={n:anchor.copy() for n in NAMES+[n+'_calibrated' for n in NAMES]};audits=[];baseix=np.r_[np.arange(83),np.arange(104,107)]
 for f in p['folds']:
  with np.load(driver.JOB/f'cached_group_diagnostics_20261030/fold{f["fold"]}_aligned_banks.npz') as a:tr=a['inner_indices'];va=a['outer_indices'];ib=a['inner_probability'][baseix];ob=a['outer_probability'][baseix]
  lookup={v:j for j,v in enumerate(tr)};gin=batches(d)[tr];gout=batches(d)[va];expert_scales=[]
  for root in ['aligned_covariance_svm_20261030','ordinal_svm_20261030']:
   zin=np.zeros(len(tr))
   for part in range(3):
    with np.load(driver.JOB/root/f'fold{f["fold"]}_inner{part}.npz') as a:zin[[lookup[v] for v in a['validation']]]=a['logits']
   with np.load(driver.JOB/root/f'fold{f["fold"]}_outer.npz') as a:assert np.array_equal(a['validation'],va);zout=a['logits']
   zin=center(zin,gin);sd=max(float(zin.std()),.1);ib=np.vstack([ib,postprocess(zin/sd,gin,'conditional',.6)]);ob=np.vstack([ob,postprocess(center(zout,gout)/sd,gout,'conditional',.6)]);expert_scales.append(sd)
  consensus=center(logit(np.clip(ib[:86].mean(0),1e-6,1-1e-6)),gin);width=max(float(np.median(abs(consensus))),.05)
  def residual(bank,groups):
   c=center(logit(np.clip(bank[:86].mean(0),1e-6,1-1e-6)),groups);gate=np.exp(-(c/width)**2);return (np.clip(logit(np.clip(bank[86:],1e-6,1-1e-6)),-10,10).T-c[:,None])*gate[:,None]
  source=dict(d);source['label']=np.full_like(d['label'],-1);source['diagnosis']=np.full_like(d['diagnosis'],-1);source['diagnosis'][tr]=d['diagnosis'][tr];context,e=fit_context(source,tr);blind=dict(d);blind['label']=np.full_like(d['label'],-1);blind['diagnosis']=np.full_like(d['diagnosis'],-1);ev=context_features(blind,va,context);rr=np.stack([np.flatnonzero(gin==g) for g in np.unique(gin)]);A=ASSIGNMENTS;y=d['label'][tr];positive=np.flatnonzero(y==1);negative=np.flatnonzero(y==0);reg=1/(.01*len(y));mode=json.loads((driver.JOB/f'inner_calibration_20261028/fold{f["fold"]}_selection.json').read_text())['chosen'];models={};cache={};per=np.random.default_rng(f['fold']).permutation(len(va))
  for gated in [False,True]:
   raw=np.column_stack([features(ib,gin),e]);vraw=np.column_stack([features(ob,gout),ev])
   if gated:raw=np.column_stack([raw,residual(ib,gin)]);vraw=np.column_stack([vraw,residual(ob,gout)])
   scaler=StandardScaler().fit(raw);xx=scaler.transform(raw);vv=scaler.transform(vraw);gx=np.column_stack([xx,.5*(2*e[:,6]-1)[:,None]*xx[:,[83,84,85,86,87]]]);gv=np.column_stack([vv,.5*(2*ev[:,6]-1)[:,None]*vv[:,[83,84,85,86,87]]]);model=LogisticRegression(C=.01,max_iter=2000).fit(gx,y);initial=np.r_[model.coef_[0],model.intercept_[0]]
   for lossname in ['conditional','posterior_pair']:
    name=('gated88_' if gated else 'linear88_')+lossname
    def obj(theta):
     beta=theta[:-1];z=gx@beta+theta[-1];ss=z[rr]@A.T;posterior=softmax(ss,axis=1);prob=posterior@A;closs=np.mean(logsumexp(ss,axis=1)-(z[rr]*y[rr]).sum(1))/8;ce=np.zeros(len(y));ce[rr.ravel()]=((prob-y[rr])/len(y)).ravel()
     if lossname=='conditional':loss=.5*closs+.5*np.mean(np.logaddexp(0,z)-y*z);gradient=.5*ce+.5*(expit(z)-y)/len(y)
     else:
      safe=np.clip(prob,1e-8,1-1e-8);lp=np.log(safe)-np.log1p(-safe);flat=np.zeros(len(y));flat[rr.ravel()]=lp.ravel();margin=flat[positive,None]-flat[negative][None];risk=np.logaddexp(0,-margin).mean();dm=-expit(-margin)/margin.size;gl=np.zeros(len(y));gl[positive]=dm.sum(1);gl[negative]=-dm.sum(0);cov=np.einsum('ga,ai,aj->gij',posterior,A,A,optimize=True)-prob[:,:,None]*prob[:,None,:];v=gl[rr]/(safe*(1-safe));v[(prob<=1e-8)|(prob>=1-1e-8)]=0.;gz=np.einsum('gij,gi->gj',cov,v,optimize=True);pg=np.zeros(len(y));pg[rr.ravel()]=gz.ravel();gradient=.5*ce+.5*pg;loss=.5*closs+.5*risk
     return float(loss+.5*reg*np.dot(beta,beta)),np.r_[gx.T@gradient+reg*beta,gradient.sum()]
    if f['fold']==1:
     grad=obj(initial)[1]
     for j in [0,len(initial)//2,len(initial)-1]:
      aa=initial.copy();bb=initial.copy();aa[j]+=1e-6;bb[j]-=1e-6;assert abs((obj(aa)[0]-obj(bb)[0])/2e-6-grad[j])<1e-5
    fit=minimize(obj,initial,jac=True,method='L-BFGS-B',options=dict(maxiter=1000,ftol=1e-12,gtol=1e-7));assert fit.success,(name,fit.message);models[name]=dict(theta=fit.x,scaler=scaler,gated=gated);q=expit(gv@fit.x[:-1]+fit.x[-1]);out[name][full['model_row_to_full_row'][va]]=np.round(q,12);out[name+'_calibrated'][full['model_row_to_full_row'][va]]=np.round(calibrate(q,gout,mode),12);cache[name]=q
  path=OUT/f'fold{f["fold"]}.joblib';joblib.dump(dict(models=models,context=context,expert_scales=expert_scales,gate_width=width,source_subjects=f['training_subjects'],protocol=spec),path,compress=3);saved=joblib.load(path)
  for name,m in saved['models'].items():
   vraw=np.column_stack([features(ob[:,per],np.char.add('opaque_',gout[per])),ev[per]])
   if m['gated']:vraw=np.column_stack([vraw,residual(ob[:,per],np.char.add('opaque_',gout[per]))])
   vv=m['scaler'].transform(vraw);xx=np.column_stack([vv,.5*(2*ev[per,6]-1)[:,None]*vv[:,[83,84,85,86,87]]]);t=m['theta'];q=expit(xx@t[:-1]+t[-1]);error=float(abs(q-cache[name][per]).max());assert error<1e-9;audits.append(dict(fold=f['fold'],name=name,native_opaque_reordered_delta=error))
  print('AMBIGUITY RESIDUAL OUTER',f['fold'],'/5',flush=True)
 y=full['label'];g=full['subject'];dep=full['diagnosis']==1;ids=np.unique(g);ref=pair_matrix(y,anchor,g,ids);rng=np.random.default_rng(1030);counts=np.zeros((2000,len(ids)))
 for j in range(len(counts)):
  for mask in [np.char.startswith(ids,'DEP'),np.char.startswith(ids,'HC')]:
   ix=np.flatnonzero(mask);counts[j]+=np.bincount(rng.choice(ix,len(ix),replace=True),minlength=len(ids))
 results={}
 for name,q in out.items():
  delta=pair_matrix(y,q,g,ids)-ref;boot=np.einsum('bi,ij,bj->b',counts,delta,counts,optimize=True)/counts.sum(1)**2;results[name]=dict(pooled_auc=float(roc_auc_score(y,q)),DEP_auc=float(roc_auc_score(y[dep],q[dep])),paired_person_delta_95CI=np.quantile(boot,[.025,.975]).tolist());np.savez_compressed(OUT/(name+'_oof.npz'),labels=y,subjects=g,probability=q)
 driver.save(OUT/'summary.json',dict(results=results,anchor_auc=float(roc_auc_score(y,anchor)),baseline_preserved=True,cohort_reused=True,multiple_search_uncorrected=True,official_score_unknown=True));driver.save(OUT/'verification.json',dict(checks_passed=True,all5outer_complete=True,source_only_gate_width_and_weights=True,no_outer_parameter_search=True,calibration_policy_inherited=True,audits=audits,holdout_and_official_not_read=True,submissions_performed=False));print('AMBIGUITY RESIDUAL COMPLETE',json.dumps(results),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException:driver.save(OUT/'failure.json',dict(traceback=traceback.format_exc()));raise
