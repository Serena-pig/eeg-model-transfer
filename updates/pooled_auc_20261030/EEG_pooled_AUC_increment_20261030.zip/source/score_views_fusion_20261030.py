"""Source-only matched fusion on raw/logposterior/rank score representations.
No outer tuning of source normalization or clinical gates; fixed C=.01 and
half conditional/BCE objective. Existing final calibration policy inherited.
"""
import os
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='1'
import json,traceback
import numpy as np,joblib
from scipy.special import expit,logit,logsumexp,softmax
from scipy.stats import rankdata,norm
from scipy.optimize import minimize
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits
import driver
from common import batches,center
from cached_fixed_fusion_20261030 import features
from context_rank_v34 import fit_context,context_features
from inner_calibration_round import calibrate
from select_ensemble import ASSIGNMENTS
from postflight import pair_matrix
OUT=driver.JOB/'score_views_fusion_20261030';OUT.mkdir(exist_ok=True)
NAMES=['posterior_control','raw_scores','raw_rank','raw_posterior','raw_rank_all_clinical']
def design(z,posterior,groups,extra,kind,scales=None):
 zz=np.array([center(row,groups) for row in z])
 if scales is None:scales=np.maximum(zz.std(1),.1)
 raw=np.clip(zz/scales[:,None],-10,10).T;std=np.empty_like(raw);ranks=np.empty_like(raw)
 for g in np.unique(groups):
  m=groups==g;assert m.sum()==8;std[m]=raw[m].std(0);ranks[m]=norm.ppf((rankdata(raw[m],axis=0,method='average')-.5)/8)
 if kind=='posterior_control':x=features(posterior,groups);scoreblocks=1
 elif kind=='raw_scores':x=np.column_stack([raw,std]);scoreblocks=1
 elif kind in ['raw_rank','raw_rank_all_clinical']:x=np.column_stack([raw,ranks,std]);scoreblocks=2
 else:x=np.column_stack([raw,np.clip(logit(np.clip(posterior,1e-6,1-1e-6)),-10,10).T,std]);scoreblocks=2
 return np.column_stack([x,extra]),scales,scoreblocks

def main():
 threadpool_limits(limits=1);p=driver.protocol();pool=json.loads((driver.JOB/'completed_pool/protocol.json').read_text());positions=pool['member_positions'];spec=dict(variants=NAMES,members=87,C_inherited=.01,clinical_sample_weights='Unit record weights, actual frequencies',conditional_BCE_mix_fixed=.5,source_only_logit_scales=True,rank8_normal_quantiles=True,multiview_score_downscale='1/sqrt(number_score_views) after sourceScaler',no_outer_parameter_search=True,calibration='Original source-inner policy inherited',script_sha256=driver.sha(__file__))
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==spec
 else:driver.save(OUT/'protocol.json',spec)
 with np.load(driver.ART/'features.npz') as a:d={k:a[k] for k in ['subject','trial','crop','label','diagnosis','train','powers','quality']}
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:full={k:a[k] for k in a.files}
 with np.load(driver.JOB/'aligned_covariance_fusion_20261030/conditional_BCE87_calibrated_oof.npz') as a:anchor=a['probability']
 out={n:anchor.copy() for n in NAMES+[n+'_calibrated' for n in NAMES]};audits=[];baseix=np.r_[np.arange(83),np.arange(104,107)]
 for f in p['folds']:
  with np.load(driver.JOB/f'cached_group_diagnostics_20261030/fold{f["fold"]}_aligned_banks.npz') as a:tr=a['inner_indices'];va=a['outer_indices'];ib=a['inner_probability'][baseix];ob=a['outer_probability'][baseix]
  lookup={v:j for j,v in enumerate(tr)};inside=np.zeros((87,len(tr)));outside=np.zeros((87,len(va)))
  for j,pos in enumerate(positions):
   m=p['members'][pos]
   for part in ['inner0','inner1','inner2','outer']:
    t=dict(fold=f['fold'],part=part,index=m['candidate_index'],name=m['name'],family=m['family'],member_position=pos);path,_=driver.paths(t)
    with np.load(path) as a:
     if part=='outer':assert np.array_equal(a['query_indices'],va);outside[j]=a['logits']
     else:inside[j,[lookup[v] for v in a['query_indices']]]=a['logits']
  for j,name in enumerate(['de_cnn','raw_de_cnn','raw_de_bigru'],start=83):
   reverse={v:i for i,v in enumerate(full['model_row_to_full_row'])}
   for part in ['inner0','inner1','inner2','outer']:
    with np.load(driver.JOB/f'leaderboard_dualbranch_20261028/{name}_fold{f["fold"]}_{part}.npz') as a:rows=a['validation'];good=np.array([int(v) in reverse for v in rows]);ix=np.array([reverse[int(v)] for v in rows[good]]);z=logit(np.clip(a['probability'][good],1e-6,1-1e-6))
    if part=='outer':assert np.array_equal(ix,va);outside[j]=z
    else:inside[j,[lookup[v] for v in ix]]=z
  root=driver.JOB/'aligned_covariance_svm_20261030'
  for part in range(3):
   with np.load(root/f'fold{f["fold"]}_inner{part}.npz') as a:inside[86,[lookup[v] for v in a['validation']]]=a['logits']
  with np.load(root/f'fold{f["fold"]}_outer.npz') as a:assert np.array_equal(a['validation'],va);outside[86]=a['logits']
  gin=batches(d)[tr];gout=batches(d)[va];base=joblib.load(driver.JOB/f'pooled_weight_fusion_20261030/fold{f["fold"]}.joblib');sd=base['SPD_source_scale'];from select_ensemble import postprocess
  ib=np.vstack([ib,postprocess(center(inside[86],gin)/sd,gin,'conditional',.6)]);ob=np.vstack([ob,postprocess(center(outside[86],gout)/sd,gout,'conditional',.6)]);source=dict(d);source['label']=np.full_like(d['label'],-1);source['diagnosis']=np.full_like(d['diagnosis'],-1);source['diagnosis'][tr]=d['diagnosis'][tr];context,e=fit_context(source,tr);blind=dict(d);blind['label']=np.full_like(d['label'],-1);blind['diagnosis']=np.full_like(d['diagnosis'],-1);ev=context_features(blind,va,context);y=d['label'][tr];rr=np.stack([np.flatnonzero(gin==g) for g in np.unique(gin)]);A=ASSIGNMENTS;reg=1/(.01*len(y));mode=json.loads((driver.JOB/f'inner_calibration_20261028/fold{f["fold"]}_selection.json').read_text())['chosen'];models={};raw_predictions={};per=np.random.default_rng(f['fold']).permutation(len(va))
  for name in NAMES:
   x,scales,blocks=design(inside,ib,gin,e,name);scaler=StandardScaler().fit(x);xx=scaler.transform(x);v,_,_=design(outside,ob,gout,ev,name,scales);vv=scaler.transform(v);xx[:,:87*blocks]/=np.sqrt(blocks);vv[:,:87*blocks]/=np.sqrt(blocks);gatecols=list(range(87*blocks)) if name=='raw_rank_all_clinical' else [j+87*b for b in range(blocks) for j in [83,84,85,86]];gx=np.column_stack([xx,.5*(2*e[:,6]-1)[:,None]*xx[:,gatecols]]);gv=np.column_stack([vv,.5*(2*ev[:,6]-1)[:,None]*vv[:,gatecols]]);m=LogisticRegression(C=.01,max_iter=2000).fit(gx,y);theta=np.r_[m.coef_[0],m.intercept_[0]]
   def obj(t):
    beta=t[:-1];z=gx@beta+t[-1];bce=np.mean(np.logaddexp(0,z)-y*z);err=(expit(z)-y)/len(y);zz=z[rr];ss=zz@A.T;posterior=softmax(ss,axis=1);closs=np.mean(logsumexp(ss,axis=1)-(zz*y[rr]).sum(1))/8;ce=np.zeros(len(y));ce[rr.ravel()]=((posterior@A-y[rr])/len(y)).ravel();grad=.5*err+.5*ce;return float(.5*bce+.5*closs+.5*reg*np.dot(beta,beta)),np.r_[gx.T@grad+reg*beta,grad.sum()]
   if f['fold']==1:
    grad=obj(theta)[1]
    for j in [0,len(theta)//2,len(theta)-1]:
     aa=theta.copy();bb=theta.copy();aa[j]+=1e-6;bb[j]-=1e-6;assert abs((obj(aa)[0]-obj(bb)[0])/2e-6-grad[j])<1e-5
   fit=minimize(obj,theta,jac=True,method='L-BFGS-B',options=dict(maxiter=1000,ftol=1e-12,gtol=1e-7));assert fit.success;models[name]=dict(theta=fit.x,scaler=scaler,raw_scales=scales,blocks=blocks,gatecols=gatecols);q=expit(gv@fit.x[:-1]+fit.x[-1]);raw_predictions[name]=q
   # Rebuild all score views and source transforms after changing IDs and row order.
   sv,_,_=design(outside[:,per],ob[:,per],np.char.add('opaque_',gout[per]),ev[per],name,scales);sv=scaler.transform(sv);sv[:,:87*blocks]/=np.sqrt(blocks);sg=np.column_stack([sv,.5*(2*ev[per,6]-1)[:,None]*sv[:,gatecols]]);replay=expit(sg@fit.x[:-1]+fit.x[-1]);error=float(abs(replay-q[per]).max());assert error<1e-9;audits.append(dict(fold=f['fold'],name=name,opaque_group_reordered_delta=error));out[name][full['model_row_to_full_row'][va]]=np.round(q,12);out[name+'_calibrated'][full['model_row_to_full_row'][va]]=np.round(calibrate(q,gout,mode),12)
  path=OUT/f'fold{f["fold"]}.joblib';joblib.dump(dict(models=models,context=context,SPD_source_scale=sd,source_subjects=f['training_subjects'],protocol=spec),path,compress=3);saved=joblib.load(path)
  for name in NAMES:assert np.array_equal(saved['models'][name]['theta'],models[name]['theta'])
  print('SCORE VIEWS FUSION OUTER',f['fold'],'/5',flush=True)
 y=full['label'];g=full['subject'];dep=full['diagnosis']==1;ids=np.unique(g);ref=pair_matrix(y,anchor,g,ids);rng=np.random.default_rng(1030);counts=np.zeros((2000,len(ids)))
 for j in range(len(counts)):
  for mask in [np.char.startswith(ids,'DEP'),np.char.startswith(ids,'HC')]:
   ix=np.flatnonzero(mask);counts[j]+=np.bincount(rng.choice(ix,len(ix),replace=True),minlength=len(ids))
 results={}
 for name,q in out.items():
  delta=pair_matrix(y,q,g,ids)-ref;boot=np.einsum('bi,ij,bj->b',counts,delta,counts,optimize=True)/counts.sum(1)**2;results[name]=dict(pooled_auc=float(roc_auc_score(y,q)),DEP_auc=float(roc_auc_score(y[dep],q[dep])),paired_person_delta_95CI=np.quantile(boot,[.025,.975]).tolist());np.savez_compressed(OUT/(name+'_oof.npz'),labels=y,subjects=g,probability=q)
 driver.save(OUT/'summary.json',dict(results=results,anchor_auc=float(roc_auc_score(y,anchor)),baseline_preserved=True,cohort_reused=True,multiple_search_uncorrected=True,official_score_unknown=True));driver.save(OUT/'verification.json',dict(checks_passed=True,all5outer_complete=True,source_only_weight_and_scale_fit=True,no_outer_hyperparameter_search=True,calibration_policy_inherited=True,audits=audits,holdout_and_official_not_read=True,submissions_performed=False));print('SCORE VIEWS FUSION COMPLETE',json.dumps(results),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException:driver.save(OUT/'failure.json',dict(traceback=traceback.format_exc()));raise
