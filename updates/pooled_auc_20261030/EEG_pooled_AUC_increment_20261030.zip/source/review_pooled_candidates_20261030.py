"""Replay saved fusion heads independently; no fitting or new model selection."""
import os
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):
 os.environ[key]='1'
import json
import numpy as np
import joblib
from scipy.special import expit
from sklearn.metrics import roc_auc_score
import driver
from common import batches, center
from context_rank_v34 import context_features
from cached_fixed_fusion_20261030 import features
from select_ensemble import postprocess
from inner_calibration_round import calibrate
from postflight import pair_matrix

OUT=driver.JOB/'pooled_candidates_review_20261030'
CANDIDATES=[('family_gate_fusion_20261030','clinical_family_pair'),
 ('pooled_posterior_rank_20261030','pooled_posterior_pair'),
 ('pooled_patient_bag_20261030','subbag32_rawmean')]

def main():
 OUT.mkdir(exist_ok=True)
 with np.load(driver.ART/'features.npz') as f:
  d={k:f[k] for k in ['subject','trial','crop','label','diagnosis','train','powers','quality']}
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as f:
  full={k:f[k] for k in f.files}
 with np.load(driver.JOB/'aligned_covariance_fusion_20261030/conditional_BCE87_calibrated_oof.npz') as f:
  anchor=f['probability']
 gfull=full['subject'];ids=np.unique(gfull);ref=pair_matrix(full['label'],anchor,gfull,ids)
 rng=np.random.default_rng(845753);counts=np.zeros((2000,len(ids)))
 for row in counts:
  for mask in [np.char.startswith(ids,'HC'),np.char.startswith(ids,'DEP')]:
   ix=np.flatnonzero(mask);row+=np.bincount(rng.choice(ix,len(ix),replace=True),minlength=len(ids))
 results={}
 for directory,name in CANDIDATES:
  root=driver.JOB/directory
  with np.load(root/(name+'_calibrated_oof.npz')) as f:
   reference=f['probability'];assert np.array_equal(f['labels'],full['label'])
  out=np.full(len(reference),.5);audits=[]
  for fold in driver.protocol()['folds']:
   k=fold['fold'];a=joblib.load(root/f'fold{k}.joblib');base=a.get('base_artifact',a)
   with np.load(driver.JOB/f'cached_group_diagnostics_20261030/fold{k}_aligned_banks.npz') as f:
    va=f['outer_indices'];bank=f['outer_probability'][np.r_[np.arange(83),np.arange(104,107)]]
   with np.load(driver.JOB/f'aligned_covariance_svm_20261030/fold{k}_outer.npz') as f:
    assert np.array_equal(f['validation'],va);z=f['logits']
   perm=np.random.default_rng(103085+k).permutation(len(va));ix=va[perm]
   query=dict(d);query['label']=np.full_like(d['label'],-1);query['diagnosis']=np.full_like(d['diagnosis'],-1)
   query['train']=np.zeros_like(d['train']);query['subject']=np.char.add('opaque_',d['subject']);query['trial']=np.zeros_like(d['trial'])
   groups=batches(query)[ix]
   bank=np.vstack([bank[:,perm],postprocess(center(z[perm],groups)/base['SPD_source_scale'],groups,'conditional',.6)])
   e=context_features(query,ix,base['context']);x=base['scaler'].transform(np.column_stack([features(bank,groups),e]))
   v=np.column_stack([x,.5*(2*e[:,6]-1)[:,None]*x[:,[83,84,85,86]]])
   if directory.startswith('family_gate'):
    fam=np.column_stack([center(x[:,positions].mean(1),groups) for positions in a['family_indices']])
    v=np.column_stack([v,fam*(e[:,6]-a['clinical_mean'])[:,None]])
    theta=a['models'][name]['theta'];q=expit(v@theta[:-1]+theta[-1])
   elif directory.startswith('pooled_patient_bag'):
    theta=a['models']['subbag32'];q=expit(v@theta[:,:-1].T+theta[:,-1]).mean(1)
   else:
    theta=a['models'][name];q=expit(v@theta[:-1]+theta[-1])
   mode=json.loads((driver.JOB/f'inner_calibration_20261028/fold{k}_selection.json').read_text())['chosen']
   q=calibrate(q,groups,mode);rows=full['model_row_to_full_row'][ix];err=float(abs(q-reference[rows]).max())
   assert err<1e-9,(name,k,err);out[rows]=q;audits.append(dict(fold=k,max_prediction_delta=err))
  assert np.max(abs(out-reference))<1e-9
  rounding={str(n):float(roc_auc_score(full['label'],np.round(out,n))) for n in (10,12,14)}
  assert max(rounding.values())-min(rounding.values())<1e-6
  delta=pair_matrix(full['label'],reference,gfull,ids)-ref
  boot=np.einsum('bi,ij,bj->b',counts,delta,counts,optimize=True)/counts.sum(1)**2
  diag=full['diagnosis'];fold_auc={str(f['fold']):float(roc_auc_score(full['label'][np.isin(gfull,f['validation_subjects'])],reference[np.isin(gfull,f['validation_subjects'])])) for f in driver.protocol()['folds']}
  record=dict(pooled_auc=float(roc_auc_score(full['label'],reference)),DEP_auc=float(roc_auc_score(full['label'][diag==1],reference[diag==1])),HC_auc=float(roc_auc_score(full['label'][diag==0],reference[diag==0])),fold_auc=fold_auc,rounding_auc=rounding,paired_person_delta_95CI_vs_845856=np.quantile(boot,[.025,.975]).tolist(),audits=audits)
  results[name]=record
  print(name,json.dumps(record),flush=True)
 driver.save(OUT/'independent_review.json',dict(checks_passed=True,people=60,ten_second_windows=2400,all5outer_folds_replayed=True,query_labels_diagnosis_train_trial_hidden=True,subject_ids_opaque=True,query_rows_permuted=True,official_test_and_sealed_not_opened=True,official_submissions=0,development_reused=True,multiple_search_uncorrected=True,anchor_auc=float(roc_auc_score(full['label'],anchor)),results=results))

if __name__=='__main__':main()
