"""Preserve complete experimental fusion heads and the full search record."""
import csv,hashlib,json,shutil,zipfile
from pathlib import Path
import driver

ROUND=['pooled_weight_fusion_20261030','pooled_posterior_rank_20261030',
 'source_reliability_fusion_20261030','pooled_86_control_20261030',
 'score_views_fusion_20261030','pooled_temperature_fusion_20261030',
 'ordinal_svm_20261030','ordinal_fusion_20261030','ambiguity_residual_fusion_20261030',
 'pooled_patient_bag_20261030','family_gate_fusion_20261030']
ROOT=driver.JOB.parent
DEST=ROOT/'frozen_baselines/candidate_847530_20261030'
OUT=Path('/workspace/output')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 review=json.loads((driver.JOB/'pooled_candidates_review_20261030/independent_review.json').read_text())
 assert review['checks_passed']
 assert not DEST.exists(), 'Freeze already exists; do not overwrite'
 DEST.mkdir()
 dirs=['pooled_weight_fusion_20261030','pooled_posterior_rank_20261030','pooled_patient_bag_20261030','family_gate_fusion_20261030','pooled_candidates_review_20261030']
 scripts=[p for p in driver.JOB.glob('*20261030.py') if any(p.stem==name or p.stem=='fuse_'+name.split('_20261030')[0] for name in ROUND)]
 scripts += [driver.JOB/x for x in ['ordinal_features_20261030.py','evaluate_ordinal_20261030.py','fuse_ordinal_20261030.py','review_pooled_candidates_20261030.py','archive_pooled_round_20261030.py','cached_fixed_fusion_20261030.py']]
 scripts=list(dict.fromkeys(scripts))
 for directory in dirs:shutil.copytree(driver.JOB/directory,DEST/directory)
 for file in scripts:shutil.copy2(file,DEST/file.name)
 references={}
 for rel in ['frozen_baselines/candidate_845856_20261030/FREEZE_COMPLETE.json','v279_rebuild/control/protocol.json','v279_rebuild/completed_pool/protocol.json']:
  references[rel]=sha(ROOT/rel)
 manifest={str(p.relative_to(DEST)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(DEST.rglob('*')) if p.is_file()}
 record=dict(status='experimental_candidate_not_promoted',primary='family_gate_fusion_20261030/clinical_family_pair_calibrated_oof.npz',pooled_auc=review['results']['clinical_family_pair']['pooled_auc'],DEP_auc=review['results']['clinical_family_pair']['DEP_auc'],references=references,files=manifest,not_standalone_inference_package=True,requires_previous_frozen_83_plus_3NN_and_alignedcovariance=True,development_people=60,ten_second_records=2400,official_submissions=0)
 (DEST/'FREEZE_COMPLETE.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
 for file in DEST.rglob('*'):
  if file.is_file():file.chmod(0o444)
 (ROOT/'CURRENT_EXPERIMENTAL_847530.txt').write_text(str(DEST)+'\n',encoding='utf-8')
 rows=[];best=[]
 for directory in ROUND:
  summary=json.loads((driver.JOB/directory/'summary.json').read_text());r=summary.get('results',summary)
  # Expert evaluation may store a direct metric summary rather than variants.
  if 'pooled_auc' in r:r={directory:r}
  valid=[]
  for name,s in r.items():
   if not isinstance(s,dict) or 'pooled_auc' not in s:continue
   row=dict(experiment=directory,variant=name,pooled_auc=s['pooled_auc'],DEP_auc=s.get('DEP_auc',s.get('dep_auc')));rows.append(row);valid.append(row)
  if valid:best.append(max(valid,key=lambda a:a['pooled_auc']))
 csvpath=OUT/'EEG_pooled_AUC_20261030_metrics.csv'
 with csvpath.open('w',newline='',encoding='utf-8-sig') as f:
  writer=csv.DictWriter(f,fieldnames=['experiment','variant','pooled_auc','DEP_auc']);writer.writeheader();writer.writerows(rows)
 lines=['# 合并AUC定向优化实测（2026-10-30）','',
 '完整五折、同一60名开发被试、2400条10秒记录的最高探索性候选为 **84.752986% AUC**；本轮起点84.585556%，增加0.167431个百分点。抑郁组由75.660000%至75.934375%。尚未达到85%，不是官方测试分数。','',
 '主要变化是把源训练数据的健康/抑郁强制50:50权重改为实际人数比例，并在条件后验之后直接优化全体正负记录对的排序损失。保留87来源模型，另加按源数据推断临床状态控制的模型族残差。推理不读取诊断、标签或trial编号；模型族只由已冻结成员类型确定。','',
 '三个近似并列候选均保存：','',
 '|候选|合并AUC|抑郁组AUC|','|---|---:|---:|']
 for name,r in review['results'].items():lines.append(f"|{name}|{r['pooled_auc']*100:.6f}%|{r['DEP_auc']*100:.6f}%|")
 lines+=['','三者差异只涉及少量排序对，不能把这点数值差认定为可靠泛化优势。保存最高数值候选，同时保留更简单的排序融合和被试级重采样方案。','',
 '## 所有尝试的记录','',f'本轮共记录{len(rows)}个输出，包括原始和校准版本；下表是每条路径内部数值最高结果，全部结果见CSV。多次尝试已经使用同一开发集，表格不是独立确认。','',
 '|路径|该路径最高输出|合并AUC|抑郁组AUC|','|---|---|---:|---:|']
 for r in best:lines.append(f"|{r['experiment']}|{r['variant']}|{r['pooled_auc']*100:.6f}%|{r['DEP_auc']*100:.6f}%|" if r['DEP_auc'] is not None else f"|{r['experiment']}|{r['variant']}|{r['pooled_auc']*100:.6f}%|未记录|")
 lo,hi=review['results']['clinical_family_pair']['paired_person_delta_95CI_vs_845856']
 lines+=['','## 验证与适用范围','',
 '保存的五折融合模型已独立重载，在隐藏标签、诊断、训练标记和trial编号后，替换被试ID并打乱记录顺序，最大预测差小于5e-13；10/12/14位小数的AUC相同。原基础模型此前已经核验，本轮不宣称重新训练或独立重放所有深度编码器。','',
 '融合参数只拟合各外层源训练被试的内层预测。新增参数固定后再评价外层；沿用原源内层校准策略，没有声称额外完成严格更深层的元模型校准交叉验证。不能在已有OOF特征上随意再切元验证集并称为完整嵌套验证。','',
 f'最高候选相对84.585556%的按被试、健康/抑郁分层配对重采样95%差值区间为[{lo*100:.4f}, {hi*100:.4f}]个百分点，包含0，且未校正多重尝试。因此数值提高已复现，真实泛化改善仍未获统计确认。','',
 '封存集及官方公开测试均未读取，未提交任何竞赛结果。该验证是60人开发集的合并AUC，不能当作官方80条测试结果。','',
 '## 冻结与复现','',
 f'冻结位置：`{DEST.relative_to(ROOT)}`；`FREEZE_COMPLETE.json`记录每个文件SHA256及旧基线依赖。原84.42%、84.5656%、84.5856%冻结版本均保留。','',
 '本更新含完整的本轮融合头、源码、预测、配置、检查结果和CSV，但依赖原工程、87来源特征及既有基础模型，**不是可独立运行的完整比赛推理包**。没有重写原有提交文件。','',
 '## 方法参考','',
 '- [RankNet原论文](https://www.microsoft.com/en-us/research/publication/learning-to-rank-using-gradient-descent/)：借鉴成对排序损失，本实现通过条件概率的雅可比反向传播，不声称复现其网络。',
 '- [Bandt与Pompe，Permutation Entropy](https://doi.org/10.1103/PhysRevLett.88.174102)：本轮独立实现排列熵、加权排列熵及Hjorth特征；其新增SVM未带来融合收益。','']
 report=OUT/'EEG_pooled_AUC_20261030.md';report.write_text('\n'.join(lines),encoding='utf-8')
 zpath=OUT/'EEG_pooled_AUC_research_20261030.zip'
 with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  z.write(report,'REPORT.md');z.write(csvpath,'metrics.csv')
  for p in sorted(DEST.rglob('*')):
   if p.is_file():z.write(p,'frozen_candidate/'+str(p.relative_to(DEST)))
  for directory in ROUND:
   for p in sorted((driver.JOB/directory).glob('*')):
    if p.is_file() and p.suffix in ('.json','.npz'):z.write(p,'search_results/'+directory+'/'+p.name)
  for p in scripts:z.write(p,'source/'+p.name)
 receipt=dict(freeze=str(DEST),files=len(manifest),research_zip=str(zpath),bytes=zpath.stat().st_size,sha256=sha(zpath),report=str(report),outputs=len(rows))
 (OUT/'EEG_pooled_AUC_20261030_artifacts.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
 print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
