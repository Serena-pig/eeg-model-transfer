"""Training-only trial prototypes, evaluated on SINGLE10s observations.
Prototypes are derived feature augmentation, not new EEG recordings. Median5
source windows, then per-person8prototype rank normalization. Validation never
aggregated to50s for primary metrics. All settings selected in3inner subjectCV.
"""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import json,traceback
import numpy as np,joblib
from scipy.stats import norm,rankdata
from scipy.special import expit
from sklearn.preprocessing import StandardScaler
from sklearn.metrics.pairwise import euclidean_distances
from sklearn.svm import SVC
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits
import driver
from domain_models_v2 import _features
from select_ensemble import postprocess
from postflight import pair_matrix
OUT=driver.JOB/'trial_prototype_svm_20261028';OUT.mkdir(exist_ok=True)
def samplew(diag):
 w=np.ones(len(diag))
 for v in [0,1]:w[diag==v]=len(diag)/(2*np.sum(diag==v))
 return w

def prototype_data(x,rows,d):
 groups=np.char.add(np.char.add(d['subject'][rows],':'),d['trial'][rows].astype(str));xx=[];yy=[];diag=[];subject=[]
 for group in np.unique(groups):
  ix=rows[groups==group];assert len(ix)==5 and len(np.unique(d['label'][ix]))==1;xx.append(np.median(x[ix],axis=0));yy.append(d['label'][ix[0]]);diag.append(d['diagnosis'][ix[0]]);subject.append(d['subject'][ix[0]])
 xx=np.array(xx);subject=np.array(subject)
 for s in np.unique(subject):
  m=subject==s;assert m.sum()==8;xx[m]=norm.ppf((rankdata(xx[m],axis=0)-.5)/8)
 return xx,np.array(yy),np.array(diag),subject

def main():
 limits=threadpool_limits(limits=1);p=driver.protocol();configs=[dict(C=C,gamma=g,prototype_mass=lam) for g in [.5,1.,2.] for C in [.1,.3,1.,3.,10.] for lam in [0.,.5,1.]];spec=dict(configs=configs,primary_unit='10secondwindow',training_only_prototypes='Median5rankfeatures per sourcevideo,8prototype rank normalization',source_window_mass_preserved=True,scaler='fit originalsource trainingwindows only',selection='3innermeanbalancedAUC-.25std; augmentedDEPfloor-.005andgain.001vsreference',fixed_ensemble_weight_to_frozen=.1,all5outer3inner=True,script_sha256=driver.sha(__file__),cohort_reused=True,not5repeat_confirmation=True)
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==spec
 else:driver.save(OUT/'protocol.json',spec)
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:d={k:a[k] for k in a.files}
 mapping=d['model_row_to_full_row'];n=len(d['label']);eligible=np.zeros(n,dtype=bool);eligible[mapping]=True;groups=np.char.add(np.char.add(d['subject'],':'),d['crop'].astype(str))
 with np.load(driver.ART/'features.npz') as a:old={k:a[k] for k in ['subject','crop','powers','spectrum']}
 z=_features(old,np.arange(len(mapping)),'aperiodic');x=np.zeros((n,z.shape[1]));x[mapping]=z;pred=np.full(n,.5);ref=pred.copy();audits=[]
 for f in p['folds']:
  tr=np.flatnonzero(np.isin(d['subject'],f['training_subjects']));va=np.flatnonzero(np.isin(d['subject'],f['validation_subjects']));lookup={v:j for j,v in enumerate(tr)};oof=np.full((len(configs),len(tr)),np.nan)
  for ik,part in enumerate(f['inner']):
   fit=np.flatnonzero(np.isin(d['subject'],part['training_subjects'])&eligible);val=np.flatnonzero(np.isin(d['subject'],part['validation_subjects']));assert not set(d['subject'][fit])&set(d['subject'][val]);px,py,pdiag,ps=prototype_data(x,fit,d);sc=StandardScaler().fit(x[fit]);xx=np.concatenate([sc.transform(x[fit]),sc.transform(px)]);yy=np.r_[d['label'][fit],py];weights=samplew(d['diagnosis'][fit]);pw=samplew(pdiag)*5;D=euclidean_distances(xx,squared=True)/x.shape[1];DV=euclidean_distances(sc.transform(x[val]),xx,squared=True)/x.shape[1];current=None
   for j,c in enumerate(configs):
    if c['gamma']!=current:current=c['gamma'];K=np.exp(-current*D);KV=np.exp(-current*DV)
    lam=c['prototype_mass'];w=np.r_[weights*(1-lam),pw*lam];keep=w>0;model=SVC(C=c['C'],kernel='precomputed',cache_size=128).fit(K[np.ix_(keep,keep)],yy[keep],sample_weight=w[keep]);score=model.decision_function(KV[:,keep]);score[~eligible[val]]=0;oof[j,[lookup[v] for v in val]]=postprocess(score,groups[val],'conditional',1.)
   print('PROTO INNER COMPLETE',f['fold'],ik+1,flush=True)
  assert np.isfinite(oof).all();metrics=[]
  for q in oof:
   vals=[];deps=[]
   for part in f['inner']:
    m=np.isin(d['subject'][tr],part['validation_subjects']);vals.append(roc_auc_score(d['label'][tr][m],q[m],sample_weight=samplew(d['diagnosis'][tr][m])));dd=m&(d['diagnosis'][tr]==1);deps.append(roc_auc_score(d['label'][tr][dd],q[dd]))
   metrics.append(dict(mean=float(np.mean(vals)),DEP=float(np.mean(deps)),stable=float(np.mean(vals)-.25*np.std(vals))))
  base=max([i for i,c in enumerate(configs) if c['prototype_mass']==0],key=lambda i:metrics[i]['stable']);choices=[i for i,c in enumerate(configs) if c['prototype_mass']>0 and metrics[i]['DEP']>=metrics[base]['DEP']-.005 and metrics[i]['mean']>=metrics[base]['mean']+.001]+[base];best=max(choices,key=lambda i:metrics[i]['stable']);fit=tr[eligible[tr]];px,py,pdiag,ps=prototype_data(x,fit,d);sc=StandardScaler().fit(x[fit]);xx=np.concatenate([sc.transform(x[fit]),sc.transform(px)]);yy=np.r_[d['label'][fit],py];weights=samplew(d['diagnosis'][fit]);pw=samplew(pdiag)*5
  for name,index in [('reference',base),('prototype',best)]:
   c=configs[index];lam=c['prototype_mass'];w=np.r_[weights*(1-lam),pw*lam];keep=w>0;trainx=xx[keep];K=np.exp(-c['gamma']*euclidean_distances(trainx,squared=True)/x.shape[1]);model=SVC(C=c['C'],kernel='precomputed',cache_size=128).fit(K,yy[keep],sample_weight=w[keep]);artifact=dict(model=model,scaler=sc,train_x=trainx,config=c,source_subjects=np.unique(d['subject'][fit]).tolist(),source_inner_metric=metrics[index],derived_prototypes_not_new_recordings=True);path=OUT/f'fold{f["fold"]}_{name}.joblib';joblib.dump(artifact,path,compress=3);saved=joblib.load(path)
   def predict(rows,art):
    kv=np.exp(-art['config']['gamma']*euclidean_distances(art['scaler'].transform(x[rows]),art['train_x'],squared=True)/x.shape[1]);z=art['model'].decision_function(kv);z[~eligible[rows]]=0;return postprocess(z,groups[rows],'conditional',1.)
   q=predict(va,artifact);perm=np.random.default_rng(f['fold']).permutation(len(va));replay=predict(va[perm],saved);err=float(abs(replay-q[perm]).max());assert err<1e-8,err;(ref if name=='reference' else pred)[va]=q;audits.append(dict(fold=f['fold'],arm=name,config=c,reload_order_delta=err,fit_train_only=True,prototype_only_training_people=True));
  driver.save(OUT/f'fold{f["fold"]}_selection.json',dict(reference=configs[base],selected=configs[best],reference_inner=metrics[base],selected_inner=metrics[best]));print('PROTO OUTER COMPLETE',f['fold'],'/5',configs[best],flush=True)
 with np.load(driver.CONTROL/'frozen_844161_baseline_oof.npz') as a:frozen=a['probability'];assert np.array_equal(d['label'],a['labels']) and np.array_equal(d['subject'],a['subjects'])
 y=d['label'];g=d['subject'];dep=d['diagnosis']==1;w=samplew(d['diagnosis']);probs=dict(reference_aperiodic=ref,trial_prototype=pred,fixed10pct_fusion=.9*frozen+.1*pred);people=np.unique(g);base=pair_matrix(y,frozen,g,people);rng=np.random.default_rng(20261028);counts=np.zeros((2000,len(people)))
 for j in range(len(counts)):
  for mask in [np.char.startswith(people,'DEP'),np.char.startswith(people,'HC')]:
   ix=np.flatnonzero(mask);counts[j]+=np.bincount(rng.choice(ix,len(ix),replace=True),minlength=len(people))
 results={}
 for name,q in probs.items():
  dd=pair_matrix(y,q,g,people)-base;boot=np.einsum('bi,ij,bj->b',counts,dd,counts,optimize=True)/counts.sum(1)**2;results[name]=dict(pooled10s_auc=float(roc_auc_score(y,q)),balanced10s_auc=float(roc_auc_score(y,q,sample_weight=w)),DEP10s_auc=float(roc_auc_score(y[dep],q[dep])),difference_vs_frozen_95CI=np.quantile(boot,[.025,.975]).tolist());np.savez_compressed(OUT/(name+'_oof.npz'),labels=y,subjects=g,probability=q)
 driver.save(OUT/'verification.json',dict(checks_passed=True,all5outer3inner=True,audits=audits,training_only_trial_aggregation=True,validation_never_aggregated_for_primary=True,seal_test_not_read=True,submissions_performed=False));driver.save(OUT/'summary.json',dict(results=results,baseline_preserved=True,cohort_reused=True,not_multiple_search_corrected=True,official_score_unknown=True));print('TRIAL PROTOTYPE COMPLETE',json.dumps(results),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException:driver.save(OUT/'failure.json',dict(traceback=traceback.format_exc()));raise
