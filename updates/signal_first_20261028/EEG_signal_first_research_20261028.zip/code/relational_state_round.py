"""Within-person emotion relation likelihood, exact4of8 posterior graph.
Pair target same/different learned on source ONLY; no trial positions/IDs as
features. Innerweights selected on clean equal83sourceOOF unary proxy, final
LR-unary transfer mismatch declared. No own outer result selects hyperparameters.
"""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import json,traceback
import numpy as np,joblib
from scipy.special import logit
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits
import driver
from domain_models_v2 import _features
from confidence_fusion_v11 import probability_bank
from select_ensemble import ASSIGNMENTS
from postflight import pair_matrix
OUT=driver.JOB/'relational_state_20261028';OUT.mkdir(exist_ok=True)
I,J=np.triu_indices(8,1);SAME=(ASSIGNMENTS[:,I]==ASSIGNMENTS[:,J]).astype(float)

def pair_data(x,y,g):
 xx=[];yy=[];first=[]
 for group in np.unique(g):
  rows=np.flatnonzero(g==group);assert len(rows)==8;xx.append(abs(x[rows[I]]-x[rows[J]]));yy.append((y[rows[I]]==y[rows[J]]).astype(int));first.extend([int(rows[0])]*len(I))
 return np.concatenate(xx),np.concatenate(yy),np.array(first)

def graph(p,x,g,model,scaler,lam):
 z=logit(np.clip(p,1e-6,1-1e-6));out=np.empty_like(p)
 for group in np.unique(g):
  rows=np.flatnonzero(g==group);assert len(rows)==8;edges=model.decision_function(scaler.transform(abs(x[rows[I]]-x[rows[J]])));ll=z[rows]@ASSIGNMENTS.T+(lam/4.)*(edges@SAME.T);ll-=ll.max();weight=np.exp(ll);weight/=weight.sum();out[rows]=np.clip(weight@ASSIGNMENTS,1e-6,1-1e-6)
 return out

def main():
 limits=threadpool_limits(limits=1);p=driver.protocol();pool=json.loads((driver.JOB/'completed_pool/protocol.json').read_text());positions=pool['member_positions'];cs=pool['members'];Cs=[.001,.01,.1];lams=[0.,.1,.25,.5,1.,2.];configs=[dict(C=C,lambda_graph=lam) for C in Cs for lam in lams];protocol=dict(pair_feature='Absolute difference of per8normalized aperiodic spectra and coarsepowers',pair_target='Same emotion withinperson/crop, source only',pair_weight_mass='Total equals original source windows; clinical50:50and pairclassbalanced',configs=configs,posterior='70balanced4of8assignments, unary logit pluslambda/4 edge sameclass logits',inner_selector='3innerdomainbalancedmean-.25std,DEPfloor-.005andmean+.001',unary_proxy='Clean equal83sourceOOF, matchedproxy control and LRtransfer final',proxy_vs_LR_mismatch_declared=True,script_sha256=driver.sha(__file__),development_cohort_reused=True,not5repeat_confirmation=True)
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==protocol
 else:driver.save(OUT/'protocol.json',protocol)
 with np.load(driver.ART/'features.npz') as a:meta={k:a[k] for k in ['subject','trial','crop','label','diagnosis','powers','spectrum']}
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:d={k:a[k] for k in a.files}
 with np.load(driver.CONTROL/'frozen_844161_baseline_oof.npz') as a:baseline=a['probability']
 mapping=d['model_row_to_full_row'];x=np.zeros((len(baseline),1500));valid_x=_features(meta,np.arange(len(mapping)),'aperiodic');assert valid_x.shape[1]==1500;x[mapping]=valid_x;eligible=np.zeros(len(x),bool);eligible[mapping]=True;g=np.char.add(np.char.add(d['subject'],':'),d['crop'].astype(str));results_q={k:np.full(len(x),.5) for k in ['graph_LR_transfer','graph_matched_proxy']};audits=[]
 for f in p['folds']:
  trv=np.flatnonzero(np.isin(meta['subject'],f['training_subjects']));vav=np.flatnonzero(np.isin(meta['subject'],f['validation_subjects']));lookup={v:j for j,v in enumerate(trv)};inside=np.zeros((len(cs),len(trv)));outside=np.zeros((len(cs),len(vav)))
  for j,i in enumerate(positions):
   m=p['members'][i]
   for part in ['inner0','inner1','inner2','outer']:
    t=dict(fold=f['fold'],part=part,index=m['candidate_index'],name=m['name'],family=m['family'],member_position=i);file,_=driver.paths(t)
    with np.load(file) as a:
     if part=='outer':assert np.array_equal(a['query_indices'],vav);outside[j]=a['logits']
     else:inside[j,[lookup[v] for v in a['query_indices']]]=a['logits']
  blinded=dict(meta);blinded['label']=np.full_like(meta['label'],-1);blinded['diagnosis']=np.full_like(meta['diagnosis'],-1);ii,scale=probability_bank(blinded,trv,inside,cs);oo,_=probability_bank(blinded,vav,outside,cs,scale);proxy=np.full(len(x),.5);proxy[mapping[trv]]=ii.mean(0);proxy[mapping[vav]]=oo.mean(0);tr=np.flatnonzero(np.isin(d['subject'],f['training_subjects']));va=np.flatnonzero(np.isin(d['subject'],f['validation_subjects']));local={v:j for j,v in enumerate(tr)};inner=np.full((len(configs),len(tr)),np.nan)
  for ik,part in enumerate(f['inner']):
   fit=np.flatnonzero(np.isin(d['subject'],part['training_subjects'])&eligible);val=np.flatnonzero(np.isin(d['subject'],part['validation_subjects']));px,py,first=pair_data(x[fit],d['label'][fit],g[fit]);sc=StandardScaler().fit(px);dx=d['diagnosis'][fit][first];w=np.ones(len(first))
   for v in [0,1]:w[dx==v]=len(w)/(2*np.sum(dx==v))
   w*=len(fit)/len(w)
   for C in Cs:
    model=LogisticRegression(C=C,solver='lbfgs',max_iter=2000,class_weight='balanced').fit(sc.transform(px),py,sample_weight=w)
    for j,c in enumerate(configs):
     if c['C']!=C:continue
     inner[j,[local[v] for v in val]]=graph(proxy[val],x[val],g[val],model,sc,c['lambda_graph'])
   print('RELATIONAL INNER',f['fold'],ik+1,flush=True)
  metrics=[]
  for q in inner:
   vals=[];deps=[]
   for part in f['inner']:
    mask=np.isin(d['subject'][tr],part['validation_subjects']);diag=d['diagnosis'][tr][mask];w=np.ones(mask.sum())
    for v in [0,1]:w[diag==v]=len(w)/(2*np.sum(diag==v))
    vals.append(roc_auc_score(d['label'][tr][mask],q[mask],sample_weight=w));dm=mask&(d['diagnosis'][tr]==1);deps.append(roc_auc_score(d['label'][tr][dm],q[dm]))
   metrics.append(dict(mean=float(np.mean(vals)),DEP=float(np.mean(deps)),stable=float(np.mean(vals)-.25*np.std(vals))))
  reference=next(i for i,c in enumerate(configs) if c['C']==.01 and c['lambda_graph']==0);ok=[i for i,c in enumerate(configs) if (c['lambda_graph']>0 and metrics[i]['mean']>=metrics[reference]['mean']+.001 and metrics[i]['DEP']>=metrics[reference]['DEP']-.005)]+[reference];best=max(ok,key=lambda i:metrics[i]['stable']);c=configs[best];fit=tr[eligible[tr]];px,py,first=pair_data(x[fit],d['label'][fit],g[fit]);sc=StandardScaler().fit(px);dx=d['diagnosis'][fit][first];w=np.ones(len(first))
  for v in [0,1]:w[dx==v]=len(w)/(2*np.sum(dx==v))
  w*=len(fit)/len(w);model=LogisticRegression(C=c['C'],solver='lbfgs',max_iter=2000,class_weight='balanced').fit(sc.transform(px),py,sample_weight=w);path=OUT/f'fold{f["fold"]}.joblib';joblib.dump(dict(model=model,scaler=sc,config=c,source_subjects=f['training_subjects']),path,compress=3);saved=joblib.load(path)
  for arm,unary in [('graph_LR_transfer',baseline),('graph_matched_proxy',proxy)]:
   q=graph(unary[va],x[va],g[va],model,sc,c['lambda_graph']);per=np.random.default_rng(f['fold']).permutation(len(va));other=graph(unary[va[per]],x[va[per]],np.char.add('opaque_',g[va[per]]),saved['model'],saved['scaler'],c['lambda_graph']);error=float(abs(other-q[per]).max());assert error<1e-10,error;results_q[arm][va]=q;audits.append(dict(fold=f['fold'],arm=arm,reload_order_metadata_error=error))
  driver.save(OUT/f'fold{f["fold"]}_selection.json',dict(config=c,source_metric=metrics[best],source_reference=metrics[reference],pair_train_people=np.unique(d['subject'][fit]).tolist()));print('RELATIONAL OUTER',f['fold'],'/5',c,flush=True)
 y=d['label'];s=d['subject'];dep=d['diagnosis']==1;w=np.where(dep,1.5,.75);ids=np.unique(s);ref=pair_matrix(y,baseline,s,ids);rng=np.random.default_rng(20261028);counts=np.zeros((2000,len(ids)))
 for j in range(len(counts)):
  for mask in [np.char.startswith(ids,'DEP'),np.char.startswith(ids,'HC')]:
   ix=np.flatnonzero(mask);counts[j]+=np.bincount(rng.choice(ix,len(ix),replace=True),minlength=len(ids))
 results={}
 for name,q in results_q.items():
  delta=pair_matrix(y,q,s,ids)-ref;boot=np.einsum('bi,ij,bj->b',counts,delta,counts,optimize=True)/counts.sum(1)**2;results[name]=dict(pooled10s_auc=float(roc_auc_score(y,q)),balanced10s_auc=float(roc_auc_score(y,q,sample_weight=w)),DEP10s_auc=float(roc_auc_score(y[dep],q[dep])),delta_vs_frozen_95CI=np.quantile(boot,[.025,.975]).tolist());np.savez_compressed(OUT/(name+'_oof.npz'),labels=y,subjects=s,probability=q)
 driver.save(OUT/'verification.json',dict(checks_passed=True,all5outer3inner=True,pair_labels_source_only=True,scalers_train_only=True,hyperparameters_source_inner_only=True,audits=audits,seal_and_official_test_not_read=True,submissions_performed=False));driver.save(OUT/'summary.json',dict(results=results,baseline_preserved=True,cohort_reused=True,not_multiple_search_corrected=True,proxy_to_LR_mismatch_declared=True,official_score_unknown=True));print('RELATIONAL STATE COMPLETE',json.dumps(results),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException:driver.save(OUT/'failure.json',dict(traceback=traceback.format_exc()));raise
