"""Reuse only already computed public frozen source encodings; verify provenance.
No backbone training/test access. BENDR mean/logstd/trend, real17channel BIOT
base outputs from SHHS+PREST and six-datasets weights. Own interface caveats
remain as declared in their original manifests, not advertised as bitwise DN3.
"""
from pathlib import Path
import json
import numpy as np
import driver
OUT=driver.JOB/'public_frozen_features_20261028';OUT.mkdir(exist_ok=True)
def main():
 with np.load(driver.ART/'features.npz') as a:meta={k:a[k] for k in ['subject','trial','crop']}
 definitions={'bendr':driver.JOB.parent/'foundation_features/bendr/development','biot_shhs':driver.JOB.parent/'foundation_features/reference_biot/shhs_prest/development','biot_six':driver.JOB.parent/'foundation_features/reference_biot/six_datasets/development'};manifests={k:json.loads((v/'manifest.json').read_text()) for k,v in definitions.items()};source=driver.protocol()['split'];arrays={'bendr':np.zeros((len(meta['subject']),1536),dtype='float32'),'biot':np.zeros((len(meta['subject']),512),dtype='float32')};records=[]
 for key,m in manifests.items():assert m['complete'] and m['frozen'] and not m['public_test_loaded'] and set(m['development_subjects'])==set(source['development']) and set(m['holdout_not_loaded'])==set(source['holdout'])
 assert driver.sha(driver.JOB.parent/'extract_bendr_features.py')==manifests['bendr']['script_sha256']
 assert all(driver.sha(driver.JOB.parent/'extract_reference_biot.py')==manifests[k]['script_sha256'] for k in ['biot_shhs','biot_six'])
 for subject in np.unique(meta['subject']):
  rows=np.flatnonzero(meta['subject']==subject);assert len(rows)==40 and np.array_equal(meta['trial'][rows],np.repeat(np.arange(1,9),5)) and np.array_equal(meta['crop'][rows],np.tile(np.arange(5),8));values={}
  for k,root in definitions.items():
   path=root/(subject+'.npz');assert driver.sha(path)==manifests[k]['files'][subject];records.append(dict(subject=str(subject),family=k,sha256=manifests[k]['files'][subject]))
   with np.load(path) as a:values[k]=np.concatenate([a['mean'],a['log_std'],a['trend']],axis=1) if k=='bendr' else a['base']
  arrays['bendr'][rows]=values['bendr'];arrays['biot'][rows]=np.concatenate([values['biot_shhs'],values['biot_six']],axis=1)
 for v in arrays.values():assert np.isfinite(v).all()
 path=OUT/'features.npz';np.savez_compressed(path,**meta,**arrays);driver.save(OUT/'features_ready.json',dict(complete=True,sha256=driver.sha(path),shapes={k:list(v.shape) for k,v in arrays.items()},external_frozen_weight_manifests={k:driver.sha(v/'manifest.json') for k,v in definitions.items()},sources=records,source_row_order_verified_from_original_loader=True,holdout_and_official_test_not_loaded=True));print('Public frozen features verified',flush=True)
if __name__=='__main__':main()
