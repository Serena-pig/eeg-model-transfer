"""Source60 paired nested SVM test: cached public BENDR and BIOT state features.
5outer/3inner same frozen split; 15C/gamma grid; train-only scalers. Primary
unit10s, auxiliary50s trial aggregation never treated as official-equivalent.
"""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import json,traceback,time
import numpy as np,joblib
from scipy.stats import norm,rankdata
from scipy.special import expit
from sklearn.preprocessing import StandardScaler
from sklearn.metrics.pairwise import euclidean_distances
from sklearn.svm import SVC
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits
import driver
from domain_models_v2 import _features
from select_ensemble import postprocess
from postflight import pair_matrix
OUT=driver.JOB/'public_frozen_svm_20261028';OUT.mkdir(exist_ok=True)
ARMS=['aperiodic','bendr_only','biot_only','aperiodic_bendr','aperiodic_biot']

def rank_context(x,g):
 out=np.zeros_like(x,dtype='float64')
 for group in np.unique(g):
  m=g==group;assert m.sum()==8;out[m]=norm.ppf((rankdata(x[m],axis=0)-.5)/8)
 return out

def kernels(c,dists):
 g=c['gamma'];k={name:np.exp(-g*x) for name,x in dists.items()}
 if c['kind'] in ['aperiodic','bendr','biot']:return k[c['kind']]
 block='bendr' if c['kind']=='mix_bendr' else 'biot';return (1-c['alpha'])*k['aperiodic']+c['alpha']*k[block]

def samplew(diag):
 w=np.ones(len(diag))
 for v in [0,1]:w[diag==v]=len(diag)/(2*np.sum(diag==v))
 return w

def main():
 limits=threadpool_limits(limits=1);p=driver.protocol();ready=json.loads((driver.JOB/'public_frozen_features_20261028/features_ready.json').read_text());assert ready['complete'];configs=[]
 for gamma in [.5,1.,2.]:
  for C in [.1,.3,1.,3.,10.]:
   for kind in ['aperiodic','bendr','biot']:configs.append(dict(kind=kind,alpha=1.,C=C,gamma=gamma))
   for kind in ['mix_bendr','mix_biot']:
    for alpha in [.25,.5]:configs.append(dict(kind=kind,alpha=alpha,C=C,gamma=gamma))
 protocol=dict(source_people=60,eligible_features_people=59,outer=5,inner=3,same_split_as_frozen84=True,configs=configs,primary_unit='single10swindow',auxiliary_unit='median5windows50strial_NOT_official_equivalent',primary_output='conditional4of8temperature1',scaler='StandardScaler.fit(trainingonly);per8rank is label-free atbothtrain/inference',source_selection='Mean3fold50:50domainAUC-.25std; additions requireDEPfloor-.005 andmeangain.001vsaperiodic',sealed_and_official_test_excluded=True,feature_sha256=ready['sha256'],script_sha256=driver.sha(__file__),not_exact_reproduction_of_missing_audit_v2=True,not5repeat_confirmation=True)
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==protocol
 else:driver.save(OUT/'protocol.json',protocol)
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:d={k:a[k] for k in a.files}
 mapping=d['model_row_to_full_row'];n=len(d['label']);eligible=np.zeros(n,dtype=bool);eligible[mapping]=True;groups=np.char.add(np.char.add(d['subject'],':'),d['crop'].astype(str))
 with np.load(driver.ART/'features.npz') as a:old={k:a[k] for k in ['subject','crop','powers','spectrum']}
 base=_features(old,np.arange(len(mapping)),'aperiodic');X={'aperiodic':np.zeros((n,base.shape[1]))};X['aperiodic'][mapping]=base
 with np.load(driver.JOB/'public_frozen_features_20261028/features.npz') as a:
  assert np.array_equal(a['subject'],old['subject'])
  for k in ['bendr','biot']:
   z=np.zeros((n,a[k].shape[1]));z[mapping]=a[k];X[k]=rank_context(z,groups)
 predictions={a:np.full(n,.5) for a in ARMS};raw_predictions={a:np.full(n,.5) for a in ARMS};audits=[];selections=[]
 for fold in p['folds']:
  tr=np.flatnonzero(np.isin(d['subject'],fold['training_subjects']));va=np.flatnonzero(np.isin(d['subject'],fold['validation_subjects']));lookup={v:j for j,v in enumerate(tr)};inner=np.full((len(configs),len(tr)),np.nan)
  for ik,s in enumerate(fold['inner']):
   fit=np.flatnonzero(np.isin(d['subject'],s['training_subjects'])&eligible);val=np.flatnonzero(np.isin(d['subject'],s['validation_subjects']));assert not set(d['subject'][fit])&set(d['subject'][val]);dist={};dv={}
   for name,x in X.items():
    sc=StandardScaler().fit(x[fit]);assert int(sc.n_samples_seen_)==len(fit);a=sc.transform(x[fit]);b=sc.transform(x[val]);dist[name]=euclidean_distances(a,squared=True)/a.shape[1];dv[name]=euclidean_distances(b,a,squared=True)/a.shape[1]
   weights=samplew(d['diagnosis'][fit]);current_gamma=None
   for j,c in enumerate(configs):
    if c['gamma']!=current_gamma:
     current_gamma=c['gamma'];kt={k:np.exp(-current_gamma*v) for k,v in dist.items()};kv={k:np.exp(-current_gamma*v) for k,v in dv.items()}
    if c['kind'].startswith('mix_'):
     block=c['kind'][4:];traink=(1-c['alpha'])*kt['aperiodic']+c['alpha']*kt[block];valk=(1-c['alpha'])*kv['aperiodic']+c['alpha']*kv[block]
    else:traink=kt[c['kind']];valk=kv[c['kind']]
    model=SVC(C=c['C'],kernel='precomputed',cache_size=128).fit(traink,d['label'][fit],sample_weight=weights);score=model.decision_function(valk);score[~eligible[val]]=0;inner[j,[lookup[v] for v in val]]=postprocess(score,groups[val],'conditional',1.)
   driver.save(OUT/'progress.json',dict(outer=fold['fold'],inner_completed=ik+1,total_outer=5,total_inner=3));print('STATE INNER COMPLETE',fold['fold'],ik+1,flush=True)
  assert np.isfinite(inner).all();parts=[np.isin(d['subject'][tr],s['validation_subjects']) for s in fold['inner']];metrics=[]
  for q in inner:
   values=[];dep=[]
   for m in parts:values.append(roc_auc_score(d['label'][tr][m],q[m],sample_weight=samplew(d['diagnosis'][tr][m])));v=m&(d['diagnosis'][tr]==1);dep.append(roc_auc_score(d['label'][tr][v],q[v]))
   metrics.append(dict(mean=float(np.mean(values)),std=float(np.std(values)),DEP=float(np.mean(dep)),score=float(np.mean(values)-.25*np.std(values))))
  baseline=max([i for i,c in enumerate(configs) if c['kind']=='aperiodic'],key=lambda i:metrics[i]['score']);choice={}
  for arm,kind in [('aperiodic','aperiodic'),('bendr_only','bendr'),('biot_only','biot'),('aperiodic_bendr','mix_bendr'),('aperiodic_biot','mix_biot')]:
   candidates=[i for i,c in enumerate(configs) if c['kind']==kind]
   if arm.startswith('aperiodic_'):
    candidates=[i for i in candidates if metrics[i]['DEP']>=metrics[baseline]['DEP']-.005 and metrics[i]['mean']>=metrics[baseline]['mean']+.001]+[baseline]
   choice[arm]=max(candidates,key=lambda i:metrics[i]['score'])
  fit=tr[eligible[tr]];scalers={};trainx={};dtrain={};dval={}
  for name,x in X.items():
   sc=StandardScaler().fit(x[fit]);scalers[name]=sc;trainx[name]=sc.transform(x[fit]);b=sc.transform(x[va]);dtrain[name]=euclidean_distances(trainx[name],squared=True)/x.shape[1];dval[name]=euclidean_distances(b,trainx[name],squared=True)/x.shape[1]
  for arm,index in choice.items():
   c=configs[index];model=SVC(C=c['C'],kernel='precomputed',cache_size=128).fit(kernels(c,dtrain),d['label'][fit],sample_weight=samplew(d['diagnosis'][fit]));z=model.decision_function(kernels(c,dval));z[~eligible[va]]=0;q=postprocess(z,groups[va],'conditional',1.);predictions[arm][va]=q;raw_predictions[arm][va]=expit(z);artifact=dict(model=model,config=c,scalers=scalers,train_x=trainx,source_subjects=np.unique(d['subject'][fit]).tolist(),feature_protocol_sha256=ready['sha256']);path=OUT/f'fold{fold["fold"]}_{arm}.joblib';joblib.dump(artifact,path,compress=3);saved=joblib.load(path);per=np.random.default_rng(fold['fold']).permutation(len(va));dd={}
   for name,x in X.items():xx=saved['scalers'][name].transform(x[va[per]]);dd[name]=euclidean_distances(xx,saved['train_x'][name],squared=True)/x.shape[1]
   zz=saved['model'].decision_function(kernels(saved['config'],dd));zz[~eligible[va[per]]]=0;replay=postprocess(zz,np.char.add('opaque_',groups[va[per]]),'conditional',1.);error=float(abs(replay-q[per]).max());assert error<1e-8,error;audits.append(dict(fold=fold['fold'],arm=arm,native_reload_order_metadata_delta=error,scalers_fit_training_only=True));selections.append(dict(fold=fold['fold'],arm=arm,config=c,source_inner=metrics[index],fallback_to_aperiodic=c['kind']=='aperiodic' and arm!='aperiodic'))
  np.savez_compressed(OUT/f'fold{fold["fold"]}_predictions.npz',validation_indices=va,**{k:v[va] for k,v in predictions.items()});driver.save(OUT/f'fold{fold["fold"]}_selections.json',[s for s in selections if s['fold']==fold['fold']]);print('STATE OUTER COMPLETE',fold['fold'],'/5',flush=True)
 y=d['label'];g=d['subject'];dep=d['diagnosis']==1;w=samplew(d['diagnosis'])
 with np.load(driver.CONTROL/'frozen_844161_baseline_oof.npz') as a:assert np.array_equal(y,a['labels']) and np.array_equal(g,a['subjects']);frozen=a['probability']
 allprobs=dict(predictions,frozen84=frozen);unique=np.unique(groups);pairmats={};panel_subject=[]
 for group in unique:
  rows=np.flatnonzero(groups==group);panel_subject.append(str(g[rows[0]]))
 panel_subject=np.array(panel_subject)
 for name,q in allprobs.items():pairmats[name]=pair_matrix(y,q,groups,unique)
 people=np.unique(g);hc=people[np.char.startswith(people,'HC')];dd=people[np.char.startswith(people,'DEP')];rng=np.random.default_rng(20261028);cohorts=[]
 for i in range(10000):
  chosen=np.r_[rng.choice(hc,5,replace=False),rng.choice(dd,5,replace=False)];cohorts.append([rng.choice(np.flatnonzero(panel_subject==s)) for s in chosen])
 cohort=np.array(cohorts);results={}
 for name,q in predictions.items():
  report=dict(pooled10s_auc=float(roc_auc_score(y,q)),balanced10s_auc=float(roc_auc_score(y,q,sample_weight=w)),DEP10s_auc=float(roc_auc_score(y[dep],q[dep])),raw10s_auc=float(roc_auc_score(y,raw_predictions[name])))
  for ref in ['aperiodic','frozen84']:
   delta=pairmats[name]-pairmats[ref];values=delta[cohort[:,:,None],cohort[:,None,:]].mean((1,2));report['sim80_vs_'+ref]=dict(median_delta=float(np.median(values)),P_positive=float(np.mean(values>0)),p10=float(np.quantile(values,.1)),not_fresh_confirmation=True,not5repeat_gate=True)
  # Trial median combines five distinct10s observations: separate diagnostic only.
  ids=np.char.add(np.char.add(g,':'),d['trial'].astype(str));uu=np.unique(ids);trialp=np.array([np.median(q[ids==s]) for s in uu]);trialy=np.array([y[np.flatnonzero(ids==s)[0]] for s in uu]);report['auxiliary50s_trial_median_auc']=float(roc_auc_score(trialy,trialp));results[name]=report;np.savez_compressed(OUT/(name+'_oof.npz'),labels=y,subjects=g,probability=q)
 driver.save(OUT/'verification.json',dict(checks_passed=True,all5outer3inner=True,audits=audits,train_only_scalers=True,inner_only_hyperparameter_and_fusion_selection=True,quality_bad_retained_validation=True,primary_unit10s=True,held_and_official_test_loaded=False,submissions_performed=False));driver.save(OUT/'summary.json',dict(results=results,baseline_frozen84_auc=float(roc_auc_score(y,frozen)),source60_not70=True,fivefold_not_fiverepeat=True,cohort_reused=True,official_score_unknown=True));print('STATE SVM COMPLETE',json.dumps(results),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException:driver.save(OUT/'failure.json',dict(traceback=traceback.format_exc()));raise
