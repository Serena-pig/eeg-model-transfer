"""Source-inner expert gating: new topology experts, clinical gate predictions.
Motivated by knownDEPweakness and exploratory diagnostics; cohort reused, NOT
new blind confirmation. No outer labels/diagnoses choose gating weights.
Selector equal83proxy vsfinalfrozenLR mismatch is explicitly declared.
"""
from pathlib import Path
import json,traceback
import numpy as np,joblib
from sklearn.metrics import roc_auc_score
import driver
from confidence_fusion_v11 import probability_bank
from context_rank_v34 import fit_context,context_features
from inner_calibration_round import calibrate
from postflight import pair_matrix
OUT=driver.JOB/'topology_clinical_gate_20261028';OUT.mkdir(exist_ok=True)
MODELS=['topo_oscillator_20261028','topo_fullspec_20261028']
def main():
 p=driver.protocol();pool=json.loads((driver.JOB/'completed_pool/protocol.json').read_text());positions=pool['member_positions'];cs=pool['members'];spec=dict(models=MODELS,gate_types=['global','soft_DEP','hard_DEP'],alphas=[0.,.1,.25,.5],clinical_gate='OriginalcontextPCA6/subjectcrossfitdiagnosisLR, no held diagnosis',source_selector='mean3innerbalancedAUC-.25std;requiremean+.001andDEPfloor-.005',base='FrozenLR with source-inner chosen label-freecountcalibration',fixed_controls='eachnewmodelsoftDEPalpha.25',source_proxy_vs_final_LR_mismatch=True,cohort_already_reused_for_hypotheses=True,script_sha256=driver.sha(__file__),no_outer_hyperparameter_or_diag_use=True)
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==spec
 else:driver.save(OUT/'protocol.json',spec)
 with np.load(driver.ART/'features.npz') as a:meta={k:a[k] for k in ['subject','trial','crop','label','diagnosis','powers','quality']}
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:d={k:a[k] for k in a.files}
 with np.load(driver.CONTROL/'frozen_844161_baseline_oof.npz') as a:frozen=a['probability']
 n=len(frozen);mapping=d['model_row_to_full_row'];groups=np.char.add(np.char.add(d['subject'],':'),d['crop'].astype(str));basecal=np.full(n,.5);probs={k:np.full(n,.5) for k in ['source_selected_LR_transfer','source_selected_matched_proxy',*['fixed_softDEP_'+m for m in MODELS]]};selections=[]
 for f in p['folds']:
  tr=np.flatnonzero(np.isin(meta['subject'],f['training_subjects']));va=np.flatnonzero(np.isin(meta['subject'],f['validation_subjects']));lookup={v:j for j,v in enumerate(tr)};inner=np.zeros((len(cs),len(tr)));outer=np.zeros((len(cs),len(va)))
  for j,i in enumerate(positions):
   m=p['members'][i]
   for part in ['inner0','inner1','inner2','outer']:
    t=dict(fold=f['fold'],part=part,index=m['candidate_index'],name=m['name'],family=m['family'],member_position=i);file,_=driver.paths(t)
    with np.load(file) as a:
     if part=='outer':assert np.array_equal(a['query_indices'],va);outer[j]=a['logits']
     else:inner[j,[lookup[v] for v in a['query_indices']]]=a['logits']
  blind=dict(meta);blind['label']=np.full_like(meta['label'],-1);blind['diagnosis']=np.full_like(meta['diagnosis'],-1);ii,scale=probability_bank(blind,tr,inner,cs);oo,_=probability_bank(blind,va,outer,cs,scale);proxy=np.full(n,.5);proxy[mapping[tr]]=ii.mean(0);proxy[mapping[va]]=oo.mean(0);source=dict(blind);source['diagnosis']=blind['diagnosis'].copy();source['diagnosis'][tr]=meta['diagnosis'][tr];context,extra=fit_context(source,tr);clinical=np.full(n,.5);clinical[mapping[tr]]=extra[:,6];clinical[mapping[va]]=context_features(blind,va,context)[:,6]
  trainrows=np.flatnonzero(np.isin(d['subject'],f['training_subjects']));validrows=np.flatnonzero(np.isin(d['subject'],f['validation_subjects']));y=d['label'][trainrows];diag=d['diagnosis'][trainrows];masks=[np.isin(d['subject'][trainrows],s['validation_subjects']) for s in f['inner']];mode=json.loads((driver.JOB/f'inner_calibration_20261028/fold{f["fold"]}_selection.json').read_text())['chosen'];basecal[validrows]=calibrate(frozen[validrows],groups[validrows],mode)
  neural={}
  for name in MODELS:
   q=np.full(n,.5)
   for part in ['inner0','inner1','inner2','outer']:
    with np.load(driver.JOB/name/f'fold{f["fold"]}_{part}.npz') as a:q[a['validation']]=a['probability']
   neural[name]=q
  def weight(gate,alpha,rows):
   v=np.ones(len(rows)) if gate=='global' else (clinical[rows] if gate=='soft_DEP' else (clinical[rows]>=.5).astype(float));return alpha*v
  def score(q):
   vv=[];dd=[]
   for mask in masks:
    dx=diag[mask];w=np.ones(mask.sum())
    for v in [0,1]:w[dx==v]=len(w)/(2*np.sum(dx==v))
    vv.append(roc_auc_score(y[mask],q[mask],sample_weight=w));z=mask&(diag==1);dd.append(roc_auc_score(y[z],q[z]))
   return dict(mean=float(np.mean(vv)),DEP=float(np.mean(dd)),stable=float(np.mean(vv)-.25*np.std(vv)))
  ref=score(proxy[trainrows]);best=dict(model=MODELS[0],gate='global',alpha=0.,metric=ref)
  for name in MODELS:
   for gate in spec['gate_types']:
    for alpha in [.1,.25,.5]:
     w=weight(gate,alpha,trainrows);met=score((1-w)*proxy[trainrows]+w*neural[name][trainrows])
     if met['mean']>=ref['mean']+.001 and met['DEP']>=ref['DEP']-.005 and met['stable']>best['metric']['stable']:best=dict(model=name,gate=gate,alpha=alpha,metric=met)
  w=weight(best['gate'],best['alpha'],validrows);probs['source_selected_LR_transfer'][validrows]=(1-w)*basecal[validrows]+w*neural[best['model']][validrows];probs['source_selected_matched_proxy'][validrows]=(1-w)*proxy[validrows]+w*neural[best['model']][validrows]
  for name in MODELS:
   w=weight('soft_DEP',.25,validrows);probs['fixed_softDEP_'+name][validrows]=(1-w)*basecal[validrows]+w*neural[name][validrows]
  joblib.dump(dict(context=context,selection=best,source_subjects=f['training_subjects'],calibration_mode=mode),OUT/f'fold{f["fold"]}_gate.joblib',compress=3);record=dict(fold=f['fold'],selection=best,source_reference=ref,query_diagnosis_hidden=True);selections.append(record);driver.save(OUT/f'fold{f["fold"]}_selection.json',record);print('CLINICAL GATE SELECTED',f['fold'],best['model'],best['gate'],best['alpha'],flush=True)
 y=d['label'];g=d['subject'];dep=d['diagnosis']==1;w=np.where(dep,1.5,.75);ids=np.unique(g);ref=pair_matrix(y,frozen,g,ids);rng=np.random.default_rng(20261028);counts=np.zeros((2000,len(ids)))
 for j in range(len(counts)):
  for mask in [np.char.startswith(ids,'DEP'),np.char.startswith(ids,'HC')]:
   ix=np.flatnonzero(mask);counts[j]+=np.bincount(rng.choice(ix,len(ix),replace=True),minlength=len(ids))
 results={}
 for name,q in probs.items():
  delta=pair_matrix(y,q,g,ids)-ref;boot=np.einsum('bi,ij,bj->b',counts,delta,counts,optimize=True)/counts.sum(1)**2;results[name]=dict(pooled10s_auc=float(roc_auc_score(y,q)),balanced10s_auc=float(roc_auc_score(y,q,sample_weight=w)),DEP10s_auc=float(roc_auc_score(y[dep],q[dep])),delta_vs_frozen_95CI=np.quantile(boot,[.025,.975]).tolist());np.savez_compressed(OUT/(name+'_oof.npz'),labels=y,subjects=g,probability=q)
 driver.save(OUT/'summary.json',dict(results=results,inner_only_selection=True,no_outer_query_diag_or_labels=True,proxy_mismatch_declared=True,cohort_reused=True,not_multiple_search_corrected=True,baseline_preserved=True,official_score_unknown=True,seal_and_official_test_not_read=True,submissions_performed=False));print('CLINICAL GATE COMPLETE',json.dumps(results),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException:driver.save(OUT/'failure.json',dict(traceback=traceback.format_exc()));raise
