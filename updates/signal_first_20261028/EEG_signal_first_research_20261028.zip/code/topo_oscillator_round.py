"""Small fixed topology CNN+BiGRU on short-time oscillatory residuals.
CPU prototype, not a reproduction of leaderboard's unpublished implementation.
Fixed20epochs, no outer early stopping. Model processes each trial identically;
no trial position/ID embeddings. Source async crop per video, clinical-balanced.
"""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import json,copy,random,traceback
import numpy as np,torch
from torch import nn
from torch.nn import functional as F
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits
import driver
from select_ensemble import postprocess,ASSIGNMENTS
from postflight import pair_matrix
OUT=driver.JOB/'topo_oscillator_20261028';OUT.mkdir(exist_ok=True)
POS=[(0,2),(0,4),(1,0),(1,2),(1,3),(1,4),(1,6),(2,0),(2,2),(2,3),(2,4),(2,6),(3,0),(3,2),(3,3),(3,4),(3,6),(4,0),(4,2),(4,3),(4,4),(4,6),(5,0),(5,2),(5,3),(5,4),(5,6),(6,2),(6,3),(6,4)]
class Net(nn.Module):
 def __init__(self):
  super().__init__();self.cnn=nn.Sequential(nn.Conv2d(5,8,3,padding=1),nn.GroupNorm(4,8),nn.GELU(),nn.Conv2d(8,8,3,padding=1),nn.GroupNorm(4,8),nn.GELU());self.spatial=nn.Sequential(nn.Flatten(),nn.Linear(8*7*7,32),nn.GELU(),nn.Dropout(.3));self.gru=nn.GRU(32,16,bidirectional=True,batch_first=True);self.attn=nn.Linear(32,1);self.head=nn.Sequential(nn.Linear(64,32),nn.GELU(),nn.Dropout(.3),nn.Linear(32,1))
 def forward(self,x):
  b,k,t,band,ch=x.shape;x=x-x.mean((1,2),keepdim=True);scale=x.mean(2).std(1,unbiased=False).clamp_min(.2);x=(x/scale[:,None,None]).clamp(-8,8);grid=x.new_zeros((b,k,t,band,7,7))
  for j,(r,c) in enumerate(POS):grid[:,:,:,:,r,c]=x[:,:,:,:,j]
  z=self.spatial(self.cnn(grid.reshape(b*k*t,band,7,7))).reshape(b*k,t,32);z,_=self.gru(z);pooled=(z*self.attn(z).softmax(1)).sum(1);spread=z.std(1,unbiased=False);out=self.head(torch.cat([pooled,spread],1)).reshape(b,k);return out-out.mean(1,keepdim=True)

def infer(model,x,rows):
 model.eval();out=[]
 with torch.no_grad():
  for start in range(0,len(rows),8):out.append(model(torch.tensor(x[rows[start:start+8]],dtype=torch.float32)).numpy())
 return np.concatenate(out)

def fit_task(x,d,tr,va,path,seed):
 random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.set_num_threads(1);rng=np.random.default_rng(seed);model=Net();opt=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.02);subjects=np.unique(d['subject'][tr]);person_rows=[];diag=[]
 for s in subjects:
  rows=tr[d['subject'][tr]==s];one=np.stack([rows[d['trial'][rows]==v][np.argsort(d['crop'][rows[d['trial'][rows]==v]])] for v in range(1,9)]);assert one.shape==(8,5);person_rows.append(one);diag.append(d['diagnosis'][rows[0]])
 person_rows=np.array(person_rows);diag=np.array(diag);pools=[np.flatnonzero(diag==v) for v in [0,1]];assign=torch.tensor(ASSIGNMENTS.T,dtype=torch.float32);steps=int(np.ceil(len(subjects)*5/4));scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(opt,20,eta_min=.00005);states=[]
 for epoch in range(1,21):
  model.train()
  for _ in range(steps):
   people=np.array([rng.choice(pools[j%2]) for j in range(4)]);crops=rng.integers(0,5,size=(4,8));rows=person_rows[people[:,None],np.arange(8)[None],crops];xb=torch.tensor(x[rows],dtype=torch.float32);yb=torch.tensor(d['label'][rows],dtype=torch.float32);xb=xb+torch.randn_like(xb)*.02;z=model(xb);bce=F.binary_cross_entropy_with_logits(z,yb*.98+.01);flat=z.flatten();label=yb.flatten();pair=F.softplus(flat[label<.5][None]-flat[label>.5][:,None]).mean();cond=(torch.logsumexp(z@assign,1)-(z*yb).sum(1)).mean()/4;loss=.5*bce+.25*pair+.25*cond+.002*(z*z).mean();opt.zero_grad(set_to_none=True);loss.backward();nn.utils.clip_grad_norm_(model.parameters(),3);opt.step()
  scheduler.step()
  if epoch in [16,18,20]:states.append({k:v.detach().clone() for k,v in model.state_dict().items()})
 groups=np.char.add(np.char.add(d['subject'][va],':'),d['crop'][va].astype(str));unique=np.unique(groups);rr=np.stack([va[groups==g] for g in unique]);assert rr.shape[1]==8;pred=[]
 for state in states:model.load_state_dict(state);pred.append(infer(model,x,rr))
 z=np.mean(pred,axis=0);prob=postprocess(z.ravel(),np.repeat(unique,8),'conditional',1.);result=np.zeros(len(va));lookup={v:j for j,v in enumerate(va)};result[[lookup[v] for v in rr.ravel()]]=prob
 torch.save(dict(states=states,seed=seed,source_subjects=subjects.tolist(),epochs=20,schematic_grid=POS,not_actual_physical_coordinates=True),path);saved=torch.load(path,map_location='cpu',weights_only=False);replay=[]
 for state in saved['states']:model.load_state_dict(state);replay.append(infer(model,x,rr[:,::-1]))
 zr=np.mean(replay,axis=0)[:,::-1];error=float(abs(zr-z).max());assert error<1e-5,error
 return result,error

def main():
 limits=threadpool_limits(limits=1);torch.set_num_threads(1);torch.use_deterministic_algorithms(True);p=driver.protocol();spec=dict(input='9frames2sSTFToscillatoryresidual5bands30channels',topology='Schematic7x7standard10-20grid,notphysicaldistance',CNN='2conv8channels,GroupNorm,spatial32',BiGRU='16eachdirection,attention+spread',epochs=20,checkpoints=[16,18,20],seed=20261028,source_async_video_crops=True,clinical_balanced=True,fixed_10pct_fusion_with_frozen=True,no_outer_early_stopping_or_hyperparameter_search=True,all5outer3inner=True,script_sha256=driver.sha(__file__))
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==spec
 else:driver.save(OUT/'protocol.json',spec)
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:d={k:a[k] for k in a.files}
 with np.load(driver.JOB/'state_features_20261028/features.npz') as a:raw=a['osc_sequence']
 x=np.zeros((len(d['label']),)+raw.shape[1:],dtype='float32');x[d['model_row_to_full_row']]=raw;eligible=np.zeros(len(x),dtype=bool);eligible[d['model_row_to_full_row']]=True;pout=np.full(len(x),.5);audits=[]
 for f in p['folds']:
  for part in ['inner0','inner1','inner2','outer']:
   split=f if part=='outer' else f['inner'][int(part[-1])];tr=np.flatnonzero(np.isin(d['subject'],split['training_subjects'])&eligible);va=np.flatnonzero(np.isin(d['subject'],split['validation_subjects']));assert not set(d['subject'][tr])&set(d['subject'][va]);cache=OUT/f'fold{f["fold"]}_{part}.npz'
   if cache.exists():
    with np.load(cache) as a:assert np.array_equal(a['validation'],va);q=a['probability'];error=float(a['reload_error'])
   else:q,error=fit_task(x,d,tr,va,cache.with_suffix('.pt'),20261028);np.savez_compressed(cache,validation=va,probability=q,reload_error=error)
   if part=='outer':pout[va]=q
   audits.append(dict(fold=f['fold'],part=part,reload_within8_permutation_delta=error,source_subject_disjoint=True));driver.save(OUT/'progress.json',dict(tasks_completed=len(audits),total=20,fold=f['fold'],part=part));print('TOPO OSC COMPLETE',len(audits),'/20',flush=True)
 with np.load(driver.CONTROL/'frozen_844161_baseline_oof.npz') as a:baseline=a['probability'];assert np.array_equal(d['label'],a['labels'])
 y=d['label'];g=d['subject'];dep=d['diagnosis']==1;w=np.where(dep,1.5,.75);people=np.unique(g);ref=pair_matrix(y,baseline,g,people);rng=np.random.default_rng(20261028);counts=np.zeros((2000,len(people)))
 for j in range(len(counts)):
  for mask in [np.char.startswith(people,'DEP'),np.char.startswith(people,'HC')]:
   ix=np.flatnonzero(mask);counts[j]+=np.bincount(rng.choice(ix,len(ix),replace=True),minlength=len(people))
 results={}
 for name,q in [('topology_osc_CNN_BiGRU',pout),('fixed10pct_fusion',.9*baseline+.1*pout)]:
  delta=pair_matrix(y,q,g,people)-ref;boot=np.einsum('bi,ij,bj->b',counts,delta,counts,optimize=True)/counts.sum(1)**2;results[name]=dict(pooled10s_auc=float(roc_auc_score(y,q)),balanced10s_auc=float(roc_auc_score(y,q,sample_weight=w)),DEP10s_auc=float(roc_auc_score(y[dep],q[dep])),difference_vs_frozen_95CI=np.quantile(boot,[.025,.975]).tolist());np.savez_compressed(OUT/(name+'_oof.npz'),labels=y,subjects=g,probability=q)
 driver.save(OUT/'verification.json',dict(checks_passed=True,all20sourcefits_complete=True,all5outer3inner=True,audits=audits,source_only_fit=True,no_outer_labels_for_earlystop=True,holdout_and_test_not_read=True,submissions_performed=False));driver.save(OUT/'summary.json',dict(results=results,baseline_preserved=True,cohort_reused=True,official_score_unknown=True,not_multiple_search_corrected=True));print('TOPO OSC ROUND COMPLETE',json.dumps(results),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException:driver.save(OUT/'failure.json',dict(traceback=traceback.format_exc()));raise
