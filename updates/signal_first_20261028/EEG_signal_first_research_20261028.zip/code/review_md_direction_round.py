"""Independent native clinical gating replay and numeric tie audit.
Does not change any model, frozen baseline or historical prediction file.
"""
from pathlib import Path
import json
import numpy as np,joblib
from sklearn.metrics import roc_auc_score
import driver
from context_rank_v34 import context_features
from inner_calibration_round import calibrate

def main():
 p=driver.protocol()
 with np.load(driver.ART/'features.npz') as a:meta={k:a[k] for k in ['subject','trial','crop','label','diagnosis','powers','quality']}
 meta['label']=np.full_like(meta['label'],-1);meta['diagnosis']=np.full_like(meta['diagnosis'],-1)
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:d={k:a[k] for k in a.files}
 with np.load(driver.CONTROL/'frozen_844161_baseline_oof.npz') as a:baseline=a['probability']
 root=driver.JOB/'topology_clinical_gate_20261028';names=['source_selected_LR_transfer','fixed_softDEP_topo_oscillator_20261028','fixed_softDEP_topo_fullspec_20261028'];reference={}
 for name in names:
  with np.load(root/(name+'_oof.npz')) as a:reference[name]=a['probability']
 output={k:np.full(len(baseline),.5) for k in names};records=[];mapping=d['model_row_to_full_row'];groups=np.char.add(np.char.add(d['subject'],':'),d['crop'].astype(str))
 for fold in p['folds']:
  artifact=joblib.load(root/f'fold{fold["fold"]}_gate.joblib');va=np.flatnonzero(np.isin(meta['subject'],fold['validation_subjects']));rows=np.flatnonzero(np.isin(d['subject'],fold['validation_subjects']));gate=np.full(len(baseline),.5);gate[mapping[va]]=context_features(meta,va,artifact['context'])[:,6];perm=np.random.default_rng(fold['fold']).permutation(len(va));opaque=dict(meta);opaque['subject']=np.char.add('opaque_',meta['subject']);delta=float(abs(context_features(opaque,va[perm],artifact['context'])[:,6]-gate[mapping[va]][perm]).max());assert delta<1e-12
  base=calibrate(baseline[rows],groups[rows],artifact['calibration_mode']);nn={}
  for model in ['topo_oscillator_20261028','topo_fullspec_20261028']:
   with np.load(driver.JOB/model/f'fold{fold["fold"]}_outer.npz') as a:assert np.array_equal(a['validation'],rows);nn[model]=a['probability']
  s=artifact['selection'];w=np.full(len(rows),s['alpha']) if s['gate']=='global' else s['alpha']*(gate[rows] if s['gate']=='soft_DEP' else (gate[rows]>=.5));output['source_selected_LR_transfer'][rows]=(1-w)*base+w*nn[s['model']]
  for model,q in nn.items():w=.25*gate[rows];output['fixed_softDEP_'+model][rows]=(1-w)*base+w*q
  records.append(dict(fold=fold['fold'],native_gate_metadata_order_delta=delta,query_diagnosis_all_hidden=True))
 for name,q in output.items():assert np.max(abs(q-reference[name]))<1e-12
 result=dict(checks_passed=True,clinical_gating_native_replay=True,source_selected_and_fixedcontrols_match=True,records=records,numeric_policy='Reporting12decimalrounded scores to remove sub-machine tie-order artifacts;no new training or choices')
 folders=['state_svm_20261028','trial_prototype_svm_20261028','public_frozen_svm_20261028','topo_oscillator_20261028','topo_fullspec_20261028','topology_inner_fusion_20261028','topology_clinical_gate_20261028','relational_state_20261028'];metrics={}
 for folder in folders:
  for path in (driver.JOB/folder).glob('*_oof.npz'):
   with np.load(path) as a:y=a['labels'];s=a['subjects'];q=a['probability']
   dep=np.char.startswith(s,'DEP');w=np.where(dep,1.5,.75);rounded=np.round(q,12);metrics[str(path.relative_to(driver.JOB))]=dict(raw_pooled_auc=float(roc_auc_score(y,q)),canonical_pooled10s_auc=float(roc_auc_score(y,rounded)),canonical_balanced10s_auc=float(roc_auc_score(y,rounded,sample_weight=w)),canonical_DEP10s_auc=float(roc_auc_score(y[dep],rounded[dep])))
 result['canonical_metrics']=metrics;driver.save(driver.CONTROL/'MD_DIRECTIONS_INDEPENDENT_REVIEW.json',result);print('MD directions independent gate replay, source controls and canonical score review complete',flush=True)
if __name__=='__main__':main()
