"""Label-free40-bin short-time residual spectral shape, NOT five DE bands."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import numpy as np
from scipy.signal import stft
from scipy.ndimage import gaussian_filter1d
from pathlib import Path
from threadpoolctl import threadpool_limits
import driver
OUT=driver.JOB/'full_osc_sequence_20261028';OUT.mkdir(exist_ok=True)
def main():
 limits=threadpool_limits(limits=1)
 with np.load(driver.ART/'features.npz') as a:meta={k:a[k] for k in ['subject','trial','crop']}
 raw=np.load(driver.ART/'raw_125hz.npy',mmap_mode='r');seq=np.zeros((len(raw),9,40,30),dtype='float32')
 for start in range(0,len(raw),40):
  f,_,z=stft(np.asarray(raw[start:start+40],dtype='float64'),fs=125,window='hann',nperseg=250,noverlap=125,boundary=None,padded=False);keep=(f>=1)&(f<41);f=f[keep];v=np.log(np.maximum(abs(z[:,:,keep,:])**2,1e-12));design=np.column_stack([np.ones(len(f)),np.log(f)]);co=np.einsum('af,ncft->ncat',np.linalg.pinv(design),v);r=gaussian_filter1d(v-np.einsum('fa,ncat->ncft',design,co),1.,axis=2);out=np.stack([r[:,:,(f>=hz)&(f<hz+1),:].mean(2) for hz in range(1,41)],axis=2).transpose(0,3,2,1);seq[start:start+len(out)]=out
 assert np.isfinite(seq).all();path=OUT/'features.npz';np.savez_compressed(path,**meta,osc_sequence=seq);driver.save(OUT/'manifest.json',dict(shape=list(seq.shape),source_people=59,feature_definition='2sSTFT1shop,1-40Hz1Hzbins,OLSlogfresidual,notIRASA',labels_diagnosis_not_read=True,holdout_test_not_read=True,sha256=driver.sha(path),script_sha256=driver.sha(__file__)));print('Full40Hz oscillatory sequence complete',flush=True)
if __name__=='__main__':main()
