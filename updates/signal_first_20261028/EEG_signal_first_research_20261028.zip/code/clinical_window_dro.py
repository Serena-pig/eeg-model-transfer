"""Prespecified robust meta objectives on clinical-group x training-window cells.
Window index and true diagnosis define TRAINING risk only, never predict inputs.
Motivated by exploratory source diagnostics; no independent-cohort claim.
"""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import json,traceback
import numpy as np,joblib
from scipy.special import expit,logsumexp
from scipy.optimize import minimize
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits
import driver
from nonlinear_rank_v18 import features
from context_rank_v34 import fit_context,context_features
from inner_calibration_round import calibrate
from postflight import pair_matrix
OUT=driver.JOB/'clinical_window_dro_20261028';OUT.mkdir(exist_ok=True)
NAMES=['cell_BCE_DRO','cell_AUC_DRO']
def main():
 limits=threadpool_limits(limits=1);p=driver.protocol();pool=json.loads((driver.JOB/'completed_pool/protocol.json').read_text());cs=pool['members'];positions=pool['member_positions'];spec=dict(variants=NAMES,temperature_fixed=5.,regularization_C_inherited=.01,BCE_risk_mix_fixed=.5,AUC_objective=[.5,.25,.25],pair_count_global=10000,pair_count_per_cell=1000,cells='Source diagnosis x 5relative10spositions',no_window_or_diagnosis_predict_inputs=True,all_constants_fixed_no_own_outer_tuning=True,cohort_reused_for_hypothesis=True,script_sha256=driver.sha(__file__))
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==spec
 else:driver.save(OUT/'protocol.json',spec)
 with np.load(driver.ART/'features.npz') as a:meta={k:a[k] for k in ['subject','diagnosis','label','trial','crop','train','powers','quality']}
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:d={k:a[k] for k in a.files}
 with np.load(driver.CONTROL/'frozen_844161_baseline_oof.npz') as a:baseline=a['probability']
 mapping=d['model_row_to_full_row'];probs={n:np.full(len(baseline),.5) for n in NAMES+[n+'_calibrated' for n in NAMES]};audits=[]
 for f in p['folds']:
  tr=np.flatnonzero(np.isin(meta['subject'],f['training_subjects']));va=np.flatnonzero(np.isin(meta['subject'],f['validation_subjects']));lookup={v:j for j,v in enumerate(tr)};inside=np.zeros((len(cs),len(tr)));outside=np.zeros((len(cs),len(va)))
  for j,i in enumerate(positions):
   m=p['members'][i]
   for part in ['inner0','inner1','inner2','outer']:
    t=dict(fold=f['fold'],part=part,index=m['candidate_index'],name=m['name'],family=m['family'],member_position=i);file,_=driver.paths(t)
    with np.load(file) as a:
     if part=='outer':assert np.array_equal(a['query_indices'],va);outside[j]=a['logits']
     else:inside[j,[lookup[v] for v in a['query_indices']]]=a['logits']
  old=joblib.load(driver.JOB/f'completed_pool_linear/meta_fold{f["fold"]}.joblib');blind=dict(meta);blind['label']=np.full_like(meta['label'],-1);blind['diagnosis']=np.full_like(meta['diagnosis'],-1);source=dict(blind);source['diagnosis']=blind['diagnosis'].copy();source['diagnosis'][tr]=meta['diagnosis'][tr];raw,_=features(source,tr,inside,cs,old['scales']);context,extra=fit_context(source,tr);x=old['scaler'].transform(np.column_stack([raw,extra]));y=meta['label'][tr];diag=meta['diagnosis'][tr];cell=diag*5+meta['crop'][tr];cells=[np.flatnonzero(cell==v) for v in range(10)];w=np.ones(len(tr))
  for v in [0,1]:w[diag==v]=len(tr)/(2*np.sum(diag==v))
  wn=w/w.sum();reg=1/(.01*len(tr));rng=np.random.default_rng(20261028+f['fold']);pos=np.flatnonzero(y==1);neg=np.flatnonzero(y==0);a=rng.choice(pos,10000,p=w[pos]/w[pos].sum());b=rng.choice(neg,10000,p=w[neg]/w[neg].sum());DG=x[a]-x[b];DC=[]
  for rr in cells:
   pos=rr[y[rr]==1];neg=rr[y[rr]==0];DC.append(x[rng.choice(pos,1000)]-x[rng.choice(neg,1000)])
  models={};start=np.r_[old['model'].coef_[0],old['model'].intercept_[0]]
  for name in NAMES:
   def objective(theta):
    beta=theta[:-1];z=x@beta+theta[-1];losses=np.logaddexp(0,z)-y*z;err=expit(z)-y;base=float(np.dot(wn,losses));grad_beta=x.T@(wn*err);grad_bias=float(np.dot(wn,err))
    if name=='cell_BCE_DRO':
     losses_cell=np.array([losses[rr].mean() for rr in cells]);q=np.exp(5*losses_cell-logsumexp(5*losses_cell));risk=(logsumexp(5*losses_cell)-np.log(10))/5;rw=np.zeros(len(tr))
     for qv,rr in zip(q,cells):rw[rr]=qv/len(rr)
     value=.5*base+.5*risk;gb=.5*grad_beta+.5*x.T@(rw*err);gi=.5*grad_bias+.5*np.dot(rw,err)
    else:
     ag=DG@beta;cg=[D@beta for D in DC];losses_cell=np.array([np.logaddexp(0,-a).mean() for a in cg]);q=np.exp(5*losses_cell-logsumexp(5*losses_cell));risk=(logsumexp(5*losses_cell)-np.log(10))/5;gg=-(DG.T@expit(-ag))/len(DG);gc=sum(-qv*(D.T@expit(-a))/len(D) for qv,D,a in zip(q,DC,cg));value=.5*base+.25*np.logaddexp(0,-ag).mean()+.25*risk;gb=.5*grad_beta+.25*gg+.25*gc;gi=.5*grad_bias
    return value+.5*reg*np.dot(beta,beta),np.r_[gb+reg*beta,gi]
   if f['fold']==1:
    _,grad=objective(start)
    for j in [0,len(start)//2,len(start)-1]:
     ap=start.copy();bp=start.copy();ap[j]+=1e-6;bp[j]-=1e-6;error=abs((objective(ap)[0]-objective(bp)[0])/2e-6-grad[j]);assert error<1e-5,error
   fit=minimize(objective,start,jac=True,method='L-BFGS-B',options=dict(maxiter=500,ftol=1e-12,gtol=1e-7));assert fit.success,fit.message;models[name]=fit.x
  artifact=dict(models=models,scaler=old['scaler'],scales=old['scales'],context=context,protocol=spec,source_subjects=f['training_subjects']);path=OUT/f'fold{f["fold"]}.joblib';joblib.dump(artifact,path,compress=3);saved=joblib.load(path)
  def design(q,rows,z,art):
   a,_=features(q,rows,z,cs,art['scales']);return art['scaler'].transform(np.column_stack([a,context_features(q,rows,art['context'])]))
  xv=design(blind,va,outside,artifact);perm=np.random.default_rng(f['fold']).permutation(len(va));query=dict(blind);query['subject']=np.char.add('opaque_',meta['subject']);query['crop']=meta['crop'].copy();query['trial']=np.zeros_like(meta['trial']);sx=design(query,va[perm],outside[:,perm],saved);groups=np.char.add(np.char.add(meta['subject'][va],':'),meta['crop'][va].astype(str));mode=json.loads((driver.JOB/f'inner_calibration_20261028/fold{f["fold"]}_selection.json').read_text())['chosen']
  for name in NAMES:
   theta=models[name];q=expit(xv@theta[:-1]+theta[-1]);rr=saved['models'][name];replay=expit(sx@rr[:-1]+rr[-1]);error=float(abs(replay-q[perm]).max());assert error<1e-10,error;probs[name][mapping[va]]=np.round(q,12);probs[name+'_calibrated'][mapping[va]]=np.round(calibrate(q,groups,mode),12);audits.append(dict(fold=f['fold'],variant=name,native_reload_order_delta=error,held_diagnosis_and_window_index_not_predict_features=True))
  print('CLINICAL WINDOW DRO OUTER',f['fold'],'/5',flush=True)
 y=d['label'];g=d['subject'];dep=d['diagnosis']==1;w=np.where(dep,1.5,.75);ids=np.unique(g);ref=pair_matrix(y,baseline,g,ids);rng=np.random.default_rng(20261028);counts=np.zeros((2000,len(ids)))
 for j in range(len(counts)):
  for mask in [np.char.startswith(ids,'DEP'),np.char.startswith(ids,'HC')]:
   ix=np.flatnonzero(mask);counts[j]+=np.bincount(rng.choice(ix,len(ix),replace=True),minlength=len(ids))
 results={}
 for name,q in probs.items():
  delta=pair_matrix(y,q,g,ids)-ref;boot=np.einsum('bi,ij,bj->b',counts,delta,counts,optimize=True)/counts.sum(1)**2;results[name]=dict(pooled10s_auc=float(roc_auc_score(y,q)),balanced10s_auc=float(roc_auc_score(y,q,sample_weight=w)),DEP10s_auc=float(roc_auc_score(y[dep],q[dep])),delta_vs_frozen_95CI=np.quantile(boot,[.025,.975]).tolist());np.savez_compressed(OUT/(name+'_oof.npz'),labels=y,subjects=g,probability=q)
 driver.save(OUT/'verification.json',dict(checks_passed=True,all5outer3inner=True,analytic_gradients_checked=True,audits=audits,source_risk_groups_only=True,seal_and_official_test_not_read=True,submissions_performed=False));driver.save(OUT/'summary.json',dict(results=results,baseline_preserved=True,cohort_reused=True,not_multiple_search_corrected=True,official_score_unknown=True));print('CLINICAL WINDOW DRO COMPLETE',json.dumps(results),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException:driver.save(OUT/'failure.json',dict(traceback=traceback.format_exc()));raise
