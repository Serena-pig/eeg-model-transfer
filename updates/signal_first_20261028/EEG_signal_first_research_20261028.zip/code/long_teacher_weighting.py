"""Long50s source-teacher confidence weighting for10s SVM student.
Teacher is subject-crossfitted INSIDE each current training split. Labels remain
original hard source labels; no pseudo EEG/no new observations. Weight mass
normalized within each sourceperson/class, preserving DEP contribution.
"""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import json,traceback
import numpy as np,joblib
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics.pairwise import euclidean_distances
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits
import driver
from domain_models_v2 import _features
from trial_prototype_svm import prototype_data,samplew
from select_ensemble import postprocess
from postflight import pair_matrix
OUT=driver.JOB/'long_teacher_weighting_20261028';OUT.mkdir(exist_ok=True)

def teacher_weight(x,fit,d,tag):
 px,py,pdiag,ps=prototype_data(x,fit,d);people=np.unique(ps);dx=np.array([pdiag[np.flatnonzero(ps==s)[0]] for s in people]);pred=np.full(len(py),np.nan);audit=[]
 for k,(ti,vi) in enumerate(StratifiedKFold(3,shuffle=True,random_state=20261028).split(people,dx)):
  train=np.isin(ps,people[ti]);val=np.isin(ps,people[vi]);assert set(ps[train]).isdisjoint(ps[val]);sc=StandardScaler().fit(px[train]);model=SVC(C=3.,gamma=1/px.shape[1],kernel='rbf',cache_size=128).fit(sc.transform(px[train]),py[train],sample_weight=samplew(pdiag[train])*5);z=model.decision_function(sc.transform(px[val]));pred[val]=postprocess(z,ps[val],'conditional',1.);audit.append(dict(training=people[ti].tolist(),held=people[vi].tolist()))
 assert np.isfinite(pred).all();pt=np.where(py==1,pred,1-pred);weight=np.ones(len(fit));raw=.25+.75*pt
 # prototype_data sorts subject:trial strings; each subject always eight trials.
 lookup={}
 for i,s in enumerate(ps):lookup.setdefault(str(s),[]).append(i)
 for s,ids in lookup.items():
  rows=fit[d['subject'][fit]==s];trial_ids=sorted(np.unique(d['trial'][rows]));assert len(ids)==len(trial_ids)==8
  for label in [0,1]:
   selected=[i for i in ids if py[i]==label];den=raw[selected].mean()
   for i in selected:
    trial=trial_ids[list(ids).index(i)];positions=np.flatnonzero((d['subject'][fit]==s)&(d['trial'][fit]==trial));assert len(positions)==5;weight[positions]=raw[i]/den
  for label in [0,1]:assert abs(weight[(d['subject'][fit]==s)&(d['label'][fit]==label)].mean()-1)<1e-12
 driver.save(OUT/(tag+'_teacher_audit.json'),dict(teacher_C_fixed=3.,teacher_gamma_fixed='1/feature_dim',subfolds=audit,no_held_subject_seen_by_its_teacher=True,weights_normalized_perperson_perclass=True))
 return weight

def main():
 limits=threadpool_limits(limits=1);p=driver.protocol();configs=[dict(C=C,gamma=g,weight_strength=a) for g in [.5,1.,2.] for C in [.1,.3,1.,3.,10.] for a in [0.,.5,1.]];spec=dict(configs=configs,teacher='50smedianfeatureprototype,SVM,C3,gamma1/dim,3foldsubjectcrossfitinsideeverytrainingsplit',weight='confidence floor.25, normalized perperson/class',primary_unit10s=True,selection='3innermeanbalanced-.25std,DEPfloor-.005andgain.001vsunweighted',fixed_fusion_weight=.1,script_sha256=driver.sha(__file__),cohort_reused=True,not5repeat_confirmation=True)
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==spec
 else:driver.save(OUT/'protocol.json',spec)
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:d={k:a[k] for k in a.files}
 mapping=d['model_row_to_full_row'];n=len(d['label']);eligible=np.zeros(n,bool);eligible[mapping]=True;groups=np.char.add(np.char.add(d['subject'],':'),d['crop'].astype(str))
 with np.load(driver.ART/'features.npz') as a:old={k:a[k] for k in ['subject','crop','powers','spectrum']}
 small=_features(old,np.arange(len(mapping)),'aperiodic');x=np.zeros((n,small.shape[1]));x[mapping]=small;pred=np.full(n,.5);ref=pred.copy();audits=[]
 for f in p['folds']:
  tr=np.flatnonzero(np.isin(d['subject'],f['training_subjects']));va=np.flatnonzero(np.isin(d['subject'],f['validation_subjects']));lookup={v:j for j,v in enumerate(tr)};oof=np.full((len(configs),len(tr)),np.nan)
  for ik,part in enumerate(f['inner']):
   fit=np.flatnonzero(np.isin(d['subject'],part['training_subjects'])&eligible);val=np.flatnonzero(np.isin(d['subject'],part['validation_subjects']));tw=teacher_weight(x,fit,d,f'fold{f["fold"]}_inner{ik}');sc=StandardScaler().fit(x[fit]);xx=sc.transform(x[fit]);D=euclidean_distances(xx,squared=True)/x.shape[1];DV=euclidean_distances(sc.transform(x[val]),xx,squared=True)/x.shape[1];w=samplew(d['diagnosis'][fit]);current=None
   for j,c in enumerate(configs):
    if current!=c['gamma']:current=c['gamma'];K=np.exp(-current*D);KV=np.exp(-current*DV)
    ww=w*((1-c['weight_strength'])+c['weight_strength']*tw);model=SVC(C=c['C'],kernel='precomputed',cache_size=128).fit(K,d['label'][fit],sample_weight=ww);score=model.decision_function(KV);score[~eligible[val]]=0;oof[j,[lookup[v] for v in val]]=np.round(postprocess(score,groups[val],'conditional',1.),12)
   print('LONG TEACHER INNER',f['fold'],ik+1,flush=True)
  metrics=[]
  for q in oof:
   vv=[];deps=[]
   for part in f['inner']:
    m=np.isin(d['subject'][tr],part['validation_subjects']);vv.append(roc_auc_score(d['label'][tr][m],q[m],sample_weight=samplew(d['diagnosis'][tr][m])));dm=m&(d['diagnosis'][tr]==1);deps.append(roc_auc_score(d['label'][tr][dm],q[dm]))
   metrics.append(dict(mean=float(np.mean(vv)),DEP=float(np.mean(deps)),stable=float(np.mean(vv)-.25*np.std(vv))))
  reference=max([i for i,c in enumerate(configs) if c['weight_strength']==0],key=lambda i:metrics[i]['stable']);ok=[i for i,c in enumerate(configs) if c['weight_strength']>0 and metrics[i]['mean']>=metrics[reference]['mean']+.001 and metrics[i]['DEP']>=metrics[reference]['DEP']-.005]+[reference];chosen=max(ok,key=lambda i:metrics[i]['stable']);fit=tr[eligible[tr]];tw=teacher_weight(x,fit,d,f'fold{f["fold"]}_outer');sc=StandardScaler().fit(x[fit]);xx=sc.transform(x[fit]);D=euclidean_distances(xx,squared=True)/x.shape[1];DV=euclidean_distances(sc.transform(x[va]),xx,squared=True)/x.shape[1];w=samplew(d['diagnosis'][fit])
  for name,index in [('reference',reference),('weighted',chosen)]:
   c=configs[index];model=SVC(C=c['C'],kernel='precomputed',cache_size=128).fit(np.exp(-c['gamma']*D),d['label'][fit],sample_weight=w*((1-c['weight_strength'])+c['weight_strength']*tw));z=model.decision_function(np.exp(-c['gamma']*DV));z[~eligible[va]]=0;q=np.round(postprocess(z,groups[va],'conditional',1.),12);(ref if name=='reference' else pred)[va]=q;artifact=dict(model=model,scaler=sc,train_x=xx,config=c,source_subjects=np.unique(d['subject'][fit]).tolist(),source_teacher_weight=tw);path=OUT/f'fold{f["fold"]}_{name}.joblib';joblib.dump(artifact,path,compress=3);saved=joblib.load(path);per=np.random.default_rng(f['fold']).permutation(len(va));kv=np.exp(-c['gamma']*euclidean_distances(saved['scaler'].transform(x[va[per]]),saved['train_x'],squared=True)/x.shape[1]);zz=saved['model'].decision_function(kv);zz[~eligible[va[per]]]=0;replay=np.round(postprocess(zz,np.char.add('opaque_',groups[va[per]]),'conditional',1.),12);err=float(abs(replay-q[per]).max());assert err<1e-8;audits.append(dict(fold=f['fold'],arm=name,reload_order_delta=err))
  driver.save(OUT/f'fold{f["fold"]}_selection.json',dict(selected=configs[chosen],reference=configs[reference],inner_selected=metrics[chosen],inner_reference=metrics[reference]));print('LONG TEACHER OUTER',f['fold'],'/5',configs[chosen],flush=True)
 with np.load(driver.CONTROL/'frozen_844161_baseline_oof.npz') as a:base=a['probability']
 y=d['label'];g=d['subject'];dep=d['diagnosis']==1;w=np.where(dep,1.5,.75);ids=np.unique(g);matrix=pair_matrix(y,base,g,ids);rng=np.random.default_rng(20261028);counts=np.zeros((2000,len(ids)))
 for j in range(len(counts)):
  for mask in [np.char.startswith(ids,'DEP'),np.char.startswith(ids,'HC')]:
   ix=np.flatnonzero(mask);counts[j]+=np.bincount(rng.choice(ix,len(ix),replace=True),minlength=len(ids))
 results={}
 for name,q in [('reference',ref),('long_teacher_student',pred),('fixed10pct_fusion',np.round(.9*base+.1*pred,12))]:
  delta=pair_matrix(y,q,g,ids)-matrix;boot=np.einsum('bi,ij,bj->b',counts,delta,counts,optimize=True)/counts.sum(1)**2;results[name]=dict(pooled10s_auc=float(roc_auc_score(y,q)),balanced10s_auc=float(roc_auc_score(y,q,sample_weight=w)),DEP10s_auc=float(roc_auc_score(y[dep],q[dep])),delta_vs_frozen_95CI=np.quantile(boot,[.025,.975]).tolist());np.savez_compressed(OUT/(name+'_oof.npz'),labels=y,subjects=g,probability=q)
 driver.save(OUT/'verification.json',dict(checks_passed=True,all5outer3inner=True,teacher_subjectcrossfit_inside_each_training=True,all_scalers_training_only=True,no_validation_aggregation=True,audits=audits,seal_and_official_test_not_read=True,submissions_performed=False));driver.save(OUT/'summary.json',dict(results=results,baseline_preserved=True,cohort_reused=True,not_multiple_search_corrected=True,official_score_unknown=True));print('LONG TEACHER COMPLETE',json.dumps(results),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException:driver.save(OUT/'failure.json',dict(traceback=traceback.format_exc()));raise
