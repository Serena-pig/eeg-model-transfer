"""Source-only temporal oscillatory residuals and regional phase coupling.
Reads no labels/diagnosis/test signals; this is OLS spectral detrending, NOT IRASA.
"""
import os
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
from pathlib import Path
import json,time
import numpy as np
from scipy.signal import stft,butter,sosfiltfilt,hilbert
from scipy.ndimage import gaussian_filter1d
from threadpoolctl import threadpool_limits
import driver
OUT=driver.JOB/'state_features_20261028';OUT.mkdir(exist_ok=True)
REGIONS=[[0,2,3],[4,9],[1,5,6],[8,13,18],[14,19],[10,15,20],[7,12,17,22],[11,16,21,26],[23,24,25,27,28,29]]
BANDS=[(1,4),(4,8),(8,13),(13,20),(20,30)]
PHASE_BANDS=[(4,8),(8,13),(13,20),(20,30)]
def compute(raw):
 x=np.asarray(raw,dtype=np.float64);f,_,z=stft(x,fs=125,window='hann',nperseg=250,noverlap=125,boundary=None,padded=False,axis=-1);keep=(f>=1)&(f<=40);f=f[keep];power=np.log(np.maximum(abs(z[:,:,keep,:])**2,1e-12));design=np.column_stack([np.ones(len(f)),np.log(f)]);coeff=np.einsum('af,ncft->ncat',np.linalg.pinv(design),power);residual=power-np.einsum('fa,ncat->ncft',design,coeff);residual=gaussian_filter1d(residual,1.,axis=2)
 seq=np.stack([residual[:,:,(f>=lo)&(f<hi),:].mean(2) for lo,hi in BANDS],axis=2).transpose(0,3,2,1);# N,9,5,30
 t=np.linspace(-1,1,seq.shape[1]);slope=np.einsum('ntbc,t->nbc',seq,t)/(t@t);temporal=np.stack([seq.std(1),slope,np.abs(np.diff(seq,axis=1)).mean(1)],axis=1).reshape(len(x),-1)
 regions=np.stack([x[:,ch].mean(1) for ch in REGIONS],axis=1);ii,jj=np.triu_indices(len(REGIONS),1);parts=[]
 for lo,hi in PHASE_BANDS:
  filtered=sosfiltfilt(butter(4,[lo,hi],fs=125,btype='bandpass',output='sos'),regions,axis=-1);analytic=hilbert(filtered,axis=-1);unit=analytic/np.maximum(abs(analytic),1e-12);phase=unit[:,ii]*unit[:,jj].conj();plv=abs(phase.mean(-1));plv_std=abs(phase.reshape(len(x),len(ii),5,250).mean(-1)).std(-1);imag=(analytic[:,ii]*analytic[:,jj].conj()).imag;sum_sq=(imag*imag).sum(-1);num=imag.sum(-1)**2-sum_sq;den=np.abs(imag).sum(-1)**2-sum_sq;dwpli=np.clip(np.divide(num,den,out=np.zeros_like(num),where=den>1e-12),0,1);parts.append(np.stack([plv,plv_std,dwpli],axis=1).reshape(len(x),-1))
 phase=np.concatenate(parts,axis=1)
 assert np.isfinite(temporal).all() and np.isfinite(phase).all()
 return dict(temporal=temporal.astype('float32'),phase=phase.astype('float32'),osc_sequence=seq.astype('float32'))
def main():
 limits=threadpool_limits(limits=1);protocol=dict(source='Existing valid59source people raw125Hz,1-45Hz/CAR30,2360windows',regions=REGIONS,temporal_bands=BANDS,phase_bands=PHASE_BANDS,temporal='2sSTFT1shop,OLSlogPSD~logf detrend,0.5HzGaussian smoothing,bandresidual std/slope/absolutechanges',phase='Regional PLV,2sPLVvariability,debiased squaredwPLI',no_IRASA_claim=True,labels_diagnosis_not_read=True,holdout_test_not_read=True,script_sha256=driver.sha(__file__))
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==protocol
 else:driver.save(OUT/'protocol.json',protocol)
 with np.load(driver.ART/'features.npz') as a:meta={k:a[k] for k in ['subject','trial','crop']}
 source=driver.protocol()['split'];assert set(np.unique(meta['subject'])).issubset(source['development']) and set(np.unique(meta['subject'])).isdisjoint(source['holdout']);raw=np.load(driver.ART/'raw_125hz.npy',mmap_mode='r');parts=OUT/'parts';parts.mkdir(exist_ok=True)
 for k,s in enumerate(np.unique(meta['subject'])):
  path=parts/(s+'.npz');rows=np.flatnonzero(meta['subject']==s)
  if not path.exists():np.savez_compressed(path,rows=rows,**compute(raw[rows]))
  driver.save(OUT/'extraction_progress.json',dict(completed_subjects=k+1,total=59,subject=str(s)));print('STATE FEATURES',k+1,'/59',s,flush=True)
 arrays={k:[] for k in ['temporal','phase','osc_sequence']};order=[]
 for s in np.unique(meta['subject']):
  with np.load(parts/(s+'.npz')) as a:
   order.extend(a['rows'].tolist())
   for k in arrays:arrays[k].append(a[k])
 ix=np.argsort(order);arrays={k:np.concatenate(v)[ix] for k,v in arrays.items()};dest=OUT/'features.npz';np.savez_compressed(dest,**meta,**arrays);driver.save(OUT/'features_ready.json',dict(complete=True,feature_shapes={k:list(v.shape) for k,v in arrays.items()},sha256=driver.sha(dest),source_people=59,labels_diagnosis_not_read=True,holdout_test_not_read=True));print('STATE FEATURES COMPLETE',flush=True)
if __name__=='__main__':main()
