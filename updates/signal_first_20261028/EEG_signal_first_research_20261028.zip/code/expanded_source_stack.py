"""83completed sources +2new topology experts, directly learned sourceOOF stack.
No sourceproxy mismatch; fixed inheritedC=.01. Outer-held-subject labels notused
for fit, selection, earlystop. One fixed directstack plus clinical/bag controls.
"""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import json,traceback
import numpy as np,joblib
from scipy.special import logit
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits
import driver
from nonlinear_rank_v18 import features
from context_rank_v34 import fit_context,context_features
from inner_calibration_round import calibrate
from postflight import pair_matrix
OUT=driver.JOB/'expanded_source_stack_20261028';OUT.mkdir(exist_ok=True)
NEURAL=['topo_oscillator_20261028','topo_fullspec_20261028']
NAMES=['direct_stack','clinical_stack','clinical_bag20']
def weights(diag):
 w=np.ones(len(diag))
 for v in [0,1]:w[diag==v]=len(diag)/(2*np.sum(diag==v))
 return w

def main():
 limits=threadpool_limits(limits=1);p=driver.protocol();pool=json.loads((driver.JOB/'completed_pool/protocol.json').read_text());oldcs=pool['members'];positions=pool['member_positions'];cs=oldcs+[dict(name=n,family='topology_osc',config=dict(epochs=20)) for n in NEURAL];K=len(cs);newix=[len(oldcs),len(oldcs)+1];spec=dict(source_members=K,original83_plus_new=NEURAL,C_fixed=.01,variants=NAMES,clinical_interaction_scale_fixed=.5,bag_members=20,bag_seed=20261028,no_proxy_mismatch=True,all3inner_neural_predictions_genuinely_subjectheld=True,hyperparameters_inherited_or_fixed_not_outerselected=True,score_round_decimals=12,source_inner_calibration_policy='Reuse clean equal83proxyselected policy; noownoutercalibrationtuning',script_sha256=driver.sha(__file__),cohort_reused=True)
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==spec
 else:driver.save(OUT/'protocol.json',spec)
 with np.load(driver.ART/'features.npz') as a:meta={k:a[k] for k in ['subject','trial','crop','label','diagnosis','powers','quality']}
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:d={k:a[k] for k in a.files}
 mapping=d['model_row_to_full_row'];reverse={v:j for j,v in enumerate(mapping)};probs={n:np.full(len(d['label']),.5) for n in NAMES+['direct_stack_calibrated','clinical_stack_calibrated','clinical_bag20_calibrated']};audits=[]
 with np.load(driver.CONTROL/'frozen_844161_baseline_oof.npz') as a:baseline=a['probability']
 for f in p['folds']:
  tr=np.flatnonzero(np.isin(meta['subject'],f['training_subjects']));va=np.flatnonzero(np.isin(meta['subject'],f['validation_subjects']));lookup={v:j for j,v in enumerate(tr)};inner=np.zeros((K,len(tr)));outer=np.zeros((K,len(va)))
  for j,i in enumerate(positions):
   m=p['members'][i]
   for part in ['inner0','inner1','inner2','outer']:
    t=dict(fold=f['fold'],part=part,index=m['candidate_index'],name=m['name'],family=m['family'],member_position=i);file,_=driver.paths(t)
    with np.load(file) as a:
     if part=='outer':assert np.array_equal(a['query_indices'],va);outer[j]=a['logits']
     else:inner[j,[lookup[v] for v in a['query_indices']]]=a['logits']
  for j,name in enumerate(NEURAL,start=len(oldcs)):
   for part in ['inner0','inner1','inner2','outer']:
    with np.load(driver.JOB/name/f'fold{f["fold"]}_{part}.npz') as a:
     fullrows=a['validation'];q=a['probability'];assert np.isfinite(q).all();good=np.array([int(v) in reverse for v in fullrows]);idx=np.array([reverse[int(v)] for v in fullrows[good]]);z=logit(np.clip(q[good],1e-6,1-1e-6))
     if part=='outer':assert np.array_equal(idx,va);outer[j]=z
     else:inner[j,[lookup[v] for v in idx]]=z
  source=dict(meta);source['label']=np.full_like(meta['label'],-1);source['diagnosis']=np.full_like(meta['diagnosis'],-1);source['label'][tr]=meta['label'][tr];source['diagnosis'][tr]=meta['diagnosis'][tr];raw,scales=features(source,tr,inner,cs);context,extra=fit_context(source,tr);sc=StandardScaler().fit(np.column_stack([raw,extra]));x=sc.transform(np.column_stack([raw,extra]));gx=np.column_stack([x,.5*(2*extra[:,6]-1)[:,None]*x[:,newix]]);y=meta['label'][tr];diag=meta['diagnosis'][tr];w=weights(diag);models={'direct_stack':[LogisticRegression(C=.01,max_iter=2000).fit(x,y,sample_weight=w)],'clinical_stack':[LogisticRegression(C=.01,max_iter=2000).fit(gx,y,sample_weight=w)]}
  rng=np.random.default_rng(20261028+f['fold']);people=np.unique(meta['subject'][tr]);bag=[]
  for b in range(20):
   rows=[]
   for v in [0,1]:
    ss=[s for s in people if diag[np.flatnonzero(meta['subject'][tr]==s)[0]]==v]
    for s in rng.choice(ss,len(ss),replace=True):rows.extend(np.flatnonzero(meta['subject'][tr]==s).tolist())
   rows=np.array(rows);bag.append(LogisticRegression(C=.01,max_iter=2000).fit(gx[rows],y[rows],sample_weight=weights(diag[rows])))
  models['clinical_bag20']=bag;artifact=dict(models=models,scaler=sc,context=context,scales=scales,source_subjects=f['training_subjects'],neural_feature_indices=newix,protocol=spec);path=OUT/f'fold{f["fold"]}.joblib';joblib.dump(artifact,path,compress=3);saved=joblib.load(path);query=dict(meta);query['label']=np.full_like(meta['label'],-1);query['diagnosis']=np.full_like(meta['diagnosis'],-1)
  def design(q,ix,z,art):
   a,_=features(q,ix,z,cs,art['scales']);e=context_features(q,ix,art['context']);xx=art['scaler'].transform(np.column_stack([a,e]));return xx,np.column_stack([xx,.5*(2*e[:,6]-1)[:,None]*xx[:,newix]])
  def pred(name,xx,gg,art):return np.mean([m.predict_proba(xx if name=='direct_stack' else gg)[:,1] for m in art['models'][name]],axis=0)
  xv,gv=design(query,va,outer,artifact);perm=np.random.default_rng(f['fold']).permutation(len(va));query['subject']=np.char.add('opaque_',meta['subject']);query['trial']=np.zeros_like(meta['trial']);sx,sg=design(query,va[perm],outer[:,perm],saved);groups=np.char.add(np.char.add(meta['subject'][va],':'),meta['crop'][va].astype(str));mode=json.loads((driver.JOB/f'inner_calibration_20261028/fold{f["fold"]}_selection.json').read_text())['chosen']
  for name in NAMES:
   q=pred(name,xv,gv,artifact);replay=pred(name,xv,gv,saved);order=pred(name,sx,sg,saved);err=float(abs(q-replay).max());pererr=float(abs(order-q[perm]).max());assert err<1e-12 and pererr<1e-10;probs[name][mapping[va]]=np.round(q,12);probs[name+'_calibrated'][mapping[va]]=np.round(calibrate(q,groups,mode),12);audits.append(dict(fold=f['fold'],variant=name,native_reload_error=err,metadata_order_error=pererr,query_labels_diagnosis_hidden=True))
  print('EXPANDED SOURCE STACK OUTER',f['fold'],'/5',flush=True)
 y=d['label'];g=d['subject'];dep=d['diagnosis']==1;w=np.where(dep,1.5,.75);ids=np.unique(g);ref=pair_matrix(y,baseline,g,ids);rng=np.random.default_rng(20261028);counts=np.zeros((2000,len(ids)))
 for j in range(len(counts)):
  for mask in [np.char.startswith(ids,'DEP'),np.char.startswith(ids,'HC')]:
   ix=np.flatnonzero(mask);counts[j]+=np.bincount(rng.choice(ix,len(ix),replace=True),minlength=len(ids))
 results={}
 for name,q in probs.items():
  delta=pair_matrix(y,q,g,ids)-ref;boot=np.einsum('bi,ij,bj->b',counts,delta,counts,optimize=True)/counts.sum(1)**2;results[name]=dict(pooled10s_auc=float(roc_auc_score(y,q)),balanced10s_auc=float(roc_auc_score(y,q,sample_weight=w)),DEP10s_auc=float(roc_auc_score(y[dep],q[dep])),delta_vs_frozen_95CI=np.quantile(boot,[.025,.975]).tolist());np.savez_compressed(OUT/(name+'_oof.npz'),labels=y,subjects=g,probability=q)
 driver.save(OUT/'verification.json',dict(checks_passed=True,all5outer3inner=True,direct_meta_training_no_unary_proxy_mismatch=True,source_labels_only=True,audits=audits,seal_and_official_test_not_read=True,submissions_performed=False));driver.save(OUT/'summary.json',dict(results=results,baseline_preserved=True,cohort_reused=True,not_multiple_search_corrected=True,official_score_unknown=True));print('EXPANDED SOURCE STACK COMPLETE',json.dumps(results),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException:driver.save(OUT/'failure.json',dict(traceback=traceback.format_exc()));raise
