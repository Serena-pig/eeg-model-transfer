"""Select topology fusion weights on genuine source-inner predictions.
Proxyselector equal83, finaltransfer onto frozenLR (mismatch declared). Also
report matched equal83proxy fusion. Outer labels never choose alpha.
"""
from pathlib import Path
import json,traceback
import numpy as np
from sklearn.metrics import roc_auc_score
import driver
from confidence_fusion_v11 import probability_bank
from postflight import pair_matrix
OUT=driver.JOB/'topology_inner_fusion_20261028';OUT.mkdir(exist_ok=True)
MODELS=['topo_oscillator_20261028','topo_fullspec_20261028']
def freeze():
 spec=dict(models=MODELS,alphas=[0.,.1,.25,.5],proxy='Unfitted equal83source ensemble genuineinnerOOF',final_LR_transfer_proxy_mismatch=True,selection='Mean3innerdomainbalancedAUC-.25std;requiremean+.001andDEPfloor-.005',outer_labels_not_used_to_select=True,script_sha256=driver.sha(__file__))
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==spec
 else:driver.save(OUT/'protocol.json',spec)
 return spec

def main():
 spec=freeze();p=driver.protocol();pool=json.loads((driver.JOB/'completed_pool/protocol.json').read_text());positions=pool['member_positions'];cs=pool['members']
 with np.load(driver.ART/'features.npz') as a:meta={k:a[k] for k in ['subject','trial','crop','label','diagnosis']}
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:d={k:a[k] for k in a.files}
 with np.load(driver.CONTROL/'frozen_844161_baseline_oof.npz') as a:baseline=a['probability']
 mapping=d['model_row_to_full_row'];probs={m+suffix:np.full(len(baseline),.5) for m in MODELS for suffix in ['_LR_transfer','_matched_proxy']};selections=[]
 for f in p['folds']:
  tr=np.flatnonzero(np.isin(meta['subject'],f['training_subjects']));va=np.flatnonzero(np.isin(meta['subject'],f['validation_subjects']));lookup={v:j for j,v in enumerate(tr)};inner=np.zeros((len(cs),len(tr)));outer=np.zeros((len(cs),len(va)))
  for j,i in enumerate(positions):
   m=p['members'][i]
   for part in ['inner0','inner1','inner2','outer']:
    t=dict(fold=f['fold'],part=part,index=m['candidate_index'],name=m['name'],family=m['family'],member_position=i);file,_=driver.paths(t)
    with np.load(file) as a:
     if part=='outer':assert np.array_equal(a['query_indices'],va);outer[j]=a['logits']
     else:inner[j,[lookup[v] for v in a['query_indices']]]=a['logits']
  blind=dict(meta);blind['label']=np.full_like(meta['label'],-1);blind['diagnosis']=np.full_like(meta['diagnosis'],-1);ii,scales=probability_bank(blind,tr,inner,cs);oo,_=probability_bank(blind,va,outer,cs,scales);trainrows=np.flatnonzero(np.isin(d['subject'],f['training_subjects']));validrows=np.flatnonzero(np.isin(d['subject'],f['validation_subjects']));proxy=np.full(len(d['label']),.5);proxy[mapping[tr]]=ii.mean(0);proxy[mapping[va]]=oo.mean(0)
  masks=[np.isin(d['subject'][trainrows],s['validation_subjects']) for s in f['inner']];y=d['label'][trainrows];diag=d['diagnosis'][trainrows]
  def score(q):
   vals=[];deps=[]
   for mask in masks:
    w=np.ones(mask.sum());dd=diag[mask]
    for v in [0,1]:w[dd==v]=len(w)/(2*np.sum(dd==v))
    vals.append(roc_auc_score(y[mask],q[mask],sample_weight=w));dm=mask&(diag==1);deps.append(roc_auc_score(y[dm],q[dm]))
   return dict(mean=float(np.mean(vals)),DEP=float(np.mean(deps)),stable=float(np.mean(vals)-.25*np.std(vals)))
  reference=score(proxy[trainrows])
  for modelroot in MODELS:
   root=driver.JOB/modelroot;neural=np.full(len(d['label']),.5)
   for part in ['inner0','inner1','inner2','outer']:
    with np.load(root/f'fold{f["fold"]}_{part}.npz') as a:neural[a['validation']]=a['probability']
   choices={alpha:score((1-alpha)*proxy[trainrows]+alpha*neural[trainrows]) for alpha in spec['alphas']};eligible=[alpha for alpha in spec['alphas'] if alpha==0 or (choices[alpha]['mean']>=reference['mean']+.001 and choices[alpha]['DEP']>=reference['DEP']-.005)];alpha=max(eligible,key=lambda a:choices[a]['stable']);probs[modelroot+'_LR_transfer'][validrows]=(1-alpha)*baseline[validrows]+alpha*neural[validrows];probs[modelroot+'_matched_proxy'][validrows]=(1-alpha)*proxy[validrows]+alpha*neural[validrows];record=dict(fold=f['fold'],model=modelroot,alpha=alpha,source_metrics=choices);selections.append(record);driver.save(OUT/f'fold{f["fold"]}_{modelroot}.json',record)
 y=d['label'];g=d['subject'];dep=d['diagnosis']==1;w=np.where(dep,1.5,.75);ids=np.unique(g);base=pair_matrix(y,baseline,g,ids);rng=np.random.default_rng(20261028);counts=np.zeros((2000,len(ids)))
 for j in range(len(counts)):
  for mask in [np.char.startswith(ids,'DEP'),np.char.startswith(ids,'HC')]:
   ix=np.flatnonzero(mask);counts[j]+=np.bincount(rng.choice(ix,len(ix),replace=True),minlength=len(ids))
 results={}
 for name,q in probs.items():
  delta=pair_matrix(y,q,g,ids)-base;boot=np.einsum('bi,ij,bj->b',counts,delta,counts,optimize=True)/counts.sum(1)**2;results[name]=dict(pooled10s_auc=float(roc_auc_score(y,q)),balanced10s_auc=float(roc_auc_score(y,q,sample_weight=w)),DEP10s_auc=float(roc_auc_score(y[dep],q[dep])),delta_vs_frozen_95CI=np.quantile(boot,[.025,.975]).tolist());np.savez_compressed(OUT/(name+'_oof.npz'),labels=y,subjects=g,probability=q)
 driver.save(OUT/'summary.json',dict(results=results,source_only_selection=True,proxy_mismatch_declared=True,baseline_preserved=True,cohort_reused=True,not_multiple_search_corrected=True,official_score_unknown=True,seal_and_official_test_not_read=True,submissions_performed=False));print('TOPOLOGY SOURCE INNER FUSION COMPLETE',json.dumps(results),flush=True)
if __name__=='__main__':
 import sys
 if '--freeze-only' in sys.argv:freeze();print('Source fusion protocol frozen before topology results')
 else:
  try:main()
  except BaseException:driver.save(OUT/'failure.json',dict(traceback=traceback.format_exc()));raise
