"""Evaluate SAME source predictions at10s vs50s, diagnostic only.
Reconstruct raw aperiodic native margins and follow trialmedian->conditional,
matching the document's ORDER while retaining our own60source5fold protocol.
"""
from pathlib import Path
import json
import numpy as np,joblib
from scipy.special import expit,logit
from sklearn.metrics import roc_auc_score
from sklearn.metrics.pairwise import euclidean_distances
import driver
from domain_models_v2 import _features
from select_ensemble import postprocess
from threadpoolctl import threadpool_limits

def main():
 limits=threadpool_limits(limits=1);p=driver.protocol()
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:d={k:a[k] for k in a.files}
 with np.load(driver.ART/'features.npz') as a:old={k:a[k] for k in ['subject','crop','powers','spectrum']}
 mapping=d['model_row_to_full_row'];valid=np.zeros(len(d['label']),bool);valid[mapping]=True;small=_features(old,np.arange(len(mapping)),'aperiodic');x=np.zeros((len(valid),small.shape[1]));x[mapping]=small;z=np.zeros(len(x));g10=np.char.add(np.char.add(d['subject'],':'),d['crop'].astype(str))
 for f in p['folds']:
  rows=np.flatnonzero(np.isin(d['subject'],f['validation_subjects']));saved=joblib.load(driver.JOB/f'state_svm_20261028/fold{f["fold"]}_aperiodic.joblib');c=saved['config'];assert c['kind']=='aperiodic';xx=saved['scalers']['aperiodic'].transform(x[rows]);kernel=np.exp(-c['gamma']*euclidean_distances(xx,saved['train_x']['aperiodic'],squared=True)/x.shape[1]);zz=saved['model'].decision_function(kernel);zz[~valid[rows]]=0;z[rows]=zz
 trialid=np.char.add(np.char.add(d['subject'],':'),d['trial'].astype(str));ids=np.unique(trialid);first=np.array([np.flatnonzero(trialid==s)[0] for s in ids]);zt=np.array([np.median(z[trialid==s]) for s in ids]);yt=d['label'][first];gt=d['subject'][first];s10=d['subject'];y10=d['label'];data={'10s_raw':(y10,np.round(expit(z),12),s10),'10s_conditional':(y10,np.round(postprocess(z,g10,'conditional',1.),12),s10),'50s_median_raw_DIAGNOSTIC':(yt,np.round(expit(zt),12),gt),'50s_median_then_conditional_DIAGNOSTIC':(yt,np.round(postprocess(zt,gt,'conditional',1.),12),gt)};result={}
 for name,(y,q,s) in data.items():
  dep=np.char.startswith(s,'DEP');result[name]=dict(rows=len(y),pooled_auc=float(roc_auc_score(y,q)),HC_auc=float(roc_auc_score(y[~dep],q[~dep])),DEP_auc=float(roc_auc_score(y[dep],q[dep])))
 report=dict(same_underlying_native_models=True,results=result,source_people=60,primary_competition_matched_unit='10seconds',official_pdf='250Hz8segments20000samples=10s each',training_pdf='4segments50000samples=50s each',source_md_claimed88_not_independently_audited=True,scope='diagnostic',holdout_or_official_test_signal_not_read=True)
 driver.save(driver.CONTROL/'TIME_SUPPORT_AUDIT_20261028.json',report);print(json.dumps(report),flush=True)
if __name__=='__main__':main()
