FACED cache builder

Requires Python, numpy and scipy (already installed on the user's machine).
Extract this folder to D:\FACED\cache_builder.
Run in CMD:
python D:\FACED\cache_builder\build_faced_cache.py

Only reads the 123 public FACED MAT files. No downloads, training or competition data access.
Processes one subject at a time and supports restart using source/script/version/output hashes.
Send D:\FACED\rebuilt_cache\FACED_cache_to_send.zip after completion.
The report records whether the output exactly matches the original cache SHA256.
A mismatch requires review and is NOT automatically accepted into the frozen experiment.
Preserve the original MAT files until verification is finished.
