"""Rebuild the original FACED cache locally; does not train or access competition data."""
import os
for name in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ.setdefault(name, '1')
import argparse, csv, hashlib, json, platform, sys, zipfile
from pathlib import Path
import numpy as np
import scipy
from scipy.io import loadmat
from scipy.signal import butter, resample_poly, sosfiltfilt
ROOT = Path(__file__).resolve().parent
BANDS = [(1,4),(4,8),(8,13),(13,20),(20,30),(30,45),(1,45)]
CHANNELS = 'FP1 FP2 F7 F3 FZ F4 F8 FT7 FC3 FCZ FC4 FT8 T3 C3 CZ C4 T4 TP7 CP3 CPZ CP4 TP8 T5 P3 PZ P4 T6 O1 OZ O2'.split()
EXPECTED = 'ecf5307dd28a3c4373faf94490de9878aafaae9a4f818bfedb7b8cd47c52b5b6'

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

def write_json(path, obj):
    path = Path(path)
    tmp = path.with_name(path.name + '.partial')
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding='utf-8')
    tmp.replace(path)

def save_array(path, value):
    tmp = path.with_name(path.name + '.partial')
    with tmp.open('wb') as f:
        np.save(f, value, allow_pickle=False)
    tmp.replace(path)

def channel_mapping():
    with (ROOT / 'faced_channels.tsv').open(encoding='utf-8-sig') as f:
        external = [r['name'].upper() for r in csv.DictReader(f, delimiter='\t')]
    assert external[16:18] == ['A1', 'A2'] and len(external) == 32
    external = [ch for ch in external if ch not in ['A1', 'A2']]
    with (ROOT / 'faced_channels_061.tsv').open(encoding='utf-8-sig') as f:
        second = [r['name'].upper() for r in csv.DictReader(f, delimiter='\t')]
    aliases = dict(T7='T3', T8='T4', P7='T5', P8='T6')
    second = [aliases.get(ch, ch) for ch in second if ch not in ['HEOR', 'HEOL']]
    assert second == external, 'Both hardware batches must have the same remaining30-channel order.'
    common = [ch for ch in CHANNELS if ch in external]
    assert len(common) == 20, common
    return common, [external.index(ch) for ch in common], [CHANNELS.index(ch) for ch in common]

def one_subject(path, external_indices):
    a = loadmat(path, simplify_cells=True)
    info = a['pre_info']
    assert int(info['resamplefs']) == 125
    excluded = sorted(np.asarray(info['reref']).ravel().tolist())
    assert excluded == ([17,18] if int(path.stem[3:]) < 61 else [31,32])
    raw = a['data_all_cleaned']
    assert raw.shape[0] == 30 and np.isfinite(raw).all()
    ends = np.cumsum(np.asarray(a['n_samples_one']).ravel() * 125).astype(int)
    assert len(ends) == 28 and ends[-1] <= raw.shape[-1]
    # The author's loader confirms the MAT records are in canonical video order.
    # FACED videos13..16 are neutral,17..28 positive. No competition IDs inferred.
    clips = np.stack([raw[:, end - 3750:end].reshape(30, 3, 1250).transpose(1, 0, 2)
                      for end in ends[12:]])
    assert clips.shape == (16, 3, 30, 1250)
    x = resample_poly(clips.reshape(-1, 30, 1250).astype('float64'), 2, 1, axis=-1)
    med = np.median(x, axis=-1, keepdims=True)
    mad = 1.4826 * np.median(abs(x-med), axis=-1, keepdims=True)
    x = np.clip(x, med-10*np.maximum(mad, 1e-8), med+10*np.maximum(mad, 1e-8))
    x -= x.mean(1, keepdims=True)
    x = x[:, external_indices]
    values = []
    for lo, hi in BANDS[:6]:
        filtered = sosfiltfilt(butter(4, [lo, hi], fs=250, btype='bandpass', output='sos'), x, axis=-1)
        values.append(np.log(np.maximum(filtered.reshape(48, 20, 10, 250).var(-1), 1e-12)).transpose(0, 2, 1))
    return np.stack(values, axis=2).reshape(16, 3, 10, 6, 20).astype('float32')

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--data', type=Path, default=Path(r'D:\FACED\FACED\processed_data'))
    ap.add_argument('--output', type=Path, default=Path(r'D:\FACED\rebuilt_cache'))
    args = ap.parse_args()
    inputs = [args.data / f'sub{i:03}.mat' for i in range(123)]
    missing = [str(p) for p in inputs if not p.is_file()]
    if missing:
        raise FileNotFoundError('Missing source files: ' + ', '.join(missing))
    expected_manifest = json.loads((ROOT / 'original_manifest.json').read_text(encoding='utf-8-sig'))
    for name, digest in expected_manifest['channel_metadata_sha256'].items():
        if sha(ROOT/name) != digest:
            raise ValueError('Channel metadata checksum mismatch: ' + name)
    common, ext, target = channel_mapping()
    if (common != expected_manifest['channels'] or ext != expected_manifest['external_indices'] or target != expected_manifest['target_indices']):
        raise ValueError('Original channel mapping does not match')
    args.output.mkdir(parents=True, exist_ok=True)
    versions = dict(python=sys.version, numpy=np.__version__, scipy=scipy.__version__, platform=platform.platform())
    script_sha = sha(Path(__file__))
    records = []
    for i, path in enumerate(inputs):
        dest = args.output / f'sub{i:03}.npy'
        audit = dest.with_suffix('.json')
        digest = sha(path)
        signature = dict(source_sha256=digest, script_sha256=script_sha, versions=versions)
        reused = False
        if dest.exists() and audit.exists():
            record = json.loads(audit.read_text(encoding='utf-8'))
            if record.get('signature') == signature and record.get('output_sha256') == sha(dest):
                check = np.load(dest, allow_pickle=False)
                reused = check.shape == (16,3,10,6,20) and check.dtype == np.float32 and np.isfinite(check).all()
                del check
        if not reused:
            value = one_subject(path, ext)
            if value.shape != (16,3,10,6,20) or value.dtype != np.float32 or not np.isfinite(value).all():
                raise ValueError('Invalid extracted feature array: ' + path.name)
            save_array(dest, value)
            del value
            record = dict(file=path.name, size=path.stat().st_size, signature=signature, output_sha256=sha(dest))
            write_json(audit, record)
        records.append(record)
        print(f'[{i+1}/123] {path.name}: ' + ('REUSED' if reused else 'OK'), flush=True)
    values = np.stack([np.load(args.output/f'sub{i:03}.npy', allow_pickle=False) for i in range(123)])
    if values.shape != (123,16,3,10,6,20) or not np.isfinite(values).all():
        raise ValueError('Invalid combined cache')
    dest = args.output / 'sequences.npy'
    save_array(dest, values)
    digest = sha(dest)
    exact = digest == EXPECTED
    report = dict(status='EXACT_ORIGINAL_MATCH' if exact else 'REBUILT_REQUIRES_REVIEW',
        shape=list(values.shape), dtype=str(values.dtype), sequences_sha256=digest,
        expected_original_sha256=EXPECTED, exact_original_match=exact,
        versions=versions, builder_sha256=script_sha, original_manifest=expected_manifest,
        subjects=records, source_files_deleted=False, competition_data_accessed=False,
        warning=None if exact else 'Do not substitute into the frozen training run until numerical/source compatibility has been reviewed.')
    write_json(args.output/'rebuild_report.json', report)
    zip_path = args.output/'FACED_cache_to_send.zip'
    temp_zip = zip_path.with_suffix('.zip.partial')
    with zipfile.ZipFile(temp_zip, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=3) as z:
        z.write(dest, 'sequences.npy')
        z.write(args.output/'rebuild_report.json', 'rebuild_report.json')
    temp_zip.replace(zip_path)
    print('CACHE STATUS:', report['status'], flush=True)
    print('SHA256:', digest, flush=True)
    print('SEND THIS FILE:', zip_path, flush=True)
    print('Keep the source MAT files until verification is complete.', flush=True)

if __name__ == '__main__':
    main()
