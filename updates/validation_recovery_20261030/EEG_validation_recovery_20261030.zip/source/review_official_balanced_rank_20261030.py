"""Independent re-load, source weight audit and fixed-cohort metrics."""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import json
import numpy as np
import joblib
from scipy.special import expit
from sklearn.metrics import roc_auc_score
import driver
from common import batches,center
from context_rank_v34 import context_features
from cached_fixed_fusion_20261030 import features
from select_ensemble import postprocess
from inner_calibration_round import calibrate

OUT=driver.JOB/'official_balanced_rank_review_20261030'

def main():
 OUT.mkdir(exist_ok=True);root=driver.JOB/'official_balanced_rank_20261030'
 with np.load(driver.ART/'features.npz') as f:
  d={k:f[k] for k in ['subject','trial','crop','label','diagnosis','train','powers','quality']}
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as f:full={k:f[k] for k in f.files}
 results={};audits=[]
 for method in ['full_balanced','subbag64']:
  with np.load(root/(method+'_rawmean_calibrated_oof.npz')) as f:
   reference=f['probability'];assert np.array_equal(f['labels'],full['label']) and np.array_equal(f['subjects'],full['subject'])
  out=np.full(len(reference),.5)
  for fold in driver.protocol()['folds']:
   k=fold['fold'];a=joblib.load(root/f'fold{k}.joblib');base=a['base_artifact']
   with np.load(driver.JOB/f'cached_group_diagnostics_20261030/fold{k}_aligned_banks.npz') as f:
    tr=f['inner_indices'];va=f['outer_indices'];bank=f['outer_probability'][np.r_[np.arange(83),np.arange(104,107)]]
   roww=a['weights'][method];clinical=d['diagnosis'][tr]
   assert np.allclose(roww[:,clinical==0].sum(1),roww.sum(1)/2)
   assert np.allclose(roww[:,clinical==1].sum(1),roww.sum(1)/2)
   assert np.allclose(roww[:,d['label'][tr]==1].sum(1),roww.sum(1)/2)
   assert not set(d['subject'][tr])&set(d['subject'][va])
   with np.load(driver.JOB/f'aligned_covariance_svm_20261030/fold{k}_outer.npz') as f:
    assert np.array_equal(f['validation'],va);z=f['logits']
   perm=np.random.default_rng(501050+k).permutation(len(va));ix=va[perm]
   query=dict(d);query['label']=np.full_like(d['label'],-1);query['diagnosis']=np.full_like(d['diagnosis'],-1);query['train']=np.zeros_like(d['train']);query['subject']=np.char.add('opaque_',d['subject']);query['trial']=np.zeros_like(d['trial'])
   groups=batches(query)[ix]
   bank=np.vstack([bank[:,perm],postprocess(center(z[perm],groups)/base['SPD_source_scale'],groups,'conditional',.6)])
   e=context_features(query,ix,base['context']);x=base['scaler'].transform(np.column_stack([features(bank,groups),e]));v=np.column_stack([x,.5*(2*e[:,6]-1)[:,None]*x[:,[83,84,85,86]]])
   theta=a['models'][method];q=expit(v@theta[:,:-1].T+theta[:,-1]).mean(1)
   mode=json.loads((driver.JOB/f'inner_calibration_20261028/fold{k}_selection.json').read_text())['chosen'];q=calibrate(q,groups,mode)
   rows=full['model_row_to_full_row'][ix];err=float(abs(q-reference[rows]).max());assert err<1e-9
   out[rows]=q;audits.append(dict(method=method,fold=k,heads=len(theta),all_source_fits_clinical_mass_exactly_half=True,native_prediction_delta=err))
  assert np.max(abs(out-reference))<1e-9
  weights=np.where(full['diagnosis']==1,2.,1.)
  rounding={str(n):float(roc_auc_score(full['label'],np.round(out,n),sample_weight=weights)) for n in (10,12,14)}
  assert max(rounding.values())-min(rounding.values())<1e-6
  results[method]=dict(equal_clinical_mass_pooled_auc=float(roc_auc_score(full['label'],reference,sample_weight=weights)),legacy_pooled_auc=float(roc_auc_score(full['label'],reference)),HC_auc=float(roc_auc_score(full['label'][full['diagnosis']==0],reference[full['diagnosis']==0])),DEP_auc=float(roc_auc_score(full['label'][full['diagnosis']==1],reference[full['diagnosis']==1])),rounding_equal_clinical_mass_auc=rounding)
 receipt=dict(checks_passed=True,all5outer_complete=True,people=60,records10s=2400,query_labels_diagnosis_train_trial_hidden=True,subject_ids_opaque_and_query_rows_permuted=True,results=results,audits=audits,not_fresh_validation=True,calibration_inherited=True,only_fusion_heads_retrained=True,no_claim_of_new_5plus5_model_refit_validation=True,official_and_sealed_not_opened=True,submissions=0)
 driver.save(OUT/'independent_review.json',receipt);print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
