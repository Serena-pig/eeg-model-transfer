"""Lock corrected reference metrics and preserve unsuccessful training controls."""
import hashlib,json,shutil,zipfile
from pathlib import Path
import driver

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
 root=driver.JOB.parent;out=Path('/workspace/output');registry=driver.JOB/'official_validation_recovery_20261030'
 summary=json.loads((registry/'summary.json').read_text());review=json.loads((driver.JOB/'official_balanced_rank_review_20261030/independent_review.json').read_text());assert review['checks_passed']
 reference=summary['rank16_reference'];diagnosis=json.loads((registry/'error_diagnosis.json').read_text())
 contract=dict(status='Active reference for new reports; not enforced by immutable legacy scripts',official_facts=dict(train_HC=45,train_DEP=25,public_test_HC=5,public_test_DEP=5,trials_per_person=8,public_prediction_rows=80,positive_label=1,neutral_label=0,submission_type='Per-trial positive-emotion probabilities',AUC_aggregation='All80 predictions pooled; organizer confirmation relayed by user'),official_document='incoming/官方_数据集说明文档.pdf',official_document_sha256=sha(root/'incoming/官方_数据集说明文档.pdf'),development=dict(HC=40,DEP=20,people=60,records10s=2400,already_used_for_model_selection=True),primary_internal_reference='Pooled ROC AUC after equalizing total clinical group weight. Never average subgroup AUCs instead.',reference_candidate=reference['candidate'],reference_equal_clinical_mass_pooled_auc=reference['equal_clinical_mass_pooled_auc'],legacy_development_pooled_auc_secondary_only=reference['development_pooled_auc'],official_score_not_measured=True,corrected_score_not_an_official_score_prediction=True,training_weights='A hypothesis to validate; not mandated to be1:1. Actual-frequency training currently outperforms forced1:1 controls.',OOF_5plus5_simulations='Diagnostic only: previously saved cross-fold forecasts, not fresh unseen10-person refit evaluation.',new_actual_5plus5_model_refit_status='Not performed in this round; existing source/outer splits retained and reweighted for fair same-cohort comparison.',next_confirmation='Freeze one candidate and validation design before one-time independent confirmation; do not tune on sealed labels.',sealed_opened=False,official_test_opened=False,competition_submissions_by_assistant_this_round=0)
 contractfile=root/'VALIDATION_CONTRACT_20261030.json';assert not contractfile.exists(),'Do not overwrite a locked contract'
 contractfile.write_text(json.dumps(contract,ensure_ascii=False,indent=2),encoding='utf-8')
 (root/'CURRENT_VALIDATION_REFERENCE_20261030.txt').write_text(str(contractfile)+'\n',encoding='utf-8')
 dest=root/'frozen_baselines/validation_recovery_20261030';assert not dest.exists(),'Do not overwrite archive';dest.mkdir()
 for directory in ['official_validation_recovery_20261030','official_balanced_rank_20261030','official_balanced_rank_review_20261030']:
  shutil.copytree(driver.JOB/directory,dest/directory)
 shutil.copy2(contractfile,dest/contractfile.name)
 scripts=['recover_official_validation_20261030.py','official_balanced_rank_20261030.py','review_official_balanced_rank_20261030.py','archive_validation_recovery_20261030.py']
 for filename in scripts:shutil.copy2(driver.JOB/filename,dest/filename)
 shutil.copy2(driver.JOB/reference['candidate'],dest/'reference_rank16_oof.npz')
 dependencies={name:sha(root/name) for name in ['frozen_baselines/candidate_rankbag_20261030/FREEZE_COMPLETE.json','v279_rebuild/control/protocol.json']}
 files={str(p.relative_to(dest)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(dest.rglob('*')) if p.is_file()}
 record=dict(status='Validation correction and negative controls; no model baseline promoted',dependencies=dependencies,files=files,reference_equal_clinical_mass_pooled_auc=reference['equal_clinical_mass_pooled_auc'],not_independent_confirmation=True,official_test_read=False,sealed_read=False,submissions=0)
 (dest/'FREEZE_COMPLETE.json').write_text(json.dumps(record,indent=2))
 for p in dest.rglob('*'):
  if p.is_file():p.chmod(0o444)
 lines=['# 验证口径修复与训练对照（2026-10-30）','',
 '当前最高内部参考AUC为 **82.847773%**，按健康、抑郁人群各占一半权重，合并全部开发预测计算。它不是官方测试分数，也不是对官方成绩的保证。原84.820069%仅是健康40人、抑郁20人构成下的开发集AUC，今后只作次要指标。','',
 '## 已完成的纠正','',
 f'原先216份保存的候选预测已统一核对标签、被试顺序及概率范围；加入本轮8份新输出后，共重算{summary["aligned_outputs"]}份。它们全部是同一60人、2400条10秒记录。不同校准输出可能对应同一个模型，份数不代表独立模型或独立试验数。',
 '修正后的数值最高候选仍是原16次排序重采样方案，并未发现被旧指标遗漏的更强候选。所有结果保存在CSV中，数值排名本身不构成无泄漏或独立泛化认证。','',
 '同时按固定种子抽取2000个5名健康+5名抑郁的组合，每人使用同一10秒crop的8段预测，共80条。每个组合将80条概率合并计算一次AUC，未按单个人AUC平均。',
 f'该候选的模拟组合平均AUC为{reference["simulated_5HC5DEP80_mean_auc"]*100:.4f}%，中位数为{reference["simulated_5HC5DEP80_median_auc"]*100:.4f}%。组合不同会导致较大波动。这些模拟使用既有跨折OOF预测，组合中的人可能来自不同外层模型；它们不是重新训练一个模型后面对10名未见被试的独立测试，分位数也不是官方成绩的置信区间。','',
 '## 两项新的训练对照','',
 '基础模型和数据缓存复用，仅重新拟合融合头：源训练数据中健康和抑郁各占一半损失权重；条件似然和条件后验全体正负记录对排序损失各50%，C沿用.01。比较完整源训练拟合与固定64次被试级子采样。参数在本轮外层评价前固定，既有开发结果已经被看过，仍属于探索。','',
 '|方案|人群各半合并AUC|抑郁组AUC|','|---|---:|---:|',f'|保留的16次候选|{reference["equal_clinical_mass_pooled_auc"]*100:.6f}%|{reference["DEP_auc"]*100:.6f}%|']
 for name,r in review['results'].items():lines.append(f'|新1:1损失 / {name}|{r["equal_clinical_mass_pooled_auc"]*100:.6f}%|{r["DEP_auc"]*100:.6f}%|')
 lines+=['','两项对照均未超过现有候选，所以不替换。官方测试人群比例要求修正评价及选模，不能推导出训练损失强制1:1必然更好。','',
 '五折模型均已保存并独立重载；隐藏查询情绪标签、临床诊断、训练标记和trial编号，打乱查询行、替换被试ID后，最大预测差约5.01e-13。验证了每个源拟合中健康、抑郁的损失总权重各半，以及概率保留10/12/14位时新参考AUC一致。原基础模型未重训，校准策略沿用既有源内层规则；不声称新完成更深层元模型校准交叉验证。','',
 '## 短板诊断','',
 f'保留候选在健康组的合并AUC为{reference["HC_auc"]*100:.4f}%，抑郁组为{reference["DEP_auc"]*100:.4f}%。逐人、逐crop的8段排序诊断显示，抑郁组中位数为{diagnosis["within_person_diagnostics"]["DEP"]["median"]*100:.2f}%，健康组为{diagnosis["within_person_diagnostics"]["HC"]["median"]*100:.2f}%。这两个逐人诊断值是辅助指标，不是主合并AUC。差距分布于多名被试，不能靠剔除某一人来处理。',
 '后续优先筛选能给抑郁组提供补充信息的特征和训练方式，同时检查跨人群正负记录排序。不要继续仅增加融合成员数，也不要反复挑选模拟测试组合。','',
 '## 新的报告与确认规则','',
 '- 新报告必须优先使用健康/抑郁各半的内部合并AUC，明确写“内部参考”，保留旧40:20指标为次要列。AUC不称作分类正确率。',
 '- 成员选择、参数及校准在源训练范围内确定；如果已有OOF特征不足以做严格嵌套元验证，需要追加源训练折，不能直接再切OOF行并声称完全嵌套。',
 '- 真正按5+5被试重训的内部验证尚未在本轮完成，不能把本轮OOF模拟当成它。今后即使重切开发集，它仍不是新的独立数据。',
 '- 独立确认前锁定唯一候选及比较方案，封存集仅用于最终确认，不用于不断试参数。',
 '- 本轮没有读取官方测试或封存集，没有提交竞赛结果；没有替换既有模型包。',
 '- `VALIDATION_CONTRACT_20261030.json`记录新口径及限制，供后续工作读取。原冻结脚本未改动，不能宣称新规范自动约束了所有历史脚本。','',
 '研究更新包含规范、源码、重算CSV、诊断及预测；需要原工程与已有模型，不能独立作为比赛推理包。完整新融合头及全部模拟数据已在本地冻结档案保存，原候选和旧基线均保留。','']
 report=out/'EEG_validation_recovery_20261030.md';report.write_text('\n'.join(lines),encoding='utf-8')
 archive=out/'EEG_validation_recovery_20261030.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  z.write(report,'REPORT.md');z.write(contractfile,contractfile.name);z.write(dest/'FREEZE_COMPLETE.json','LOCAL_FREEZE_COMPLETE.json');z.write(dest/'reference_rank16_oof.npz','reference_rank16_oof.npz')
  for script in scripts:z.write(driver.JOB/script,'source/'+script)
  for directory in ['official_validation_recovery_20261030','official_balanced_rank_20261030','official_balanced_rank_review_20261030']:
   for p in sorted((driver.JOB/directory).glob('*')):
    if p.is_file() and (p.suffix in ('.json','.csv') or (directory=='official_balanced_rank_20261030' and p.suffix=='.npz')):z.write(p,directory+'/'+p.name)
 with zipfile.ZipFile(archive) as z:assert z.testzip() is None
 for rel,r in files.items():assert sha(dest/rel)==r['sha256']
 receipt=dict(report=str(report),archive=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),freeze=str(dest),files=len(files),aligned_outputs=summary['aligned_outputs'],primary_reference_auc=reference['equal_clinical_mass_pooled_auc'],new_controls_improved=False,baseline_preserved=True,checks_passed=True)
 (out/'EEG_validation_recovery_20261030_artifacts.json').write_text(json.dumps(receipt,indent=2))
 print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
