"""Diagnostic re-scoring of saved OOF predictions; no training or test access.

Equal clinical mass pooled AUC is distinct from mean subgroup AUC. Simulations
reuse cross-fold development predictions and are NOT independent test sets.
"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import csv,hashlib,json
from pathlib import Path
import numpy as np
from scipy.stats import rankdata
from sklearn.metrics import roc_auc_score
import driver

OUT=driver.JOB/'official_validation_recovery_20261030'
SCENARIOS=2000
SEED=2026103008

def main():
 OUT.mkdir(exist_ok=True)
 spec=dict(official_public_HC=5,official_public_DEP=5,trials_per_person=8,record_seconds=10,
  primary_reference='Pooled AUC with equal total HC/DEP weight, not subgroup macro AUC',
  diagnostic_scenarios=SCENARIOS,seed=SEED,scenario_sampling='5HC+5DEP without replacement, one crop per person, all8trials',
  predictions='Previously saved outer OOF; multiple outer models, NOT one refit model facing10 unseen people',
  no_fresh_validation=True,all_candidates_previously_development_exposed=True,
  scenario_intervals='Descriptive spread of overlapping simulated sets, not a confidence interval for official score',
  official_and_sealed_not_opened=True,submissions=0,script_sha256=driver.sha(__file__))
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==spec
 else:driver.save(OUT/'protocol.json',spec)
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as f:full={k:f[k] for k in ['subject','label','diagnosis','crop','trial']}
 s,y,diag=full['subject'],full['label'],full['diagnosis'];ids=np.unique(s)
 assert len(ids)==60 and len(y)==2400
 people_diag=np.array([diag[np.flatnonzero(s==person)[0]] for person in ids])
 assert (people_diag==0).sum()==40 and (people_diag==1).sum()==20
 cube=np.empty((60,5,8),dtype=int)
 for i,person in enumerate(ids):
  for crop in range(5):
   rows=np.flatnonzero((s==person)&(full['crop']==crop));rows=rows[np.argsort(full['trial'][rows])]
   assert len(rows)==8 and y[rows].sum()==4 and np.array_equal(full['trial'][rows],np.arange(1,9));cube[i,crop]=rows
 rng=np.random.default_rng(SEED);indices=[]
 for _ in range(SCENARIOS):
  people=np.r_[rng.choice(np.flatnonzero(people_diag==0),5,replace=False),rng.choice(np.flatnonzero(people_diag==1),5,replace=False)]
  crops=rng.integers(0,5,len(people));indices.append(cube[people,crops].ravel())
 indices=np.array(indices);sy=y[indices];assert np.all(sy.sum(1)==40)
 np.savez_compressed(OUT/'diagnostic_scenarios.npz',indices=indices)
 w=np.where(diag==1,2.,1.);rows=[];skipped=[];scenario_results={}
 anchorfile=driver.JOB/'pooled_rank_bag_20261030/subbag16_rawmean_calibrated_oof.npz'
 with np.load(anchorfile) as f:anchor=f['probability']
 def simulated(q):
  ranks=rankdata(q[indices],axis=1,method='average');return ((ranks*sy).sum(1)-40*41/2)/(40*40)
 anchor_sim=simulated(anchor)
 for path in sorted(driver.JOB.rglob('*oof.npz')):
  if OUT in path.parents:continue
  rel=str(path.relative_to(driver.JOB))
  try:
   with np.load(path) as f:
    if not {'labels','subjects','probability'}<=set(f.files):raise ValueError('Missing canonical labels/subjects/probability fields')
    if not np.array_equal(y,f['labels']) or not np.array_equal(s,f['subjects']):raise ValueError('Different or unaligned evaluation cohort/order; not silently comparable')
    q=f['probability']
   if q.shape!=y.shape or not np.all(np.isfinite(q)) or np.any((q<0)|(q>1)):raise ValueError('Not a finite canonical probability vector')
   if any(t in rel.lower() for t in ['50s','50sec','full_trial_aggregate']):raise ValueError('Explicitly aggregated long-trial candidate excluded from10s comparison')
   sim=simulated(q);assert abs(sim[0]-roc_auc_score(sy[0],q[indices[0]]))<1e-12
   record=dict(candidate=rel,development_pooled_auc=float(roc_auc_score(y,q)),equal_clinical_mass_pooled_auc=float(roc_auc_score(y,q,sample_weight=w)),HC_auc=float(roc_auc_score(y[diag==0],q[diag==0])),DEP_auc=float(roc_auc_score(y[diag==1],q[diag==1])),simulated_5HC5DEP80_mean_auc=float(sim.mean()),simulated_5HC5DEP80_median_auc=float(np.median(sim)),simulated_5HC5DEP80_q025=float(np.quantile(sim,.025)),simulated_5HC5DEP80_q975=float(np.quantile(sim,.975)),simulated_delta_mean_vs_rank16=float((sim-anchor_sim).mean()),prediction_sha256=hashlib.sha256(q.tobytes()).hexdigest(),eligibility='Numerically aligned only; training/selection provenance needs separate review')
   rows.append(record);scenario_results[rel]=sim
  except (ValueError,KeyError,TypeError) as exc:skipped.append(dict(path=rel,reason=str(exc)))
 rows.sort(key=lambda r:r['equal_clinical_mass_pooled_auc'],reverse=True)
 assert len(rows)>0
 with (OUT/'all_aligned_candidates.csv').open('w',newline='',encoding='utf-8-sig') as f:
  wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
 np.savez_compressed(OUT/'simulated_aucs.npz',paths=np.array(list(scenario_results)),auc=np.array(list(scenario_results.values())))
 driver.save(OUT/'summary.json',dict(protocol=spec,aligned_outputs=len(rows),skipped_outputs=len(skipped),top20=rows[:20],rank16_reference=next(r for r in rows if r['candidate']==str(anchorfile.relative_to(driver.JOB))),not_independent_confirmation=True,provenance_review_required_before_promoting_top=True))
 driver.save(OUT/'skipped.json',skipped)
 print(json.dumps(dict(aligned=len(rows),skipped=len(skipped),top12=rows[:12]),indent=2),flush=True)

if __name__=='__main__':main()
