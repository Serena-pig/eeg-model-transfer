"""Report frozen evidence and further exploratory ranking-bag fits."""
import hashlib,json,zipfile
from pathlib import Path
import driver

def main():
 root=driver.JOB.parent;out=Path('/workspace/output');frozen=root/'frozen_baselines/candidate_rankbag_20261030'
 meta=json.loads((frozen/'FREEZE_COMPLETE.json').read_text())
 first=json.loads((driver.JOB/'gain_reality_audit_20261030/audit.json').read_text())
 last=json.loads((driver.JOB/'rankbag_gain_audit_20261030/audit.json').read_text())
 best=meta['primary'].split('/')[0];score=last['new_auc'];dep=meta['selections'][best]['DEP_auc']
 lines=['# AUC提升核验及排序重采样实验','',
 '**结论：原84.752986%的数值提升能够复现，但尚不能确认真实泛化提高。进一步训练的最高数值候选为'+f' {score*100:.6f}%'+f'，抑郁组 {dep*100:.6f}%。这是重复使用开发集的探索结果，不是官方测试成绩。**','',
 '## 对84.752986%提升的审计','',
 '- 旧版84.585556%与新版84.752986%使用同一60人、2400条10秒记录、相同标签、相同外层划分和合并AUC口径；冻结文件哈希一致。',
 '- 被试层面的训练/验证划分不重叠；保存的融合头此前独立重载，隐藏标签及临床诊断、替换被试ID并打乱行顺序，预测差小于5e-13。本审计检查已保存划分及特征索引，不宣称重新训练全部基础模型。',
 '- 每次剔除一名被试后，60次比较均仍为正，AUC差为0.1191至0.1974个百分点。但五折只有三折提高，两折降低。',
 '- 按健康/抑郁分层、以完整被试为单位的20000次配对bootstrap，提升95%区间为[-0.0493, 0.3913]个百分点。完整被试预测交换检验的探索性双侧p约0.1378；59次尝试的粗略Bonferroni值为1，实际整个研究的尝试更多。',
 '- 因此没有发现本次比较因换口径、单一被试或已检查的划分重叠而虚增，但不能由此证明整个历史训练流程无任何泄漏；元模型的反复挑选会使开发分数乐观。重采样区间也没有涵盖完整重训及模型选择的不确定性。','',
 '|折|旧AUC|原新候选AUC|差值（百分点）|','|---|---:|---:|---:|']
 for f in first['folds']:lines.append(f"|{f['fold']}|{100*f['old_auc']:.6f}%|{100*f['new_auc']:.6f}%|{100*f['delta']:+.6f}|")
 lines+=['','## 进一步探索：被试级排序重采样','',
 '保留87来源模型，仅重训融合头。每次在源训练被试中按临床组分层抽取80%，完整保留该被试所有记录；固定C=.01，条件似然与条件后验成对排序损失各50%。临床比例保持源数据实际比例。没有将切片当作独立被试抽样，也没有把这些重复预测当成额外独立验证样本。','',
 '先固定16次重采样完成五折，再在看过16次开发结果后扩至固定64次，保留相同的前16个模型。扩展是受先前开发结果启发的探索，不能当作一项新的独立确认。没有搜索外层融合权重。','',
 '|方案|合并AUC|抑郁组AUC|','|---|---:|---:|',
 '|原84.5856%候选|84.585556%|75.660000%|',
 '|上轮84.753%候选|84.752986%|75.934375%|']
 for directory,r in meta['selections'].items():lines.append(f"|{directory}|{r['pooled_auc']*100:.6f}%|{r['DEP_auc']*100:.6f}%|")
 lo,hi=last['stratified_person_bootstrap_20000']['delta_95CI']
 lines+=['','16次重采样的84.8201%在扩至64次后回落至84.7533%。这不是同一个保存模型重载失败，而是增加抽样成员后收益发生回落；不能据此宣称16次方案有稳定优势。保留它仅为最高数值实验候选，不把它升级为确认基线。',
 f'最高候选距离85%仍差 {(0.85-score)*100:.6f} 个百分点。已独立重载五折模型并核对取整稳定性；保存的所有折均完整，不报告未完成模型的拼接分数。',
 f'最高候选相对84.585556%的按被试配对区间为[{lo*100:.6f}, {hi*100:.6f}]个百分点，探索性双侧p为{last["paired_person_swap_20000"]["two_sided_p"]:.6f}。区间与p均未解决重复筛选偏差，不能据此宣布稳定泛化已经提高。','',
 '## 保存及后续使用','',
 '- 保留所有原冻结基线。新候选状态为实验候选，未替换正式基线；已保存模型、预测、配置及文件哈希。',
 '- 未读取封存集和官方公开测试；未提交竞赛结果。独立确认仍需要预先锁定唯一候选及验证方案，再使用未参与模型选择的数据一次性比较。',
 '- 本更新包包含审计代码、结果、两种重采样方案的预测和最高候选的五折融合头。它依赖既有87来源模型及原工程，不是独立比赛推理包。',
 '- 不应把后续每次调参都拿封存集反复比较，或把这份开发分数说成官方80条预测的AUC。','']
 report=out/'EEG_gain_audit_rankbag_20261030.md';report.write_text('\n'.join(lines),encoding='utf-8')
 archive=out/'EEG_gain_audit_rankbag_20261030.zip'
 scripts=['audit_gain_reality_20261030.py','audit_rankbag_gain_20261030.py','pooled_rank_bag_20261030.py','pooled_rank_bag64_20261030.py','review_rank_bag_20261030.py','review_rank_bag64_20261030.py','freeze_rankbag_round_20261030.py','report_gain_audit_round_20261030.py']
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  z.write(report,'REPORT.md');z.write(frozen/'FREEZE_COMPLETE.json','FREEZE_COMPLETE.json')
  for script in scripts:z.write(driver.JOB/script,'source/'+script)
  for directory in ['gain_reality_audit_20261030','rankbag_gain_audit_20261030','rank_bag_review_20261030','rank_bag64_review_20261030','pooled_rank_bag_20261030','pooled_rank_bag64_20261030']:
   for p in sorted((driver.JOB/directory).glob('*')):
    if p.is_file() and (p.suffix in ('.json','.npz') or (directory==best and p.suffix=='.joblib')):z.write(p,directory+'/'+p.name)
 with zipfile.ZipFile(archive) as z:assert z.testzip() is None
 for rel,r in meta['files'].items():assert hashlib.sha256((frozen/rel).read_bytes()).hexdigest()==r['sha256']
 receipt=dict(report=str(report),archive=str(archive),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),best_pooled_auc=score,best_DEP_auc=dep,generalization_confirmed=False,freeze=str(frozen),zip_crc_and_frozen_hashes_pass=True)
 (out/'EEG_gain_audit_rankbag_20261030_artifacts.json').write_text(json.dumps(receipt,indent=2))
 print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
