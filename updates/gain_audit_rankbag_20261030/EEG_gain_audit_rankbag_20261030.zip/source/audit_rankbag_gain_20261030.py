"""Audit a frozen comparison, using person clusters rather than 2400 IID rows.
Does not fit/select models or read sealed/competition data.
"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import json,hashlib
from pathlib import Path
import numpy as np
from sklearn.metrics import roc_auc_score
import driver
from postflight import pair_matrix

def main():
 out=driver.JOB/'rankbag_gain_audit_20261030';out.mkdir(exist_ok=True)
 root=driver.JOB.parent
 a=root/'frozen_baselines/candidate_845856_20261030'
 b=root/'frozen_baselines/candidate_rankbag_20261030'
 for folder in (a,b):
  manifest=json.loads((folder/'FREEZE_COMPLETE.json').read_text())
  entries=manifest['files'].items() if isinstance(manifest['files'],dict) else [(r['path'],r) for r in manifest['files']]
  for rel,record in entries:
   assert hashlib.sha256((folder/rel).read_bytes()).hexdigest()==record['sha256'],rel
 oldpath=a/'aligned_covariance_fusion_20261030/conditional_BCE87_calibrated_oof.npz'
 newpath=b/json.loads((b/'FREEZE_COMPLETE.json').read_text())['primary']
 with np.load(oldpath) as f:y=f['labels'];s=f['subjects'];old=f['probability']
 with np.load(newpath) as f:
  assert np.array_equal(y,f['labels']) and np.array_equal(s,f['subjects']);new=f['probability']
 ids=np.unique(s);assert len(ids)==60 and len(y)==2400
 for person in ids:
  rows=s==person;assert rows.sum()==40 and y[rows].sum()==20
 p=driver.protocol();folds=[];coverage=[]
 with np.load(driver.ART/'features.npz') as f:subjects=f['subject'];labels=f['label']
 for fold in p['folds']:
  tr=set(fold['training_subjects']);va=set(fold['validation_subjects']);assert not tr&va
  coverage+=list(va);inner_coverage=[]
  for inner in fold['inner']:
   it=set(inner['training_subjects']);iv=set(inner['validation_subjects']);assert not it&iv and it|iv==tr
   inner_coverage+=list(iv)
  assert len(inner_coverage)==len(set(inner_coverage)) and set(inner_coverage)==tr
  k=fold['fold']
  with np.load(driver.JOB/f'cached_group_diagnostics_20261030/fold{k}_aligned_banks.npz') as f:
   ti=f['inner_indices'];vi=f['outer_indices'];assert not set(ti)&set(vi)
   assert set(subjects[ti])<=tr and set(subjects[vi])<=va
  mask=np.isin(s,list(va));oldauc=roc_auc_score(y[mask],old[mask]);newauc=roc_auc_score(y[mask],new[mask])
  folds.append(dict(fold=k,people=int(mask.sum()/40),old_auc=oldauc,new_auc=newauc,delta=newauc-oldauc))
 assert len(coverage)==len(set(coverage))==60 and set(coverage)==set(ids)
 oldmat=pair_matrix(y,old,s,ids);newmat=pair_matrix(y,new,s,ids);delta=newmat-oldmat
 observed=float(delta.mean());assert abs(observed-(roc_auc_score(y,new)-roc_auc_score(y,old)))<1e-12
 # Stratified paired person bootstrap; every person's complete trial/crop cluster remains intact.
 rng=np.random.default_rng(2026103001);counts=np.zeros((20000,len(ids)))
 for clinical in ('HC','DEP'):
  ii=np.flatnonzero(np.char.startswith(ids,clinical));draws=rng.choice(ii,(len(counts),len(ii)),replace=True)
  for j in range(len(counts)):counts[j]+=np.bincount(draws[j],minlength=len(ids))
 bs=np.einsum('bi,ij,bj->b',counts,delta,counts,optimize=True)/60**2
 # Paired cluster randomization: swap whole-person new/old forecast vectors.
 # Evaluate all person-pair comparisons exactly through four 60x60 matrices.
 def mixed(pos,neg):
  pp=np.stack([pos[(s==person)&(y==1)] for person in ids]);nn=np.stack([neg[(s==person)&(y==0)] for person in ids])
  x=pp[:,None,:,None];z=nn[None,:,None,:];return ((x>z)+.5*(x==z)).mean((2,3))
 cross01=mixed(old,new);cross10=mixed(new,old)
 swaps=rng.integers(0,2,(20000,60));u=swaps;v=1-u
 def quadratic(x,m,z):return np.einsum('bi,ij,bj->b',x,m,z,optimize=True)
 null=(quadratic(v,oldmat,v)+quadratic(v,cross01,u)+quadratic(u,cross10,v)+quadratic(u,newmat,u)
       -quadratic(u,oldmat,u)-quadratic(u,cross01,v)-quadratic(v,cross10,u)-quadratic(v,newmat,v))/60**2
 pvalue=(1+int(np.sum(np.abs(null)>=abs(observed))))/(len(null)+1)
 loo=[]
 for j,person in enumerate(ids):
  keep=np.arange(60)!=j;loo.append(dict(subject=str(person),delta=float(delta[np.ix_(keep,keep)].mean())))
 groups=np.char.startswith(ids,'DEP');parts={}
 for title,rows,cols in [('HCpos_HCneg',~groups,~groups),('DEPpos_DEPneg',groups,groups),('HCpos_DEPneg',~groups,groups),('DEPpos_HCneg',groups,~groups)]:
  pieces=delta[np.ix_(rows,cols)];parts[title]=dict(delta=float(pieces.mean()),contribution_to_global_delta=float(pieces.sum()/3600))
 receipt=dict(replay='Independent native fusion replay already passed, maximum absolute difference <5e-13',frozen_hashes_verified=True,source_inner_and_outer_subjects_disjoint=True,identical_labels_subject_order_and_10second_metric=True,people=60,records=2400,old_auc=float(roc_auc_score(y,old)),new_auc=float(roc_auc_score(y,new)),delta=observed,folds=folds,folds_improved=int(sum(f['delta']>0 for f in folds)),leave_one_person_out=dict(min_delta=min(z['delta'] for z in loo),max_delta=max(z['delta'] for z in loo),positive_comparisons=int(sum(z['delta']>0 for z in loo)),total=60),stratified_person_bootstrap_20000=dict(delta_95CI=np.quantile(bs,[.025,.975]).tolist(),resamples_positive_fraction=float((bs>0).mean())),paired_person_swap_20000=dict(two_sided_p=pvalue,bonferroni_59_exploratory_p=min(1.,59*pvalue)),clinical_pair_decomposition=parts,rows_not_independent=True,development_reused=True,search_trials_at_least=59,generalization_improvement_confirmed=False,reason=('Person bootstrap CI includes zero. ' if np.quantile(bs,.025)<=0 else 'Pointwise person bootstrap CI excludes zero, but this is not search-adjusted. ')+'Reused development data cannot independently confirm generalization.',sealed_opened=False,official_test_opened=False,competition_submissions=0)
 driver.save(out/'audit.json',receipt);driver.save(out/'leave_one_person_out.json',loo)
 print(json.dumps(receipt,indent=2),flush=True)

if __name__=='__main__':main()
