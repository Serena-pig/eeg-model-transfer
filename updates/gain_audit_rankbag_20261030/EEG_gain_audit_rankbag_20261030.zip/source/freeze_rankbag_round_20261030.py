"""Freeze ranking subbag experiments without replacing a confirmed baseline."""
import hashlib,json,shutil
from pathlib import Path
import driver

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
 root=driver.JOB.parent;dest=root/'frozen_baselines/candidate_rankbag_20261030'
 names=['pooled_rank_bag_20261030','pooled_rank_bag64_20261030']
 selections={}
 for name in names:
  summary=json.loads((driver.JOB/name/'summary.json').read_text())
  verification=json.loads((driver.JOB/name/'verification.json').read_text());assert verification['checks_passed'] and verification['all5outer_complete']
  reviewdir='rank_bag64_review_20261030' if 'bag64' in name else 'rank_bag_review_20261030'
  review=json.loads((driver.JOB/reviewdir/'independent_review.json').read_text());assert review['checks_passed']
  key='subbag64_rawmean_calibrated' if 'bag64' in name else 'subbag16_rawmean_calibrated'
  selections[name]=dict(path=name+'/'+key+'_oof.npz',**summary['results'][key])
 assert not dest.exists(),'Do not overwrite a frozen candidate'
 dest.mkdir()
 directories=names+['rank_bag_review_20261030','rank_bag64_review_20261030','gain_reality_audit_20261030']
 for name in directories:shutil.copytree(driver.JOB/name,dest/name)
 for name in ['pooled_rank_bag_20261030.py','pooled_rank_bag64_20261030.py','review_rank_bag_20261030.py','review_rank_bag64_20261030.py','audit_gain_reality_20261030.py','freeze_rankbag_round_20261030.py']:
  shutil.copy2(driver.JOB/name,dest/name)
 best=max(selections,key=lambda k:selections[k]['pooled_auc'])
 files={str(p.relative_to(dest)):dict(sha256=sha(p),bytes=p.stat().st_size) for p in sorted(dest.rglob('*')) if p.is_file()}
 metadata=dict(status='experimental_only_not_promoted',primary=selections[best]['path'],selections=selections,files=files,development_reused=True,earlier_outer_feedback_seen=True,generalization_improvement_confirmed=False,requires_existing_87_base_models=True,standalone_inference_package=False,dependency_manifest='../candidate_847530_20261030/FREEZE_COMPLETE.json',dependency_manifest_sha256=sha(root/'frozen_baselines/candidate_847530_20261030/FREEZE_COMPLETE.json'),official_test_opened=False,sealed_opened=False,submissions=0)
 (dest/'FREEZE_COMPLETE.json').write_text(json.dumps(metadata,indent=2))
 for p in dest.rglob('*'):
  if p.is_file():p.chmod(0o444)
 (root/'CURRENT_EXPERIMENTAL_RANKBAG.txt').write_text(str(dest)+'\n')
 print(json.dumps(dict(freeze=str(dest),primary=metadata['primary'],selections=selections,files=len(files)),indent=2))

if __name__=='__main__':main()
