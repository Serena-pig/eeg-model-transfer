"""Execution-only aggregation recovery using the unchanged original per-fold equations."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import argparse,json,hashlib,numpy as np
from threadpoolctl import threadpool_limits
import run_leaderboard_neural_v2 as r

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);out=ap.parse_args().out;limits=threadpool_limits(limits=1);plan=json.loads((out/'plan.json').read_text());assert plan['code_sha256']==hashlib.sha256(Path(r.__file__).read_bytes()).hexdigest() and plan['models_sha256']==hashlib.sha256(Path(r.models.__file__).read_bytes()).hexdigest();_,y,g,keys,split,meta=r.load_data();anchor,rep=r.r.protocol.outer_reference(y,g);records=[json.loads((out/f'fold{fold}.json').read_text()) for fold in range(1,6)];pred={name:np.full(len(y),np.nan) for name in records[0]['choices']};count=np.zeros(len(y),int)
    for fold,(aa,bb) in enumerate(r.r.r.base.folds(split['development']),1):
        rec=records[fold-1];iv=np.flatnonzero(np.isin(g,bb));assert rec['training_subjects']==aa.tolist() and rec['validation_subjects']==bb.tolist();assert set(aa).isdisjoint(bb) and set(aa).isdisjoint(split['holdout'])
        with np.load(out/f'fold{fold}_outer.npz') as d:
            assert np.array_equal(d['indices'],iv);count[iv]+=1
            for name in pred:pred[name][iv]=d[name]
    assert np.all(count==1);summary=dict(folds=records)
    for name,p in {**pred,'baseline':anchor}.items():
        assert np.isfinite(p).all() and ((p>=0)&(p<=1)).all();summary[name]=r.r.summarize(y,p,g,keys,rep);np.savez_compressed(out/(name+'_oof.npz'),labels=y,subjects=g,group_ids=keys,representative=rep,probability=p)
    r.common.atomic_json(out/'summary.json',summary);r.common.atomic_json(out/'COLLECTION_REPLAY.json',dict(original_fitting_code_unchanged=True,all_five_outer_arrays_copied_once=True,holdout_loaded=False,public_test_loaded=False,collector_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()));print('ORIGINAL PER-FOLD AGGREGATION RECOVERED',out,flush=True)
if __name__=='__main__':main()
