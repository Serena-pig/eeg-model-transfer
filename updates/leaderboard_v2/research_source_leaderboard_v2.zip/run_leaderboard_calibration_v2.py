"""New calibration of the frozen best ensemble. Official/holdout signals never read."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from datetime import datetime
import json,hashlib,itertools,joblib
import numpy as np
from scipy.special import expit,logit,logsumexp
from scipy.stats import rankdata
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from threadpoolctl import threadpool_limits
import fuse_reference_bendr as fusion
import auc_cluster_bootstrap as boot
r=fusion.r;ROOT=fusion.ROOT;CHAMPION=ROOT/'runs/reference_bendr_fusion_20261024_175105_067385'
ASSIGN=np.zeros((70,8))
for j,subset in enumerate(itertools.combinations(range(8),4)):ASSIGN[j,list(subset)]=1.

def source(fold):
    plan=json.loads((CHAMPION/'plan.json').read_text());base={k:ROOT/'runs'/v for k,v in plan['base_sources'].items()};new={k:ROOT/'runs'/v for k,v in plan['new_sources'].items()};iy,ig,ip,cols,_,names=fusion.components(base,new,fold);rec=json.loads((CHAMPION/f'fold{fold}.json').read_text());assert names==rec['component_names'];z=fusion.stack.score(ip);score=z+np.column_stack([fusion.stack.score(v)-z for v in cols])@np.array(rec['coefficients']['person_bagged']);return iy,ig,expit(score)

def posterior(z,temp):
    energy=ASSIGN@(z/temp);lp=logsumexp(energy[:,None]+np.where(ASSIGN==1,0.,-np.inf),axis=0);ln=logsumexp(energy[:,None]+np.where(ASSIGN==0,0.,-np.inf),axis=0);return lp-ln

def transform(p,keys,kind,param=1.):
    out=np.empty(len(p));z=logit(np.clip(p,1e-9,1-1e-9))
    for key in np.unique(keys):
        ix=np.flatnonzero(keys==key);a=z[ix];assert len(ix)==8;v=a-a.mean()
        if kind=='temperature':out[ix]=expit(v/max(a.std(),.25)**param)
        elif kind=='median':out[ix]=expit((a-np.median(a))/max(a.std(),.25)**param)
        else:out[ix]=expit(posterior(a,param))
    return out

def features(p,keys):
    z=logit(np.clip(p,1e-9,1-1e-9));out=np.empty((len(p),12))
    for key in np.unique(keys):
        ix=np.flatnonzero(keys==key);v=z[ix];a=v-v.mean();b=v-np.median(v);sd=max(v.std(),.25);rz=a/sd;rank=logit((rankdata(v)-.5)/8);gap=np.sort(v)[4]-np.sort(v)[3]
        out[ix]=np.c_[v,a,b,rz,rank,posterior(v,.5),posterior(v,1.),posterior(v,2.),rz*np.log(sd),rz*np.log(.1+gap),np.tanh(rz),np.tanh(rz/2)]
    return out

class ContextCalibration:
    def __init__(self,C):self.C=C
    def fit(self,p,y,g,keys):
        x=features(p,keys);self.scaler=StandardScaler().fit(x);self.model=LogisticRegression(C=self.C,fit_intercept=False,max_iter=2000,random_state=42).fit(self.scaler.transform(x),y,sample_weight=np.where(np.char.startswith(g,'DEP'),2.,1.));self.source_subjects=np.unique(g).tolist();return self
    def predict(self,p,keys):return self.model.predict_proba(self.scaler.transform(features(p,keys)))[:,1]

def main():
    limits=threadpool_limits(limits=1);_,_,y,g,keys,split=r.load_data();assert json.loads((CHAMPION/'verification.json').read_text())['checks_passed']
    with np.load(CHAMPION/'person_bagged_oof.npz') as d:assert np.array_equal(y,d['labels']) and np.array_equal(g,d['subjects']);prior=d['probability'];rep=d['representative']
    out=ROOT/'runs'/('leaderboard_calibration_v2_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'));out.mkdir();(ROOT/'CURRENT_LEADERBOARD_CALIBRATION_V2.txt').write_text(str(out));plan=dict(source=CHAMPION.name,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),primary='overall_selected',temperatures=[.5,1.,2.,4.],scale_powers=[-.5,0.,.5,1.],C=[.001,.01,.1,1.],blend=[.1,.25,.5,1.],source_only=True,holdout_not_loaded=split['holdout'],public_test_loaded=False,not_fresh_validation=True,limitation='Existing source-OOF base predictions used for calibration CV; meta-training predictions may depend on other source-inner labels. Source fitting is not unbiased validation. Every outer person remains excluded from all fitting and selection.');r.r.base.save(out/'plan.json',plan);policies=['overall_selected','context_only','fixed_posterior'];pred={k:np.full(len(y),np.nan) for k in policies};records=[]
    for fold,(aa,bb) in enumerate(r.r.base.folds(split['development']),1):
        iy,ig,ip=source(fold);ik=r.r.group_ids(ig);assert set(ig)==set(aa) and set(ig).isdisjoint(bb) and set(ig).isdisjoint(split['holdout']);va=np.isin(g,bb);inner=list(r.r.base.folds(aa,n=3))
        def objective(p):return float(np.mean([boot.evaluation(iy[np.isin(ig,b)],p[np.isin(ig,b)],ig[np.isin(ig,b)],ik[np.isin(ig,b)])['auc'] for _,b in inner]))
        rows=[dict(kind='baseline',parameter=0.,blend=0.,auc=objective(ip))];cache={}
        for kind,parameters in [('temperature',plan['scale_powers']),('median',plan['scale_powers']),('posterior',plan['temperatures'])]:
            for parameter in parameters:
                q=transform(ip,ik,kind,parameter);cache[kind+':'+str(parameter)]=q
                for blend in plan['blend']:rows.append(dict(kind=kind,parameter=parameter,blend=blend,auc=objective(blend*q+(1-blend)*ip)))
        for C in plan['C']:
            q=np.full(len(ip),np.nan)
            for a,b in inner:
                tr=np.isin(ig,a);vv=np.isin(ig,b);model=ContextCalibration(C).fit(ip[tr],iy[tr],ig[tr],ik[tr]);q[vv]=model.predict(ip[vv],ik[vv])
            cache['context:'+str(C)]=q
            for blend in plan['blend']:rows.append(dict(kind='context',parameter=C,blend=blend,auc=objective(blend*q+(1-blend)*ip)))
        choices=dict(overall_selected=max(rows,key=lambda v:v['auc']),context_only=max([v for v in rows if v['kind']=='context' and v['blend']==1.],key=lambda v:v['auc']),fixed_posterior=dict(kind='posterior',parameter=1.,blend=1.,auc=objective(cache['posterior:1.0'])));models={}
        for name,c in choices.items():
            q=prior[va]
            if c['kind']=='context':
                if c['parameter'] not in models:models[c['parameter']]=ContextCalibration(c['parameter']).fit(ip,iy,ig,ik);joblib.dump(models[c['parameter']],out/f'fold{fold}_C{c["parameter"]}.joblib')
                q=models[c['parameter']].predict(q,keys[va])
            elif c['kind']!='baseline':q=transform(q,keys[va],c['kind'],c['parameter'])
            pred[name][va]=c['blend']*q+(1-c['blend'])*prior[va]
        rec=dict(fold=fold,training_subjects=aa.tolist(),validation_subjects=bb.tolist(),choices=choices,source_candidates=rows);records.append(rec);r.r.base.save(out/f'fold{fold}.json',rec);np.savez_compressed(out/f'fold{fold}_inner.npz',labels=iy,subjects=ig,baseline_probability=ip,**cache);print('CALIBRATION V2 FOLD',fold,choices,flush=True)
    summary=dict(folds=records)
    for name,p in {**pred,'baseline':prior}.items():summary[name]=r.summarize(y,p,g,keys,rep);np.savez_compressed(out/(name+'_oof.npz'),labels=y,subjects=g,group_ids=keys,representative=rep,probability=p)
    r.r.base.save(out/'summary.json',summary);r.r.base.save(out/'bootstrap.json',{name:boot.compare(y,p,prior,g,rep,keys) for name,p in pred.items()});print('CALIBRATION V2 COMPLETE',out,flush=True)
if __name__=='__main__':main()
