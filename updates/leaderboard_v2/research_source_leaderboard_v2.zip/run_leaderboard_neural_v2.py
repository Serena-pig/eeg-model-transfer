"""5x3 person-disjoint simulated test adaptation, never official test adaptation."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from datetime import datetime
import argparse,json,gc
import numpy as np,torch
from threadpoolctl import threadpool_limits
import run_biot_projection as data
import run_extended_lora as common
import leaderboard_neural_v2 as models
r=data.r;ROOT=r.ROOT

def load_data():
    import run_pooled80 as sequences
    import run_group_auc as raw_data
    sequence,y,g,keys,split=sequences.load_data();raw,yy,gg,ss=raw_data.load();assert np.array_equal(y,yy) and np.array_equal(g,gg) and split==ss
    meta=dict(sequence_manifest=json.loads((ROOT/'de_sequence/development/manifest.json').read_text()),feature_manifest=json.loads((ROOT/'feature_ablation/development/manifest.json').read_text()),pretrained_encoder=False)
    return models.Bank(sequence,raw_data.normalize_features(raw['absolute_de'],keys,'zscore')),y,g,keys,split,meta

def fit_predictions(x,y,g,keys,it,iv,name,seed,folder,maximum=30):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);parts=[]
    for offset in models.SEEDS:
        sf=folder/f'seed{offset}';models.train(x,y,g,it,name,seed+offset,sf,maximum);result={}
        for epoch in models.EPOCHS:
            if epoch>maximum:continue
            predfile=sf/f'prediction_epoch{epoch}.npz'
            if predfile.exists():
                with np.load(predfile) as d:
                    assert np.array_equal(d['validation_indices'],iv);p={k:d[k] for k in d.files if k!='validation_indices'}
            else:
                ck=torch.load(sf/f'epoch_{epoch}.pt',map_location='cpu',weights_only=False);assert np.array_equal(ck['training_indices'],it);model=models.Model(name);model.load_state_dict(ck['state_dict'])
                p={'none':models.predict(model,x[iv])};assert all(np.isfinite(v).all() for v in p.values());np.savez_compressed(predfile,validation_indices=iv,**p);del model
            for tta,prob in p.items():result[str(epoch)+'__'+tta]=prob
        parts.append(result);gc.collect()
    assert set(parts[0])==set(parts[1]);return {key:np.mean([v[key] for v in parts],axis=0) for key in parts[0]}

def worker(root,fold):
    limits=threadpool_limits(limits=1);torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    out=Path(root);x,y,g,keys,split,meta=load_data();anchor,rep=r.protocol.outer_reference(y,g);aa,bb=list(r.r.base.folds(split['development']))[fold-1]
    if (out/f'fold{fold}_outer.npz').exists():return json.loads((out/f'fold{fold}.json').read_text())
    tr=np.flatnonzero(np.isin(g,aa));va=np.flatnonzero(np.isin(g,bb));inner=[(np.flatnonzero(np.isin(g,a)),np.flatnonzero(np.isin(g,b))) for a,b in r.r.base.folds(aa,n=3)];iy=np.concatenate([y[v] for _,v in inner]);ig=np.concatenate([g[v] for _,v in inner]);ik=r.r.group_ids(ig);base=r.protocol.inner_reference(fold,iy,ig)
    rows=[dict(config='baseline',epoch=-1,tta='none',post='raw',blend=0.,auc=common.inner_objective(iy,base,ig,ik))];scores={}
    for name in models.CONFIGS:
        parts=[]
        for j,(it,iv) in enumerate(inner):
            assert set(g[it]).isdisjoint(g[iv]) and set(g[it]).isdisjoint(bb) and set(g[it]).isdisjoint(split['holdout'])
            parts.append(fit_predictions(x,y,g,keys,it,iv,name,42+fold*100+j,out/f'checkpoints/fold{fold}_{name}_inner{j}'));print('BENDR GRU INNER COMPLETE',fold,name,j,flush=True)
        for key in parts[0]:
            p=np.concatenate([v[key] for v in parts]);scores[name+'__'+key]=p;epoch,tta=key.split('__')
            for post in ['raw','group_mean_logit']:
                for blend in [.1,.25,.5,1.]:rows.append(dict(config=name,epoch=int(epoch),tta=tta,post=post,blend=blend,auc=common.inner_objective(iy,blend*r.postprocess(p,ik,post)+(1-blend)*base,ig,ik)))
        common.atomic_json(out/f'fold{fold}_candidate_scores.json',rows)
    choices={'overall_selected':max(rows,key=lambda v:v['auc']),'pure_selected':max([v for v in rows if v['epoch']>0 and v['blend']==1.],key=lambda v:v['auc']),'pure_early':max([v for v in rows if v['epoch']==5 and v['blend']==1.],key=lambda v:v['auc'])}
    outer={};outputs={}
    for name in dict.fromkeys(c['config'] for c in choices.values() if c['epoch']>=0):
        maximum=max(c['epoch'] for c in choices.values() if c['config']==name);outer[name]=fit_predictions(x,y,g,keys,tr,va,name,42+fold*100+99,out/f'checkpoints/fold{fold}_{name}_outer',maximum)
    for policy,c in choices.items():outputs[policy]=anchor[va] if c['epoch']<0 else c['blend']*r.postprocess(outer[c['config']][str(c['epoch'])+'__'+c['tta']],keys[va],c['post'])+(1-c['blend'])*anchor[va]
    common.atomic_json(out/f'fold{fold}.json',dict(fold=fold,training_subjects=aa.tolist(),validation_subjects=bb.tolist(),choices=choices,inner_scores=rows));np.savez_compressed(out/f'fold{fold}_inner.npz',labels=iy,subjects=ig,baseline_probability=base,**scores);np.savez_compressed(out/f'fold{fold}_outer.npz',indices=va,**outputs);print('BENDR GRU OUTER COMPLETE',fold,choices,flush=True)
    return rec

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--resume-from',type=Path);args=ap.parse_args();limits=threadpool_limits(limits=1);torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    assert json.loads((ROOT/'leaderboard_neural_v2_interface_check.json').read_text())['passed'];x,y,g,keys,split,meta=load_data();anchor,rep=r.protocol.outer_reference(y,g)
    out=args.resume_from or ROOT/'runs'/('leaderboard_neural_v2_'  +datetime.now().strftime('%Y%m%d_%H%M%S_%f'));out.mkdir(parents=True,exist_ok=True)
    plan=dict(configurations=models.CONFIGS,epochs=models.EPOCHS,seed_offsets=models.SEEDS,source_only=True,source_optimization='Matched single-CNN, multi-kernel3/5/7 CNN, multi-kernelCNN-BiGRU, Transformer-MLP and Transformer-cubicB-spline-KAN; original10x6x30 DE and DE residual; balanced5HC5DEP80-row episodes, weighted pooled ranking and within-person loss; source-only scalers, cosine lr.0007->.00007 wd.05, channel/band dropout',selection='Mean of3 source-inner50/50 pooled AUC; config/epoch/post/blend source only; two fixed seeds averaged',code_sha256=data.digest(Path(__file__)),models_sha256=data.digest(ROOT/'leaderboard_neural_v2.py'),projection_manifest=meta,holdout_not_loaded=split['holdout'],public_test_loaded=False,submissions=0,not_fresh_validation=True)
    if (out/'plan.json').exists():assert json.loads((out/'plan.json').read_text())==plan
    else:common.atomic_json(out/'plan.json',plan)
    (ROOT/'CURRENT_LEADERBOARD_NEURAL_V2.txt').write_text(str(out));print('BENDR GRU RUN DIRECTORY',out,flush=True)
    from concurrent.futures import ProcessPoolExecutor,as_completed
    import multiprocessing
    with ProcessPoolExecutor(2,mp_context=multiprocessing.get_context('spawn')) as pool:
        for future in as_completed([pool.submit(worker,str(out),fold) for fold in range(1,6)]):future.result()
    records=[json.loads((out/f'fold{fold}.json').read_text()) for fold in range(1,6)];summary=dict(folds=records);preds={p:np.full(len(y),np.nan) for p in records[0]['choices']};counts=np.zeros(len(y),int)
    for fold in range(1,6):
        with np.load(out/f'fold{fold}_outer.npz') as d:
            counts[d['indices']]+=1
            for name in preds:preds[name][d['indices']]=d[name]
    assert np.all(counts==1)
    for name,p in {**preds,'baseline':anchor}.items():assert np.isfinite(p).all();summary[name]=r.summarize(y,p,g,keys,rep);np.savez_compressed(out/(name+'_oof.npz'),labels=y,subjects=g,group_ids=keys,representative=rep,probability=p)
    common.atomic_json(out/'summary.json',summary);print('BENDR GRU COMPLETE',out,flush=True)
if __name__=='__main__':main()
