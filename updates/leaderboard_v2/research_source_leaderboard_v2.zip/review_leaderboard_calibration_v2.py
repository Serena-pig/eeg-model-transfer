"""Reproduce source choices and all outer predictions before reporting AUC."""
from pathlib import Path
import sys,json,hashlib,joblib,numpy as np
from threadpoolctl import threadpool_limits
import run_leaderboard_calibration_v2 as m
sys.modules['__main__'].ContextCalibration=m.ContextCalibration
ROOT=m.ROOT

def main():
    limits=threadpool_limits(limits=1);out=Path((ROOT/'CURRENT_LEADERBOARD_CALIBRATION_V2.txt').read_text().strip());plan=json.loads((out/'plan.json').read_text());assert plan['script_sha256']==hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest();_,_,y,g,keys,split=m.r.load_data();summary=json.loads((out/'summary.json').read_text());count=np.zeros(len(y),int);largest=0.;refits=0
    with np.load(m.CHAMPION/'person_bagged_oof.npz') as d:prior=d['probability']
    for rec,(aa,bb) in zip(summary['folds'],m.r.r.base.folds(split['development'])):
        fold=rec['fold'];iy,ig,ip=m.source(fold);ik=m.r.r.group_ids(ig);assert set(ig)==set(aa) and set(ig).isdisjoint(bb) and set(ig).isdisjoint(split['holdout']);va=np.isin(g,bb);count[va]+=1;inner=list(m.r.r.base.folds(aa,n=3))
        def objective(p):return float(np.mean([m.boot.evaluation(iy[np.isin(ig,b)],p[np.isin(ig,b)],ig[np.isin(ig,b)],ik[np.isin(ig,b)])['auc'] for _,b in inner]))
        with np.load(out/f'fold{fold}_inner.npz') as d:
            assert np.array_equal(ip,d['baseline_probability']) and np.array_equal(ig,d['subjects'])
            for C in plan['C']:
                q=np.full(len(ip),np.nan)
                for a,b in inner:
                    tr=np.isin(ig,a);vv=np.isin(ig,b);model=m.ContextCalibration(C).fit(ip[tr],iy[tr],ig[tr],ik[tr]);q[vv]=model.predict(ip[vv],ik[vv]);refits+=1
                error=float(abs(q-d['context:'+str(C)]).max());assert error<1e-12;largest=max(largest,error)
            for row in rec['source_candidates']:
                c=row;q=ip if c['kind']=='baseline' else d[c['kind']+':'+str(c['parameter'])];p=c['blend']*q+(1-c['blend'])*ip;assert abs(objective(p)-c['auc'])<1e-12
        assert rec['choices']['overall_selected']==max(rec['source_candidates'],key=lambda v:v['auc']);assert rec['choices']['context_only']==max([v for v in rec['source_candidates'] if v['kind']=='context' and v['blend']==1.],key=lambda v:v['auc'])
        for name,c in rec['choices'].items():
            q=prior[va]
            if c['kind']=='context':
                model=joblib.load(out/f'fold{fold}_C{c["parameter"]}.joblib');assert set(model.source_subjects)==set(aa);assert np.allclose(model.scaler.mean_,m.features(ip,ik).mean(0));q=model.predict(q,keys[va]);anonymous=np.array(['u'+str(j) for j in np.unique(keys[va],return_inverse=True)[1]]);assert np.allclose(q,model.predict(prior[va],anonymous),atol=1e-12)
            elif c['kind']!='baseline':q=m.transform(q,keys[va],c['kind'],c['parameter'])
            expected=c['blend']*q+(1-c['blend'])*prior[va]
            with np.load(out/(name+'_oof.npz')) as d:assert np.array_equal(d['labels'],y) and np.array_equal(d['subjects'],g);error=float(abs(expected-d['probability'][va]).max());assert error<1e-12;largest=max(largest,error)
        print('CALIBRATION V2 AUDITED FOLD',fold,flush=True)
    assert np.all(count==1);m.r.r.base.save(out/'verification.json',dict(checks_passed=True,source_calibration_refits=refits,max_prediction_delta=largest,source_indices_and_choices_checked=True,outer_predictions_reloaded=True,query_diagnosis_not_required=True,holdout_loaded=False,public_test_loaded=False,not_fresh_validation=True))
    rows=[]
    for name in ['overall_selected','context_only','fixed_posterior','baseline']:
        a=summary[name]['all_windows'];rows.append(dict(policy=name,pooled_auc=a['pooled']['auc'],balanced_auc=a['balanced_50_50']['auc'],DEP_auc=a['cohorts']['DEP']['auc']))
    ci=json.loads((out/'bootstrap.json').read_text())['overall_selected']['balanced_auc'];text='当前最高融合模型的组内校准：已完成并复核\n\n|策略|合并AUC|50/50加权合并AUC|DEP AUC|\n|---|---:|---:|---:|\n'+'\n'.join('|'+row['policy']+'|'+f"{row['pooled_auc']:.3%}|{row['balanced_auc']:.3%}|{row['DEP_auc']:.3%}|" for row in rows)+f'\n\n预先固定主策略overall_selected，相对原最佳加权AUC的整人重采样增量95%区间：{ci}（小数单位）。CI跨零时不认定稳定提升。配置只用源内部预测选择，外层被试不参与任何拟合；源内部两级模型训练统计存在依赖，内层指标不当作独立验证成绩。60名开发被试已多次使用。官方成绩未知，封存10人和官方测试信号没有读取，未代交比赛。\n';Path('/workspace/output/EEG_leaderboard_calibration_v2_verified.md').write_text(text);print(text,flush=True)
if __name__=='__main__':main()
