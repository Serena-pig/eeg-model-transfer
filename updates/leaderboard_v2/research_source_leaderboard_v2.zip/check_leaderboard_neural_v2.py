"""B-spline correctness and exact source-training resume; no benchmark/AUC claim."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from tempfile import TemporaryDirectory
import json,hashlib,numpy as np,torch
from threadpoolctl import threadpool_limits
import run_leaderboard_neural_v2 as r
m=r.models

def main():
    limits=threadpool_limits(limits=1);torch.set_num_threads(1);torch.use_deterministic_algorithms(True);layer=m.SplineKAN(3,2).double();x=torch.tensor([[-1.2,.2,1.1],[.3,-.4,2.2]],dtype=torch.double,requires_grad=True);basis=layer.basis(x);err=float(abs(basis.sum(-1)-1).max());assert err<1e-12 and torch.all(basis>=0);assert torch.autograd.gradcheck(layer,(x,),eps=1e-6,atol=1e-4)
    bank,y,g,keys,split,meta=r.load_data();hc=[s for s in split['development'] if s.startswith('HC')][:5];dep=[s for s in split['development'] if s.startswith('DEP')][:5];it=np.flatnonzero(np.isin(g,hc+dep));largest=0.
    with TemporaryDirectory() as tmp:
        for name in m.CONFIGS:
            a=m.train(bank,y,g,it,name,42,Path(tmp)/name/'full',2);m.train(bank,y,g,it,name,42,Path(tmp)/name/'resume',1);b=m.train(bank,y,g,it,name,42,Path(tmp)/name/'resume',2);error=max(float(abs(a.state_dict()[k]-v).max()) for k,v in b.state_dict().items());assert error==0.;largest=max(largest,error);p=m.predict(a,bank[it[:8]]);assert p.shape==(8,) and np.isfinite(p).all();print('REAL SOURCE MODEL RESUME CHECK',name,error,flush=True)
    result=dict(passed=True,real_source_people=hc+dep,real_source_trials=len(it),spline_partition_unity_error=err,spline_input_gradient_check=True,exact_optimizer_RNG_resume_max_delta=largest,matched_architectures=list(m.CONFIGS),models_sha256=hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest(),runner_sha256=hashlib.sha256(Path(r.__file__).read_bytes()).hexdigest(),holdout_loaded=False,public_test_loaded=False,no_AUC_claimed=True);(r.ROOT/'leaderboard_neural_v2_interface_check.json').write_text(json.dumps(result,indent=2));print('LEADERBOARD V2 INTERFACE PASSED',flush=True)
if __name__=='__main__':main()
