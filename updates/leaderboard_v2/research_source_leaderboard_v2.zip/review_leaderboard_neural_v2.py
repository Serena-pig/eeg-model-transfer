"""Audit source training and reconstruct label-free adapted predictions per selected8 panel."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import inspect,json
import numpy as np,torch
from threadpoolctl import threadpool_limits
import run_leaderboard_neural_v2 as runner
import auc_cluster_bootstrap as boot
m=runner.models;r=runner.r;ROOT=r.ROOT

def predict_selected(model,x,keys,iv,tta):
    assert tta=='none'
    return m.predict(model,x[iv])

def reload_mean(out,fold,label,c,x,keys,it,iv):
    result=[]
    for offset in m.SEEDS:
        p=out/f'checkpoints/fold{fold}_{c["config"]}_{label}/seed{offset}/epoch_{c["epoch"]}.pt';ck=torch.load(p,map_location='cpu',weights_only=False);assert np.array_equal(ck['training_indices'],it);model=m.Model(c['config']);model.load_state_dict(ck['state_dict']);original={key:v.clone() for key,v in model.state_dict().items()};result.append(predict_selected(model,x,keys,iv,c['tta']));assert all(torch.equal(original[key],v) for key,v in model.state_dict().items())
    return np.mean(result,axis=0)

def choose(rows):
    return {'overall_selected':max(rows,key=lambda v:v['auc']),'pure_selected':max([v for v in rows if v['epoch']>0 and v['blend']==1.],key=lambda v:v['auc']),'pure_early':max([v for v in rows if v['epoch']==5 and v['blend']==1.],key=lambda v:v['auc'])}

def main():
    limits=threadpool_limits(limits=1);torch.set_num_threads(1);torch.use_deterministic_algorithms(True)
    out=Path((ROOT/'CURRENT_LEADERBOARD_NEURAL_V2.txt').read_text().strip());plan=json.loads((out/'plan.json').read_text());summary=json.loads((out/'summary.json').read_text())
    assert plan['code_sha256']==runner.data.digest(Path(runner.__file__)) and plan['models_sha256']==runner.data.digest(ROOT/'leaderboard_neural_v2.py');assert plan['configurations']==m.CONFIGS
    assert json.loads((ROOT/'leaderboard_neural_v2_interface_check.json').read_text())['passed']
    x,y,g,keys,split,meta=runner.load_data();assert meta==plan['projection_manifest'];anchor,rep=r.protocol.outer_reference(y,g);counts=np.zeros(len(y),int);maxdelta=0.;checked=0
    for fold,(aa,bb) in enumerate(r.r.base.folds(split['development']),1):
        tr=np.flatnonzero(np.isin(g,aa));va=np.flatnonzero(np.isin(g,bb));counts[va]+=1;rec=summary['folds'][fold-1];assert rec['training_subjects']==aa.tolist() and rec['validation_subjects']==bb.tolist()
        fits={f'inner{j}':(np.flatnonzero(np.isin(g,a)),np.flatnonzero(np.isin(g,b))) for j,(a,b) in enumerate(r.r.base.folds(aa,n=3))};fits['outer']=(tr,va)
        for folder in (out/'checkpoints').glob(f'fold{fold}_*'):
            name='_'.join(folder.name.split('_')[1:-1]);label=folder.name.split('_')[-1];it,iv=fits[label];assert name in m.CONFIGS and set(g[it]).isdisjoint(g[iv]) and set(g[it]).isdisjoint(split['holdout'])
            if label!='outer':assert set(g[it]).isdisjoint(bb)
            sequence,de=x[it];w=np.where(np.char.startswith(g[it],'DEP'),2.,1.);w/=w.sum();mean=(sequence.mean(1)*w[:,None,None]).sum(0);std=np.sqrt((((sequence-mean)**2).mean(1)*w[:,None,None]).sum(0)).clip(.05);dmean=(de*w[:,None]).sum(0)
            expected={'smean':mean[None,None],'sstd':std[None,None],'dmean':dmean,'dstd':np.sqrt(((de-dmean)**2*w[:,None]).sum(0)).clip(1e-6)}
            for offset in m.SEEDS:
                for path in (folder/f'seed{offset}').glob('epoch_*.pt'):
                    ck=torch.load(path,map_location='cpu',weights_only=False);assert ck['name']==name and ck['config']==m.CONFIGS[name] and np.array_equal(ck['training_indices'],it) and set(ck['training_subjects'])==set(g[it]);e=ck['epoch'];assert len(ck['loss'])==e and bool(ck['optimizer']['state'])==(e>0)
                    assert ck['seed']==42+fold*100+(99 if label=='outer' else int(label[-1]))+offset;assert ck['torch_rng'].dtype==torch.uint8 and ck['numpy_generator']['bit_generator']=='PCG64'
                    ds=ck['state_dict'];assert all(torch.isfinite(v).all() for v in ds.values()) and np.isfinite(ck['loss']).all()
                    for key,value in expected.items():assert np.allclose(ds[key].numpy(),value,atol=1e-6)
                    checked+=1
        with np.load(out/f'fold{fold}_inner.npz') as cache:
            iy=cache['labels'];ig=cache['subjects'];ik=r.r.group_ids(ig);assert set(ig)==set(aa) and np.array_equal(cache['baseline_probability'],r.protocol.inner_reference(fold,iy,ig))
            for c in rec['inner_scores']:
                p=cache['baseline_probability'] if c['epoch']<0 else c['blend']*r.postprocess(cache[c['config']+'__'+str(c['epoch'])+'__'+c['tta']],ik,c['post'])+(1-c['blend'])*cache['baseline_probability']
                assert abs(runner.common.inner_objective(iy,p,ig,ik)-c['auc'])<1e-12
            choices=choose(rec['inner_scores']);assert choices==rec['choices'];seen=set()
            for c in choices.values():
                if c['epoch']<0 or (c['config'],c['epoch'],c['tta']) in seen:continue
                seen.add((c['config'],c['epoch'],c['tta']));parts=[]
                for j in range(3):
                    it,iv=fits[f'inner{j}'];parts.append(reload_mean(out,fold,f'inner{j}',c,x,keys,it,iv))
                err=float(np.max(abs(np.concatenate(parts)-cache[c['config']+'__'+str(c['epoch'])+'__'+c['tta']])));assert err<1e-7;maxdelta=max(maxdelta,err)
        for policy,c in choices.items():
            p=anchor[va]
            if c['epoch']>=0:p=c['blend']*r.postprocess(reload_mean(out,fold,'outer',c,x,keys,tr,va),keys[va],c['post'])+(1-c['blend'])*p
            with np.load(out/(policy+'_oof.npz')) as saved:assert np.array_equal(saved['labels'],y) and np.array_equal(saved['subjects'],g);err=float(np.max(abs(saved['probability'][va]-p)));assert err<1e-7;maxdelta=max(maxdelta,err)
        print('AUDITED LEADERBOARD NEURAL V2 FOLD',fold,flush=True)
    assert np.all(counts==1)
    with np.load(ROOT/'runs/generalization_fusion_20261024_105057_981652/person_bagged_oof.npz') as d:previous=d['probability']
    intervals={}
    for name in choices:
        with np.load(out/(name+'_oof.npz')) as d:intervals[name]=boot.compare(y,d['probability'],previous,g,rep,keys)
    runner.common.atomic_json(out/'vs_previous_best.json',intervals)
    runner.common.atomic_json(out/'verification.json',dict(checks_passed=True,checkpoint_count=checked,review_code_sha256=runner.data.digest(Path(__file__)),source_only_scalers_optimizer_indices_checked=True,source_DE_cache_provenance_verified=True,source_inner_choices_reproduced=True,selected_inner_and_outer_predictions_reloaded=True,max_prediction_delta=maxdelta,no_query_video_or_labels_required=True,two_fixed_seeds_averaged=True,holdout_loaded=False,public_test_loaded=False,submissions=0,not_fresh_validation=True));print('LEADERBOARD NEURAL V2 AUDIT PASS',out,flush=True)
if __name__=='__main__':main()
