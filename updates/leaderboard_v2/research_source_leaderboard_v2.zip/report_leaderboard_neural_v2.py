"""Verified frozen CNN + learned temporal/de head study, no encoder redistribution."""
from pathlib import Path
import json,csv,io
import run_leaderboard_neural_v2 as runner
ROOT=runner.ROOT

def main():
    pointer='CURRENT_LEADERBOARD_NEURAL_V2.txt';out=Path((ROOT/pointer).read_text().strip());verify=json.loads((out/'verification.json').read_text());assert verify['checks_passed'];summary=json.loads((out/'summary.json').read_text());rows=[]
    for name in ['overall_selected','pure_selected','pure_early','baseline']:
        s=summary[name];rows.append(dict(policy=name,pooled_auc=s['all_windows']['pooled']['auc'],balanced_50_50_auc=s['all_windows']['balanced_50_50']['auc'],DEP_auc=s['all_windows']['cohorts']['DEP']['auc'],representative_pooled_auc=s['representative8']['pooled']['auc']))
    target=Path('/workspace/output');target.mkdir(exist_ok=True);buffer=io.StringIO();writer=csv.DictWriter(buffer,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows);(target/'EEG_leaderboard_neural_v2_verified_metrics.csv').write_text(buffer.getvalue());p=rows[0];ci=json.loads((out/'vs_previous_best.json').read_text())['overall_selected']['balanced_auc'];table='\n'.join('|'+v['policy']+'|'+f"{v['pooled_auc']:.3%}|{v['balanced_50_50_auc']:.3%}|{v['DEP_auc']:.3%}|" for v in rows)
    text=f'''多分支CNN与Transformer/B样条KAN：复核结果\n\n60名开发被试，五外层/三内层按人验证，主策略为overall_selected。\n\n|方案|合并AUC|50/50加权合并AUC|DEP AUC|\n|---|---:|---:|---:|\n{table}\n\n对固定旧参考80.194%加权AUC的主策略增量{(p['balanced_50_50_auc']-.801942578125)*100:+.3f}个百分点，整人重采样95%区间{ci}；内部85%目标达到：{p['balanced_50_50_auc']>=.85}。CI跨零不认定稳定提升；开发被试多次使用，官方成绩未知。\n\n匹配比较单分支CNN、核3/5/7多分支CNN、多分支CNN＋BiGRU、Transformer＋MLP、Transformer＋三次B样条KAN头。原始特征为10个1秒帧×6频带×30电极的DE及完整10秒DE残差。KAN层是可学习逐输入边函数的B样条加性层，不是将普通MLP改名。所有配置采用相同5HC＋5DEP的80条源训练模拟批次、全体正负排序与被试内排序损失、通道/频带丢弃、余弦学习率及两个固定种子平均。只在源内层选择配置/轮数/后处理/融合。不是对榜首或榜十代码的复现。\n\n真实源数据上的KAN基函数单位分解、有限差分梯度与优化器/RNG精确续训测试通过；五外层训练索引、源内统计及检查点重载均已复核，最大误差{verify['max_prediction_delta']}。\n\n封存10人、官方测试信号未读取，提交0次。本分支不使用外部预训练权重。\n'''
    (target/'EEG_leaderboard_neural_v2_verified.md').write_text(text);(out/'delivery.json').write_text(json.dumps(dict(primary=p,balanced_auc_delta_CI95=ci,target_internal_hit=p['balanced_50_50_auc']>=.85,official_score_unknown=True,holdout_loaded=False,public_test_loaded=False,submissions=0),indent=2));print(text,flush=True)
if __name__=='__main__':main()
