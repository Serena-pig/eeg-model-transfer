"""Independent full outer controls for each architecture, epoch selected only on source-inner data."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from datetime import datetime
from concurrent.futures import ProcessPoolExecutor,as_completed
import multiprocessing,json,hashlib
import numpy as np,torch
from threadpoolctl import threadpool_limits
import run_leaderboard_neural_v2 as runner
import auc_cluster_bootstrap as boot
ROOT=runner.ROOT;m=runner.models

def worker(root,fold,parent):
    limits=threadpool_limits(limits=1);torch.set_num_threads(1);torch.set_num_interop_threads(1) if torch.get_num_interop_threads()!=1 else None;torch.use_deterministic_algorithms(True);out=Path(root);parent=Path(parent)
    if (out/f'fold{fold}_outer.npz').exists():return
    x,y,g,keys,split,meta=runner.load_data();aa,bb=list(runner.r.r.base.folds(split['development']))[fold-1];it=np.flatnonzero(np.isin(g,aa));iv=np.flatnonzero(np.isin(g,bb));assert set(g[it]).isdisjoint(g[iv]);rec=json.loads((parent/f'fold{fold}.json').read_text());choices={name:max([row for row in rec['inner_scores'] if row['config']==name and row['blend']==1.],key=lambda row:row['auc']) for name in m.CONFIGS};pred={}
    for name,c in choices.items():
        ckfolder=out/f'checkpoints/fold{fold}_{name}_outer';p=runner.fit_predictions(x,y,g,keys,it,iv,name,42+fold*100+99,ckfolder,c['epoch']);pred[name]=runner.r.postprocess(p[str(c['epoch'])+'__none'],keys[iv],c['post']);print('ARCHITECTURE CONTROL FIT',fold,name,c['epoch'],flush=True)
    runner.common.atomic_json(out/f'fold{fold}.json',dict(fold=fold,training_subjects=aa.tolist(),validation_subjects=bb.tolist(),choices=choices));np.savez_compressed(out/f'fold{fold}_outer.npz',indices=iv,**pred)

def main():
    limits=threadpool_limits(limits=1);x,y,g,keys,split,meta=runner.load_data();parent=Path((ROOT/'CURRENT_LEADERBOARD_NEURAL_V2.txt').read_text().strip());assert json.loads((parent/'verification.json').read_text())['checks_passed'];out=ROOT/'runs'/('leaderboard_architecture_controls_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'));out.mkdir();(ROOT/'CURRENT_LEADERBOARD_ARCH_CONTROLS.txt').write_text(str(out));runner.common.atomic_json(out/'plan.json',dict(parent=parent.name,architectures=list(m.CONFIGS),two_fixed_seeds=m.SEEDS,selection='Per-architecture pure epoch and postprocessing from parent source-inner scores only; independent outer checkpoints',models_sha256=hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),development_subjects=split['development'],holdout_not_loaded=split['holdout'],public_test_loaded=False,not_fresh_validation=True))
    with ProcessPoolExecutor(2,mp_context=multiprocessing.get_context('spawn')) as pool:
        for f in as_completed([pool.submit(worker,str(out),fold,str(parent)) for fold in range(1,6)]):f.result()
    _,rep=runner.r.protocol.outer_reference(y,g);pred={k:np.full(len(y),np.nan) for k in m.CONFIGS};count=np.zeros(len(y),int);largest=0.;checked=0
    for fold,(aa,bb) in enumerate(runner.r.r.base.folds(split['development']),1):
        it=np.flatnonzero(np.isin(g,aa));iv=np.flatnonzero(np.isin(g,bb));rec=json.loads((out/f'fold{fold}.json').read_text());parentrec=json.loads((parent/f'fold{fold}.json').read_text());count[iv]+=1
        for name,c in rec['choices'].items():
            assert c==max([row for row in parentrec['inner_scores'] if row['config']==name and row['blend']==1.],key=lambda row:row['auc']);parts=[]
            for seed in m.SEEDS:
                ck=torch.load(out/f'checkpoints/fold{fold}_{name}_outer/seed{seed}/epoch_{c["epoch"]}.pt',map_location='cpu',weights_only=False);assert np.array_equal(ck['training_indices'],it) and set(ck['training_subjects'])==set(aa) and set(aa).isdisjoint(split['holdout']);model=m.Model(name);model.load_state_dict(ck['state_dict']);parts.append(m.predict(model,x[iv]));checked+=1
            expected=runner.r.postprocess(np.mean(parts,axis=0),keys[iv],c['post'])
            with np.load(out/f'fold{fold}_outer.npz') as d:assert np.array_equal(d['indices'],iv);error=float(abs(expected-d[name]).max());assert error<1e-7;largest=max(largest,error);pred[name][iv]=d[name]
    assert np.all(count==1);summary={}
    with np.load(ROOT/'runs/reference_bendr_fusion_20261024_175105_067385/person_bagged_oof.npz') as d:prior=d['probability']
    for name,p in pred.items():summary[name]=runner.r.summarize(y,p,g,keys,rep);np.savez_compressed(out/(name+'_oof.npz'),labels=y,subjects=g,group_ids=keys,representative=rep,probability=p)
    runner.common.atomic_json(out/'summary.json',summary);runner.common.atomic_json(out/'bootstrap.json',{k:boot.compare(y,v,prior,g,rep,keys) for k,v in pred.items()});runner.common.atomic_json(out/'architecture_pairwise_CI.json',dict(KAN_vs_MLP=boot.compare(y,pred['transformer_kan'],pred['transformer_mlp'],g,rep,keys),multibranch_vs_single=boot.compare(y,pred['multibranch_cnn'],pred['single_cnn'],g,rep,keys)));runner.common.atomic_json(out/'parameter_counts.json',{name:sum(p.numel() for p in m.Model(name).parameters()) for name in m.CONFIGS});runner.common.atomic_json(out/'verification.json',dict(checks_passed=True,outer_checkpoint_reloads=checked,max_prediction_delta=largest,all_architecture_epochs_chosen_without_outer_people=True,holdout_loaded=False,public_test_loaded=False))
    table='\n'.join('|'+name+'|'+f"{s['all_windows']['pooled']['auc']:.3%}|{s['all_windows']['balanced_50_50']['auc']:.3%}|{s['all_windows']['cohorts']['DEP']['auc']:.3%}|" for name,s in summary.items());text='五种结构的独立外层对照（已复核）\n\n|结构|合并AUC|50/50加权合并AUC|DEP AUC|\n|---|---:|---:|---:|\n'+table+'\n\n这些是各结构单独的输出，不是最终融合分数。数据、优化器和训练损失相同，但网络参数量不同；具体参数量与KAN对MLP、多分支对单分支的配对区间保存在本run下，不将参数量差异归因成某个模块必然有效。每种结构各自只用源内层选择轮数和后处理；两个固定种子平均，不按外层挑种子。60名开发被试已多次使用，官方成绩未知。\n';Path('/workspace/output/EEG_leaderboard_architecture_controls_verified.md').write_text(text);print(text,flush=True)
if __name__=='__main__':main()
