"""Execution-only recovery: isolated fold subprocesses, then unchanged scientific aggregation/audit."""
from pathlib import Path
import json,subprocess,sys,time,hashlib
ROOT=Path(__file__).resolve().parent;out=Path((ROOT/'CURRENT_LEADERBOARD_NEURAL_V2.txt').read_text().strip());plan=json.loads((out/'plan.json').read_text());assert plan['code_sha256']==hashlib.sha256((ROOT/'run_leaderboard_neural_v2.py').read_bytes()).hexdigest();assert plan['models_sha256']==hashlib.sha256((ROOT/'leaderboard_neural_v2.py').read_bytes()).hexdigest();queue=[f for f in range(1,6) if not (out/f'fold{f}_outer.npz').exists()];running=[];last=0.
try:
    while queue or running:
        while queue and len(running)<2:
            fold=queue.pop(0);stream=(ROOT/f'logs/leaderboard_neural_v2_fold{fold}_recovery.log').open('a');p=subprocess.Popen([sys.executable,'-u','leaderboard_neural_v2_worker_entry.py','--out',str(out),'--fold',str(fold)],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT);running.append((p,stream,fold));print('FRESH FOLD PROCESS START',fold,p.pid,flush=True)
        for item in list(running):
            p,stream,fold=item
            if p.poll() is not None:
                stream.close();running.remove(item);assert p.returncode==0,'Real fit failure in fold'+str(fold);print('FRESH FOLD COMPLETE',fold,flush=True)
        if time.monotonic()-last>30:print('RECOVERY PROGRESS',len(list(out.glob('fold*_outer.npz'))),'/5outer',flush=True);last=time.monotonic()
        time.sleep(1)
finally:
    for p,stream,fold in running:
        if p.poll() is None:p.terminate();p.wait()
        stream.close()
(out/'EXECUTION_RECOVERY.json').write_text(json.dumps(dict(reason='Worker return typo after save, and repeated interop-thread setting on reused processes. Fresh one-fold processes preserve scientific code/optimizer/RNG checkpoints.',scientific_code_unchanged=True,model_code_unchanged=True,all_five_folds_complete=True),indent=2))
for command,name in [(['aggregate_leaderboard_neural_v2.py','--out',str(out)],'leaderboard_neural_v2_collection_recovery.log'),(['review_leaderboard_neural_v2.py'],'leaderboard_neural_v2_review.log'),(['report_leaderboard_neural_v2.py'],'leaderboard_neural_v2_report.log')]:
    with (ROOT/'logs'/name).open('a') as stream:subprocess.run([sys.executable,'-u',*command],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,check=True)
print('RECOVERED NEURAL ROUND VERIFIED',flush=True)
