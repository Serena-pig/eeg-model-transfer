"""Run one frozen scientific worker in a fresh process; catch only its post-save return typo."""
import argparse,json,hashlib
from pathlib import Path
import numpy as np
import run_leaderboard_neural_v2 as r

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);ap.add_argument('--fold',type=int,required=True);a=ap.parse_args();plan=json.loads((a.out/'plan.json').read_text());assert plan['code_sha256']==hashlib.sha256(Path(r.__file__).read_bytes()).hexdigest();assert plan['models_sha256']==hashlib.sha256(Path(r.models.__file__).read_bytes()).hexdigest()
    try:r.worker(str(a.out),a.fold)
    except NameError as e:
        tb=e.__traceback__
        while tb.tb_next:tb=tb.tb_next
        assert e.name=='rec' and tb.tb_frame.f_code.co_name=='worker' and Path(tb.tb_frame.f_code.co_filename)==Path(r.__file__)
        rec=json.loads((a.out/f'fold{a.fold}.json').read_text());split=json.loads((r.ROOT/'cache/splits.json').read_text());assert set(rec['training_subjects']).isdisjoint(rec['validation_subjects']) and set(rec['training_subjects']).isdisjoint(split['holdout'])
        with np.load(a.out/f'fold{a.fold}_outer.npz') as d:
            assert len(d['indices'])==len(np.unique(d['indices']))==480
            for name in rec['choices']:assert d[name].shape==(480,) and np.isfinite(d[name]).all() and ((d[name]>=0)&(d[name]<=1)).all()
        (a.out/f'fold{a.fold}_return_recovery.json').write_text(json.dumps(dict(post_save_return_typo_caught=True,complete_predictions_validated=True,no_numerical_model_change=True,scientific_runner_sha256=plan['code_sha256']),indent=2));print('FROZEN SCIENTIFIC WORKER FIT COMPLETE',a.fold,flush=True)
if __name__=='__main__':main()
