"""Fixed source-only constrained fusion of five architecture controls and published-count calibration."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from datetime import datetime
import json,hashlib,numpy as np
from scipy.special import expit
from threadpoolctl import threadpool_limits
import run_leaderboard_calibration_v2 as cal
import fuse_reference_bendr as opt
import auc_cluster_bootstrap as boot
ROOT=cal.ROOT

def main():
    limits=threadpool_limits(limits=1);neural=Path((ROOT/'CURRENT_LEADERBOARD_NEURAL_V2.txt').read_text().strip());controls=Path((ROOT/'CURRENT_LEADERBOARD_ARCH_CONTROLS.txt').read_text().strip());assert all(json.loads((p/'verification.json').read_text())['checks_passed'] for p in [cal.CHAMPION,neural,controls]);_,_,y,g,keys,split=cal.r.load_data()
    with np.load(cal.CHAMPION/'person_bagged_oof.npz') as d:anchor=d['probability'];rep=d['representative'];assert np.array_equal(g,d['subjects'])
    out=ROOT/'runs'/('leaderboard_v2_fusion_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'));out.mkdir();(ROOT/'CURRENT_LEADERBOARD_V2_FUSION.txt').write_text(str(out));plan=dict(primary='person_bagged',source=cal.CHAMPION.name,neural=neural.name,controls=controls.name,coefficient_max=.5,coefficient_sum_max=.75,bags=12,regularizer=.1,source_only=True,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),holdout_not_loaded=split['holdout'],public_test_loaded=False,not_fresh_validation=True);cal.r.r.base.save(out/'plan.json',plan);pred={k:np.full(len(y),np.nan) for k in ['person_bagged','pairwise']};largest=0.;gapmax=0.;records=[]
    for fold,(aa,bb) in enumerate(cal.r.r.base.folds(split['development']),1):
        iy,ig,ip=cal.source(fold);ik=cal.r.r.group_ids(ig);assert set(ig)==set(aa) and set(ig).isdisjoint(bb) and set(ig).isdisjoint(split['holdout']);va=np.isin(g,bb);rec=json.loads((controls/f'fold{fold}.json').read_text());columns=[];outs=[];names=[]
        with np.load(neural/f'fold{fold}_inner.npz') as cache:
            assert np.array_equal(cache['labels'],iy) and np.array_equal(cache['subjects'],ig)
            for name,c in rec['choices'].items():
                columns.append(cal.r.postprocess(cache[name+'__'+str(c['epoch'])+'__none'],ik,c['post']));names.append(name)
                with np.load(controls/(name+'_oof.npz')) as d:assert np.array_equal(g,d['subjects']);outs.append(d['probability'][va])
        columns.append(cal.transform(ip,ik,'posterior',1.));outs.append(cal.transform(anchor[va],keys[va],'posterior',1.));names.append('fixed4_posterior_T1');fun,ids=opt.problem(iy,ig,ip,columns);rng=np.random.default_rng(20261026+fold);hc=np.flatnonzero(np.char.startswith(ids,'HC'));dep=np.flatnonzero(np.char.startswith(ids,'DEP'));counts=[np.ones(len(ids))]
        for j in range(12):
            cc=np.zeros(len(ids))
            for ix in [hc,dep]:cc+=np.bincount(rng.choice(ix,len(ix),replace=True),minlength=len(ids))
            counts.append(cc)
        fits=[opt.solve(fun,c,len(columns)) for c in counts];coeff=dict(pairwise=np.array(fits[0]['coeff']),person_bagged=np.mean([v['coeff'] for v in fits[1:]],axis=0));z=opt.stack.score(anchor[va]);delta=np.column_stack([opt.stack.score(p)-z for p in outs])
        for policy,c in coeff.items():pred[policy][va]=expit(z+delta@c)
        # Independent recomputation from saved coefficients; verify optimizer objective/KKT bounds.
        for fit,cnt in zip(fits,counts):
            c=np.array(fit['coeff']);assert c.min()>-1e-7 and c.max()<=.500001 and c.sum()<=.750001;value,grad=fun(c,cnt);assert abs(value-fit['objective'])<1e-12;assert fit['frank_wolfe_gap']<2e-5;gapmax=max(gapmax,fit['frank_wolfe_gap'])
        record=dict(fold=fold,training_subjects=aa.tolist(),validation_subjects=bb.tolist(),component_names=names,fits=fits,coefficients={k:v.tolist() for k,v in coeff.items()});records.append(record);cal.r.r.base.save(out/f'fold{fold}.json',record);np.savez_compressed(out/f'fold{fold}_source.npz',labels=iy,subjects=ig,prior=ip,columns=np.array(columns));print('NEW FUSION FOLD',fold,record['coefficients'],flush=True)
    summary=dict(folds=records);baseline_cal=cal.transform(anchor,keys,'posterior',1.)
    for name,p in {**pred,'baseline':anchor,'fixed4_only':baseline_cal}.items():summary[name]=cal.r.summarize(y,p,g,keys,rep);np.savez_compressed(out/(name+'_oof.npz'),labels=y,subjects=g,group_ids=keys,representative=rep,probability=p)
    intervals={name:dict(vs_previous=boot.compare(y,p,anchor,g,rep,keys),vs_fixed4=boot.compare(y,p,baseline_cal,g,rep,keys)) for name,p in pred.items()};cal.r.r.base.save(out/'summary.json',summary);cal.r.r.base.save(out/'bootstrap.json',intervals)
    # Reload stored fold decisions and reconstruct every outer probability a second time.
    count=np.zeros(len(y),int)
    for fold,(aa,bb) in enumerate(cal.r.r.base.folds(split['development']),1):
        rec=json.loads((out/f'fold{fold}.json').read_text());va=np.isin(g,bb);count[va]+=1;outs=[]
        for name in rec['component_names'][:-1]:
            with np.load(controls/(name+'_oof.npz')) as d:outs.append(d['probability'][va])
        outs.append(cal.transform(anchor[va],keys[va],'posterior',1.));z=opt.stack.score(anchor[va]);delta=np.column_stack([opt.stack.score(p)-z for p in outs])
        for name,c in rec['coefficients'].items():
            with np.load(out/(name+'_oof.npz')) as d:error=float(abs(expit(z+delta@np.array(c))-d['probability'][va]).max());assert error<1e-12;largest=max(largest,error)
    assert np.all(count==1);cal.r.r.base.save(out/'verification.json',dict(checks_passed=True,all_outer_predictions_reloaded=True,source_only_weights_and_architecture_choices=True,max_prediction_delta=largest,max_convex_optimality_gap=gapmax,holdout_loaded=False,public_test_loaded=False,submissions_performed=False))
    table='\n'.join('|'+name+'|'+f"{s['all_windows']['pooled']['auc']:.3%}|{s['all_windows']['balanced_50_50']['auc']:.3%}|{s['all_windows']['cohorts']['DEP']['auc']:.3%}|" for name,s in summary.items() if name!='folds');ci=intervals['person_bagged']['vs_previous']['balanced_auc'];text='榜单补充方法最终融合（已复核）\n\n|方案|合并AUC|50/50加权合并AUC|DEP AUC|\n|---|---:|---:|---:|\n'+table+f'\n\n主策略person_bagged，对旧最佳的加权AUC增量整人重采样95%区间：{ci}。同一60人反复开发，区间未校正长期多重选择，不能当作官方独立验证。源OOF同时用于选配置和拟合约束融合，源拟合指标会乐观；外层被试不参与拟合。未读取封存10人或官方测试信号，未代交比赛，旧GitHub模型包保持原版本。\n';Path('/workspace/output/EEG_leaderboard_v2_fusion_verified.md').write_text(text);print(text,flush=True)
if __name__=='__main__':main()
