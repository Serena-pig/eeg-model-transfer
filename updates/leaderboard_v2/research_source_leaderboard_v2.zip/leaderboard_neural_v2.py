"""Matched source-only multi-branch CNN and Transformer/B-spline KAN controls.
Independent implementations inspired by method names; not leaderboard code replication.
"""
from pathlib import Path
import random
import numpy as np,torch
from torch import nn
from torch.nn import functional as F
from scipy.special import expit
CONFIGS={'single_cnn':{},'multibranch_cnn':{},'multibranch_bigru':{},'transformer_mlp':{},'transformer_kan':{}}
EPOCHS=[5,15,30];SEEDS=[0,173]
class Bank:
    def __init__(self,sequence,de):self.sequence=sequence;self.de=de
    def __getitem__(self,ix):return self.sequence[ix],self.de[ix]
class SplineKAN(nn.Module):
    def __init__(self,incoming,outgoing,grid_size=8,degree=3):
        super().__init__();self.degree=degree;self.register_buffer('grid',torch.arange(-degree,grid_size+degree+1,dtype=torch.float32)*(6/grid_size)-3);self.base=nn.Linear(incoming,outgoing,bias=False);self.spline=nn.Parameter(torch.randn(outgoing,incoming,grid_size+degree)*.02)
    def basis(self,x):
        x=x.clamp(-2.9999,2.9999).unsqueeze(-1);g=self.grid;basis=((x>=g[:-1])&(x<g[1:])).to(x.dtype)
        for k in range(1,self.degree+1):basis=(x-g[:-k-1])/(g[k:-1]-g[:-k-1])*basis[...,:-1]+(g[k+1:]-x)/(g[k+1:]-g[1:-k])*basis[...,1:]
        return basis
    def forward(self,x):return self.base(F.silu(x))+F.linear(self.basis(x).flatten(1),self.spline.flatten(1))
class Model(nn.Module):
    def __init__(self,name):
        super().__init__();self.name=name;self.config=CONFIGS[name]
        for k,d in [('smean',(1,1,6,30)),('sstd',(1,1,6,30)),('dmean',(180,)),('dstd',(180,))]:self.register_buffer(k,torch.ones(d) if k.endswith('std') else torch.zeros(d))
        if name.startswith('transformer'):
            self.project=nn.Linear(180,48);self.position=nn.Parameter(torch.zeros(1,10,48));layer=nn.TransformerEncoderLayer(48,4,96,.35,batch_first=True,norm_first=True);self.transformer=nn.TransformerEncoder(layer,2,enable_nested_tensor=False)
        else:
            kernels=[3] if name=='single_cnn' else [3,5,7];width=12 if len(kernels)==1 else 8;self.convolutions=nn.ModuleList([nn.Sequential(nn.Conv1d(6,width,k,padding=k//2),nn.ELU(),nn.Dropout(.3)) for k in kernels]);self.project=nn.Sequential(nn.Linear(30*width*len(kernels),48),nn.LayerNorm(48),nn.ELU(),nn.Dropout(.4))
            if name=='multibranch_bigru':self.gru=nn.GRU(48,24,batch_first=True,bidirectional=True)
        self.attention=nn.Linear(48,1);self.dropout=nn.Dropout(.4)
        if name=='transformer_kan':self.head=nn.Sequential(nn.LayerNorm(48),SplineKAN(48,16),nn.LayerNorm(16),SplineKAN(16,1));nn.init.zeros_(self.head[-1].base.weight);nn.init.zeros_(self.head[-1].spline)
        else:self.head=nn.Sequential(nn.Linear(48,16),nn.ELU(),nn.Linear(16,1));nn.init.zeros_(self.head[-1].weight);nn.init.zeros_(self.head[-1].bias)
        self.skip=nn.Linear(180,1);nn.init.zeros_(self.skip.weight);nn.init.zeros_(self.skip.bias)
    def forward(self,sequence,de):
        x=(sequence-self.smean)/self.sstd;b,t,f,c=x.shape
        if self.name.startswith('transformer'):z=self.transformer(self.project(x.reshape(b,t,180))+self.position)
        else:
            x=x.permute(0,3,2,1).reshape(b*c,f,t);z=torch.cat([conv(x) for conv in self.convolutions],dim=1);z=self.project(z.reshape(b,c,-1,t).permute(0,3,1,2).flatten(2))
            if self.name=='multibranch_bigru':z,_=self.gru(z)
        pooled=(z*self.attention(z).softmax(1)).sum(1);return (self.head(self.dropout(pooled))+self.skip((de-self.dmean)/self.dstd)).squeeze(-1)
def predict(model,data):
    seq,de=data;model.eval();result=[]
    with torch.no_grad():
        for start in range(0,len(de),80):result.append(model(torch.tensor(seq[start:start+80],dtype=torch.float32),torch.tensor(de[start:start+80],dtype=torch.float32)).numpy())
    return expit(np.concatenate(result).astype(float))
def train(x,y,g,it,name,seed,folder,maximum=30):
    random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);model=Model(name);seq,de=x[it];people=g[it];ids=np.unique(people);hc=ids[~np.char.startswith(ids,'DEP')];dep=ids[np.char.startswith(ids,'DEP')];assert len(hc)>=5 and len(dep)>=5;panels={s:np.flatnonzero(people==s).reshape(8,5).T for s in ids};rng=np.random.default_rng(seed);w=np.where(np.char.startswith(people,'DEP'),2.,1.);w/=w.sum();sm=(seq.mean(1)*w[:,None,None]).sum(0);ss=np.sqrt((((seq-sm)**2).mean(1)*w[:,None,None]).sum(0)).clip(.05);dm=(de*w[:,None]).sum(0);ds=np.sqrt(((de-dm)**2*w[:,None]).sum(0)).clip(1e-6)
    with torch.no_grad():
        for key,value in [('smean',sm[None,None]),('sstd',ss[None,None]),('dmean',dm),('dstd',ds)]:getattr(model,key).copy_(torch.tensor(value,dtype=torch.float32))
    opt=torch.optim.AdamW(model.parameters(),lr=.0007,weight_decay=.05);available={int(p.stem.split('_')[-1]):p for p in folder.glob('epoch_*.pt')};start=0;losses=[]
    if available:
        ck=torch.load(available[max(available)],map_location='cpu',weights_only=False);assert ck['name']==name and ck['seed']==seed and np.array_equal(ck['training_indices'],it);model.load_state_dict(ck['state_dict']);opt.load_state_dict(ck['optimizer']);rng.bit_generator.state=ck['numpy_generator'];torch.set_rng_state(ck['torch_rng']);random.setstate(ck['python_rng']);start=ck['epoch'];losses=ck['loss']
    sequence=torch.tensor(seq,dtype=torch.float32);dd=torch.tensor(de,dtype=torch.float32);labels=torch.tensor(y[it],dtype=torch.float32)
    for epoch in range(start+1,maximum+1):
        model.train();total=0.
        for group in opt.param_groups:group['lr']=.0007*(.1+.9*.5*(1+np.cos(np.pi*(epoch-1)/29)))
        steps=int(np.ceil(len(it)/80))
        for step in range(steps):
            selected=np.r_[rng.choice(hc,5,replace=False),rng.choice(dep,5,replace=False)];ix=np.concatenate([panels[s][rng.integers(5)] for s in selected]);xx=sequence[ix].clone();yy=labels[ix];assert torch.all(yy.reshape(10,8).sum(1)==4)
            mask=((torch.rand(10,1,1,30)>.1)&(torch.rand(10,1,6,1)>.1)).float().repeat_interleave(8,0);xx=xx*mask+.02*torch.randn_like(xx);opt.zero_grad(set_to_none=True);score=model(xx,dd[ix]);pos=score[yy==1];neg=score[yy==0];local=[]
            for j in range(10):
                s=score[j*8:(j+1)*8];v=yy[j*8:(j+1)*8];local.append(F.softplus(-(s[v==1,None]-s[None,v==0])).mean())
            loss=.5*F.binary_cross_entropy_with_logits(score,yy)+.5*F.softplus(-(pos[:,None]-neg[None,:])).mean()+.2*torch.stack(local).mean();assert torch.isfinite(loss);loss.backward();nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step();total+=float(loss.detach())
        losses.append(total/steps)
        if epoch in EPOCHS or epoch==maximum:
            ck=dict(name=name,config=CONFIGS[name],seed=seed,epoch=epoch,loss=losses.copy(),state_dict=model.state_dict(),optimizer=opt.state_dict(),numpy_generator=rng.bit_generator.state,torch_rng=torch.get_rng_state(),python_rng=random.getstate(),training_indices=it,training_subjects=ids.tolist());temp=folder/f'epoch_{epoch}.pt.tmp';torch.save(ck,temp);temp.replace(folder/f'epoch_{epoch}.pt');print('LEADERBOARD V2',name,folder.name,epoch,round(losses[-1],5),flush=True)
    return model
