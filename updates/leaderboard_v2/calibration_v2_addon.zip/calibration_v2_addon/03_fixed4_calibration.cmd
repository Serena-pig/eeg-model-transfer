@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Run 01_install_dependencies.cmd first.
 pause
 exit /b 1
)
set "INPUT=%~1"
if not defined INPUT for /f "delims=" %%F in ('dir /b /a-d /o-d "predictions\submission_best_*.xlsx" 2^>nul ^| findstr /v /i "_fixed4_v2"') do if not defined INPUT set "INPUT=predictions\%%F"
if not defined INPUT (
 echo Generate original predictions with 02_generate_submission.cmd first.
 pause
 exit /b 1
)
echo Original predictions: "%INPUT%"
.venv\Scripts\python.exe apply_fixed_count_calibration.py "%INPUT%"
if errorlevel 1 (
 echo Calibration stopped. Keep the error output for diagnosis.
 pause
 exit /b 1
)
echo New output ends with _fixed4_v2.xlsx. No submission was performed.
pause
