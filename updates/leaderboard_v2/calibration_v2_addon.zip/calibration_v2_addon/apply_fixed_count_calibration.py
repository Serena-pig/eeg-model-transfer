"""Standalone frozen postprocessor: published4-positive/4-neutral composition, no labels.
Does not train weights, modify original prediction files or submit anything.
"""
import argparse,itertools,json,hashlib
from pathlib import Path
import numpy as np
from scipy.special import logit,expit,logsumexp
import openpyxl
ASSIGN=np.zeros((70,8),dtype=float)
for j,subset in enumerate(itertools.combinations(range(8),4)):ASSIGN[j,list(subset)]=1.
HEADERS=['user_id','trial_id','prob. of positive emotion']

def fixed4(p):
    p=np.asarray(p,dtype=float)
    if p.shape!=(8,) or not np.isfinite(p).all() or ((p<0)|(p>1)).any():raise ValueError('Expected8 probabilities')
    energy=ASSIGN@logit(np.clip(p,1e-9,1-1e-9));lp=logsumexp(energy[:,None]+np.where(ASSIGN==1,0.,-np.inf),axis=0);ln=logsumexp(energy[:,None]+np.where(ASSIGN==0,0.,-np.inf),axis=0);q=expit(lp-ln);assert abs(q.sum()-4)<1e-10;return q

def main():
    parser=argparse.ArgumentParser();parser.add_argument('input',type=Path);parser.add_argument('--output',type=Path);args=parser.parse_args();output=args.output or args.input.with_name(args.input.stem+'_fixed4_v2.xlsx')
    if '_fixed4_v2' in args.input.stem:raise ValueError('Input already has the fixed4_v2 marker; do not apply this correction twice')
    if output.resolve()==args.input.resolve() or output.exists():raise ValueError('Use a new output path; original predictions are preserved')
    w=openpyxl.load_workbook(args.input);s=w.active
    if s.max_row!=81 or s.max_column!=3 or [s.cell(1,j).value for j in range(1,4)]!=HEADERS:raise ValueError('Expected official80-row three-column template')
    groups={}
    for row in range(2,82):
        subject=s.cell(row,1).value;trial=s.cell(row,2).value;prob=s.cell(row,3).value
        if not isinstance(subject,str) or not isinstance(trial,int) or trial not in range(1,9):raise ValueError('Invalid user_id ortrial_id')
        groups.setdefault(subject,[]).append((row,trial,float(prob)))
    if len(groups)!=10:raise ValueError('Expected10 people')
    for subject,rows in groups.items():
        if len(rows)!=8 or {r[1] for r in rows}!=set(range(1,9)):raise ValueError('Expected8 distinct trials per person')
        q=fixed4([r[2] for r in rows])
        for (row,trial,prob),value in zip(rows,q):s.cell(row,3,float(value))
    w.save(output);output.with_suffix('.calibration_audit.json').write_text(json.dumps(dict(method='Fixed4 conditional Bernoulli posterior, temperature1, exactly once',input_file=args.input.name,input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),output_sha256=hashlib.sha256(output.read_bytes()).hexdigest(),output_rows=80,trial_order_preserved=True,test_labels_read=False,weights_fitted=False,official_submission_performed=False),indent=2),encoding='utf-8');print('Generated local fixed4-calibrated copy:',output);print('No upload/submission performed. This does not establish an official AUC.')
if __name__=='__main__':main()
