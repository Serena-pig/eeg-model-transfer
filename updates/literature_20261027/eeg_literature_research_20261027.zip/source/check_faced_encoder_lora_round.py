"""Verify actual GRU/input-projection LoRA updates and exact continuation."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import tempfile,numpy as np,torch
from threadpoolctl import threadpool_limits
import run_faced_encoder_lora_round as r

def main():
    limits=threadpool_limits(limits=1);torch.set_num_threads(1);d,split,x,zero,good,baseline,rep,parent,state,manifest=r.load();ids=np.r_[np.unique(d['g'][np.char.startswith(d['g'],'HC')])[:5],np.unique(d['g'][np.char.startswith(d['g'],'DEP')])[:5]];tr=np.flatnonzero(np.isin(d['g'],ids));m=r.models.Model(state);m.train();trainable=[n for n,p in m.named_parameters() if p.requires_grad];assert all(n.endswith(('.A','.B')) for n in trainable) and any('.gru.' in n for n in trainable)
    frozen={n:p.detach().clone() for n,p in m.named_parameters() if not p.requires_grad};params=[p for p in m.parameters() if p.requires_grad];opt=torch.optim.AdamW(params,lr=.001);a=torch.from_numpy(x[tr[:40]].reshape(5,8,10,120));loss=m(a).square().mean();loss.backward();assert any(float(p.grad.abs().sum())>0 for n,p in m.named_parameters() if '.gru.' in n and n.endswith('.B'));opt.step();error=max(float(abs(p-frozen[n]).max()) for n,p in m.named_parameters() if n in frozen);assert error==0
    with tempfile.TemporaryDirectory(prefix='encoder_lora_resume_') as tmp:
        one=Path(tmp)/'continuous';two=Path(tmp)/'resume';r.models.train(x,d['y'],d['g'],good,tr,state,919,one,15);r.models.train(x,d['y'],d['g'],good,tr,state,919,two,5);r.models.train(x,d['y'],d['g'],good,tr,state,919,two,15);a=torch.load(one/'epoch_15.pt',weights_only=False);b=torch.load(two/'epoch_15.pt',weights_only=False);delta=max(float(abs(a['model'][k]-b['model'][k]).max()) for k in a['model']);assert delta==0
    r.r.save(r.r.ROOT/'FACED_ENCODER_LORA_UNIT_VERIFICATION.json',dict(checks_passed=True,genuine_gru_lora_gradients=True,frozen_base_max_update=error,resume_model_max_delta=delta,trainable_parameter_names=trainable,source_only=True,official_test_loaded=False));print('ENCODER LORA CHECK PASSED',error,delta)
if __name__=='__main__':main()
