"""Strict external-task-weight reuse and source-only raw replay to120 logvariance inputs."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from zipfile import ZipFile
import io,json,hashlib,ast
import numpy as np,h5py,torch
from torch import nn
from scipy.signal import butter,sosfiltfilt
import faced_transfer_round as models
ROOT=Path(__file__).resolve().parent
PKG=ROOT/'incoming_v279/EEG_AUC_v279_20261025'
WEIGHT=PKG/'artifacts/external_emotion/faced_v21/emotion_pretrained.pt'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    torch.set_num_threads(1);torch.manual_seed(42);torch.use_deterministic_algorithms(True);split=json.loads((ROOT/'cache/splits.json').read_text());expected=json.loads((ROOT/'feature_ablation/development/manifest.json').read_text())['subjects'];original=json.loads((PKG/'SHA256SUMS.json').read_text());assert sha(WEIGHT)==original[str(WEIGHT.relative_to(PKG))]
    ck=torch.load(WEIGHT,map_location='cpu',weights_only=True);assert ck['competition_labels_used'] is False and ck['subjects']==123 and ck['task']=='FACED positive versus neutral';m=models.EmotionNet();m.load_state_dict(ck['state'],strict=True);m.eval().requires_grad_(False)
    source=PKG/'scripts/emotion_transfer_v21.py';tree=ast.parse(source.read_text());node=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='EmotionNet');namespace=dict(torch=torch,nn=nn);exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),namespace);reference=namespace['EmotionNet']();reference.load_state_dict(ck['state'],strict=True);reference.eval().requires_grad_(False)
    meta=json.loads((PKG/'artifacts/external_emotion/faced_v21/manifest.json').read_text());channels=meta['target_indices'];assert len(channels)==20
    out=ROOT/'foundation_features/faced_sequence_round/development';out.mkdir(parents=True,exist_ok=True);plan=dict(development_subjects=split['development'],holdout_not_loaded=split['holdout'],weight_sha256=sha(WEIGHT),weight_training_subjects_claimed=123,weight_task=ck['task'],competition_labels_in_checkpoint=False,pretraining_raw_not_independently_replayed=True,source_preprocessing='Originalfloat64;10MADclip/CAR30;1s6bandlogvariancefloor1e-12;exactshared20channels; anonymous8panelinputnormalization; raw250Hznoresample.',encoder_frozen=True,models_sha256=sha(ROOT/'faced_transfer_round.py'),script_sha256=sha(__file__),original_architecture_sha256=sha(source),external_manifest=meta,official_test_loaded=False,files={})
    manifest=out/'manifest.json'
    if manifest.exists():
        old=json.loads(manifest.read_text());assert all(old[k]==v for k,v in plan.items() if k!='files');plan['files']=old['files']
    entries={}
    for zp in (ROOT/'raw_training').glob('*.zip'):
        with ZipFile(zp) as z:
            for name in z.namelist():
                if Path(name).stem in split['development'] and name.endswith('.mat'):entries[Path(name).stem]=(zp,name)
    replay=0.
    for s in split['development']:
        dest=out/(s+'.npz')
        if s in plan['files']:assert sha(dest)==plan['files'][s];continue
        zp,name=entries[s]
        with ZipFile(zp) as z:raw=z.read(name)
        assert hashlib.sha256(raw).hexdigest()==expected[s];waves=[]
        with h5py.File(io.BytesIO(raw)) as f:
            for key in ['EEG_data_neu','EEG_data_pos']:
                a=np.asarray(f[key],dtype='float64');a=a.T if a.shape==(30,50000) else a
                for j in range(4):waves.append(a[j*12500:(j+1)*12500].T.reshape(30,5,2500).transpose(1,0,2))
        x=np.concatenate(waves);med=np.median(x,axis=-1,keepdims=True);mad=1.4826*np.median(abs(x-med),axis=-1,keepdims=True);x=np.clip(x,med-10*np.maximum(mad,1e-8),med+10*np.maximum(mad,1e-8));x-=x.mean(1,keepdims=True);seq=[]
        for lo,hi in [(1,4),(4,8),(8,13),(13,20),(20,30),(30,45)]:
            a=sosfiltfilt(butter(4,[lo,hi],fs=250,btype='bandpass',output='sos'),x[:,channels],axis=-1);seq.append(np.log(a.reshape(40,20,10,250).var(-1).clip(1e-12)).transpose(0,2,1))
        seq=np.stack(seq,axis=2).reshape(40,10,120).astype('float32');latent=np.empty((40,192),'float32');logits=np.empty(40,'float32')
        with torch.inference_mode():
            for crop in range(5):
                rr=np.arange(crop,40,5);tensor=torch.from_numpy(seq[rr][None]);a=m(tensor);b=reference(tensor);error=float(abs(a-b).max());assert error<1e-7,(s,crop,error);replay=max(replay,error);latent[rr]=m.latent(tensor).numpy()[0];logits[rr]=a.numpy()[0]
        np.savez_compressed(dest,latent=latent,logits=logits,sequence=seq,raw_sha256=np.array(expected[s]));plan['files'][s]=sha(dest);manifest.write_text(json.dumps(plan,indent=2));print('FACED SOURCE',s,len(plan['files']),'/60',flush=True)
    plan.update(complete=True,compatible_architecture_max_error=replay);manifest.write_text(json.dumps(plan,indent=2));print('FACED FEATURES COMPLETE',out,replay,flush=True)
if __name__=='__main__':main()
