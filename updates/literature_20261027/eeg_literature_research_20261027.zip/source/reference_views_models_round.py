"""Source-fitted v279 reference/individual-band ideas, new60person checkpoints."""
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.metrics.pairwise import rbf_kernel
import v279_transfer_models as groups

def configs():
    result=[]
    for view in ['native','car','robust','median','local']:
        for C in [.3,3.]:result.append(dict(name=f'{view}_spectrum_{C}',keys=[view+'_spec'],kind='svm',C=C,pca=128))
        result.append(dict(name=view+'_individual_de',keys=[view+'_param',view+'_de'],kind='svm',C=1.,pca=96))
        result.append(dict(name=view+'_parameters_lr',keys=[view+'_param'],kind='lr',C=.03,pca=96))
    result.append(dict(name='reference_mkl',keys=['native_spec','robust_spec','local_spec'],kind='mkl',C=3.,pca=96));result.append(dict(name='periodic_mkl',keys=['car_spec','robust_param','local_de'],kind='mkl',C=1.,pca=96));return result

class Model:
    def __init__(self,cfg):self.cfg=cfg
    def fit(self,d,tr):
        self.training_subjects=np.unique(d['g'][tr]).tolist();self.transforms=[];self.tx=[]
        for key in self.cfg['keys']:
            x=d['views'][key][tr];sc=StandardScaler().fit(x);x=sc.transform(x);pca=PCA(n_components=min(self.cfg['pca'],len(tr)-1,x.shape[1]),svd_solver='randomized',random_state=12031).fit(x);x=pca.transform(x);sd=max(np.mean(x*x),.01)**.5;self.transforms.append((sc,pca,sd));self.tx.append(x/sd)
        xx=self.matrix(self.tx);self.model=LogisticRegression(C=self.cfg['C'],solver='liblinear',max_iter=700) if self.cfg['kind']=='lr' else SVC(C=self.cfg['C'],kernel='precomputed' if self.cfg['kind']=='mkl' else 'rbf',cache_size=128);self.model.fit(xx,d['y'][tr],sample_weight=groups.weights(d['g'][tr]));z=groups.group_transform(self.model.decision_function(xx)[:,None],d['keys'][tr]).ravel();self.scale=max(float(z.std()),.1);return self
    def matrix(self,x):return sum(rbf_kernel(a,b,gamma=1/a.shape[1]) for a,b in zip(x,self.tx))/len(x) if self.cfg['kind']=='mkl' else np.concatenate(x,axis=1)
    def predict(self,d,ix):
        x=[pca.transform(sc.transform(d['views'][key][ix]))/sd for key,(sc,pca,sd) in zip(self.cfg['keys'],self.transforms)];z=self.model.decision_function(self.matrix(x))/self.scale;return groups.group_transform(z[:,None],d['keys'][ix]).ravel()
