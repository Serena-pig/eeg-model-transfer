"""Source-only exact pure feature functions from supplied v279 reference-view branch."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from zipfile import ZipFile
import ast,io,json,hashlib
import numpy as np,h5py
from scipy.signal import butter,sosfiltfilt,welch,resample_poly,iirnotch,filtfilt
from scipy.ndimage import gaussian_filter1d
ROOT=Path(__file__).resolve().parent;PKG=ROOT/'incoming_v279/EEG_AUC_v279_20261025'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    split=json.loads((ROOT/'cache/splits.json').read_text());expected=json.loads((ROOT/'feature_ablation/development/manifest.json').read_text())['subjects'];source=PKG/'scripts/input_views_v12.py';sums=json.loads((PKG/'SHA256SUMS.json').read_text());assert sha(source)==sums[str(source.relative_to(PKG))];tree=ast.parse(source.read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['reference_views','spectral_features','transform_group']];nodes.insert(0,next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(a,ast.Name) and a.id=='XY' for a in n.targets)));namespace=dict(np=np,butter=butter,sosfiltfilt=sosfiltfilt,welch=welch,resample_poly=resample_poly,iirnotch=iirnotch,filtfilt=filtfilt,gaussian_filter1d=gaussian_filter1d);exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),namespace)
    out=ROOT/'reference_views_round/development';out.mkdir(parents=True,exist_ok=True);manifest=out/'manifest.json';plan=dict(development_subjects=split['development'],holdout_not_loaded=split['holdout'],source_sha256=sha(source),script_sha256=sha(__file__),views=['native','car','robust','median','local'],source_feature_functions_unchanged=True,features='10MAD, windowDC, five references;50Hznotch,.3-75Hz; Welch1000/750;1HzlogPSD44, eightbandlogpower, robustaperiodic/smoothedpeaks/fiveindividualalphaanchoredbands.',individual_alpha='Estimated only from same8unlabelledtrials; not fitted with emotion labels.',local_reference='Four neighbors on approximate 2D layout, not a calibrated physical surface Laplacian.',official_test_loaded=False,files={})
    if manifest.exists():
        old=json.loads(manifest.read_text());assert all(old[k]==v for k,v in plan.items() if k!='files');plan['files']=old['files']
    entries={}
    for zp in (ROOT/'raw_training').glob('*.zip'):
        with ZipFile(zp) as z:
            for name in z.namelist():
                if name.endswith('.mat') and Path(name).stem in split['development']:entries[Path(name).stem]=(zp,name)
    for person in split['development']:
        dest=out/(person+'.npz')
        if person in plan['files']:assert sha(dest)==plan['files'][person];continue
        zp,name=entries[person]
        with ZipFile(zp) as z:raw=z.read(name)
        assert hashlib.sha256(raw).hexdigest()==expected[person];parts=[]
        with h5py.File(io.BytesIO(raw)) as f:
            for key in ['EEG_data_neu','EEG_data_pos']:
                a=np.asarray(f[key],dtype='float64');a=a.T if a.shape==(30,50000) else a
                for j in range(4):parts.append(a[j*12500:(j+1)*12500].T.reshape(30,5,2500).transpose(1,0,2))
        waves=np.concatenate(parts);features={}
        for crop in range(5):
            rr=np.arange(crop,40,5);values,unused=namespace['transform_group'](waves[rr])
            for name,a in values.items():
                if name not in features:features[name]=np.empty((40,)+a.shape[1:],dtype='float32')
                features[name][rr]=a
        np.savez_compressed(dest,**features);plan['files'][person]=sha(dest);manifest.write_text(json.dumps(plan,indent=2));print('REFERENCE VIEWS',person,len(plan['files']),'/60',flush=True)
    plan['complete']=True;manifest.write_text(json.dumps(plan,indent=2));print('REFERENCE VIEWS COMPLETE',out,flush=True)
if __name__=='__main__':main()
