"""External rest-MDD auxiliary scores, never inferred emotion labels or query diagnosis."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from zipfile import ZipFile
from fractions import Fraction
import ast,io,json,hashlib,types,sys,importlib.util,warnings
import numpy as np,h5py,torch,joblib
from scipy.signal import butter,sosfiltfilt,resample_poly,welch
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
ROOT=Path(__file__).resolve().parent;PKG=ROOT/'incoming_v279/EEG_AUC_v279_20261025'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    torch.set_num_threads(1);torch.use_deterministic_algorithms(True);split=json.loads((ROOT/'cache/splits.json').read_text());expected=json.loads((ROOT/'feature_ablation/development/manifest.json').read_text())['subjects'];sums=json.loads((PKG/'SHA256SUMS.json').read_text());source=PKG/'scripts/clinical_traits_v57.py';weight=PKG/'artifacts/external_depression/nm000114/trait_v57/models.joblib';assert sha(weight)==sums[str(weight.relative_to(PKG))] and sha(source)==sums[str(source.relative_to(PKG))]
    tree=ast.parse(source.read_text());module=types.ModuleType('clinical_traits_v57');module.__dict__.update(dict(np=np,torch=torch,hashlib=hashlib,Fraction=Fraction,butter=butter,sosfiltfilt=sosfiltfilt,resample_poly=resample_poly,welch=welch,StandardScaler=StandardScaler,PCA=PCA,LogisticRegression=LogisticRegression,BANDS=[(1,4),(4,8),(8,13),(13,20),(20,30),(30,45)]));nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in ['TraitClassifier','prepare_epochs','features']];assert len(nodes)==3;exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),module.__dict__);sys.modules['clinical_traits_v57']=module;setattr(sys.modules['__main__'],'TraitClassifier',module.TraitClassifier)
    with warnings.catch_warnings(record=True) as warns:blob=joblib.load(weight)
    assert blob['task']=='External MDD trait auxiliary,notemotion' and all(s.startswith(('sub-HS','sub-MDDS')) for s in blob['source_subjects']);models=blob['models'];assert all(not set(m.training_subjects)&set(split['development']+split['holdout']) for m in models.values())
    path=PKG/'scripts/cbramod_features_v5.py';spec=importlib.util.spec_from_file_location('verified_trait_backbone',path);lib=importlib.util.module_from_spec(spec);spec.loader.exec_module(lib);backbone=lib.FrozenCBraMod(device='cpu',channel_mode='pretrain19');channels=[lib.CHANNELS.index(c) for c in lib.PRETRAIN19]
    out=ROOT/'external_traits_round/development';out.mkdir(parents=True,exist_ok=True);manifest=out/'manifest.json';plan=dict(development_subjects=split['development'],holdout_not_loaded=split['holdout'],external_training_people=blob['source_subjects'],external_task=blob['task'],external_models_sha256=sha(weight),external_source_sha256=sha(source),backbone_sha256=lib.WEIGHT_SHA256,script_sha256=sha(__file__),official_test_loaded=False,actual_query_diagnosis_input=False,interpretation='Two frozen external-MDD decision margins, spectral and public-frozen-backbone. These are auxiliary domains, not emotion labels or clinical diagnoses. External pretraining raw dataset not independently replayed.',library_load_warnings=[str(w.message) for w in warns],files={})
    if manifest.exists():
        old=json.loads(manifest.read_text());assert all(old[k]==v for k,v in plan.items() if k not in ['files','library_load_warnings']);plan['files']=old['files']
    entries={}
    for zp in (ROOT/'raw_training').glob('*.zip'):
        with ZipFile(zp) as z:
            for name in z.namelist():
                if name.endswith('.mat') and Path(name).stem in split['development']:entries[Path(name).stem]=(zp,name)
    for person in split['development']:
        dest=out/(person+'.npz')
        if person in plan['files']:assert sha(dest)==plan['files'][person];continue
        zp,name=entries[person]
        with ZipFile(zp) as z:raw=z.read(name)
        assert hashlib.sha256(raw).hexdigest()==expected[person];parts=[]
        with h5py.File(io.BytesIO(raw)) as f:
            for key in ['EEG_data_neu','EEG_data_pos']:
                x=np.asarray(f[key],dtype='float64');x=x.T if x.shape==(30,50000) else x
                for video in range(4):parts.append(x[video*12500:(video+1)*12500].T.reshape(30,5,2500).transpose(1,0,2))
        x=np.concatenate(parts)[:,channels];scores=np.empty((40,2),'float32')
        for crop in range(5):
            rr=np.arange(crop,40,5);features=module.features(module.prepare_epochs(x[rr],250),backbone);scores[rr]=[float(models[k].predict(features[k][None])[0]) for k in ['spectral','foundation']]
        assert np.isfinite(scores).all();np.savez_compressed(dest,scores=scores);plan['files'][person]=sha(dest);manifest.write_text(json.dumps(plan,indent=2));print('EXTERNAL TRAITS',person,len(plan['files']),'/60',flush=True)
    plan['complete']=True;manifest.write_text(json.dumps(plan,indent=2));print('EXTERNAL TRAITS COMPLETE',out,flush=True)
if __name__=='__main__':main()
