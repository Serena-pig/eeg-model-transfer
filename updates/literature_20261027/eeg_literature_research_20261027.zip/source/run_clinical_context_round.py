"""Matched outer source-only validation against current82.95candidate."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from datetime import datetime
import json,time,numpy as np,joblib
from threadpoolctl import threadpool_limits
import run_v279_transfer as r
from run_faced_transfer_round import baseline_source
import clinical_context_round as models

def main():
    limits=threadpool_limits(limits=1);d,split,_,rep=r.load();y=d['y'];g=d['g'];keys=d['keys'];feature_root=r.ROOT/'external_traits_round/development';manifest=json.loads((feature_root/'manifest.json').read_text());assert manifest['complete'];parts=[]
    for s in split['development']:
        p=feature_root/(s+'.npz');assert r.digest(p)==manifest['files'][s]
        with np.load(p) as a:parts.append(a['scores'])
    d['traits']=np.concatenate(parts).astype(float);assert d['traits'].shape==(2400,2)
    import run_group_auc as raw
    x,_,_,_=raw.load();good=np.exp(np.median(x['absolute_de']-.5*np.log(2*np.pi*np.e),axis=1))>=1e-5;parent=Path((r.ROOT/'CURRENT_V279_QUALITY_TRANSFER.txt').read_text().strip())
    with np.load(parent/'inner_selected_fusion_oof.npz') as a:assert np.array_equal(g,a['subjects']);baseline=a['probability']
    out=r.ROOT/'runs'/('clinical_context_round_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'));out.mkdir();(r.ROOT/'CURRENT_CLINICAL_CONTEXT_ROUND.txt').write_text(str(out));configs=models.configs();r.save(out/'plan.json',dict(primary='inner_selected_fusion',configs=configs,reference=parent.name,clinical_feature_manifest=manifest,script_sha256=r.digest(__file__),models_sha256=r.digest(r.ROOT/'clinical_context_round.py'),source_only=True,actual_query_diagnosis_input=False,holdout_not_loaded=split['holdout'],official_test_loaded=False,submissions_performed=False,not_fresh_validation=True))
    predictions={};counts=np.zeros(len(y),int);records=[];maxreload=0.;permutation=0.;clean={k:v for k,v in d.items() if k not in ['g','y','crop']}
    def fit(a,b,cfg,path):
        nonlocal maxreload,permutation
        tr=a[good[a]];model=models.factory(cfg).fit(d,tr);joblib.dump(model,path,compress=3);p=r.m.posterior(model.predict(clean,b),keys[b]);p[~good[b]]=.5
        loaded=joblib.load(path);assert set(loaded.training_subjects)==set(g[tr]);assert set(g[tr]).isdisjoint(g[b]) and set(g[tr]).isdisjoint(split['holdout']);q=r.m.posterior(loaded.predict(clean,b),keys[b]);q[~good[b]]=.5;maxreload=max(maxreload,float(abs(p-q).max()));perm=np.random.default_rng(27).permutation(len(b));z=r.m.posterior(loaded.predict(clean,b[perm]),keys[b[perm]]);z[~good[b[perm]]]=.5;permutation=max(permutation,float(abs(p[perm]-z).max()));return p
    for fold,(aa,bb) in enumerate(r.cal.r.r.base.folds(split['development']),1):
        start=time.time();tr=np.flatnonzero(np.isin(g,aa));va=np.flatnonzero(np.isin(g,bb));counts[va]+=1;inner=[(np.flatnonzero(np.isin(g,a)),np.flatnonzero(np.isin(g,b))) for a,b in r.cal.r.r.base.folds(aa,n=3)];ii=np.concatenate([b for _,b in inner]);iy,ig,ip=baseline_source(parent,fold);ik=keys[ii];assert np.array_equal(g[ii],ig)
        def objective(p):return float(np.mean([r.boot.evaluation(iy[np.isin(ig,b)],p[np.isin(ig,b)],ig[np.isin(ig,b)],ik[np.isin(ig,b)])['auc'] for _,b in r.cal.r.r.base.folds(aa,n=3)]))
        source={};outs={};rows=[dict(model='baseline',blend=0.,score=objective(ip))]
        for cfg in configs:
            name=cfg['name'];pp=[fit(a,b,cfg,out/f'fold{fold}_inner{j}_{name}.joblib') for j,(a,b) in enumerate(inner)];source[name]=np.concatenate(pp);outs[name]=fit(tr,va,cfg,out/f'fold{fold}_outer_{name}.joblib')
            for blend in [.1,.25,.5,1.]:rows.append(dict(model=name,blend=blend,score=objective((1-blend)*ip+blend*source[name])))
        c=max(rows,key=lambda z:z['score']);pure=max([z for z in rows if z['blend']==1.],key=lambda z:z['score']);outs['pure_selected']=outs[pure['model']];outs['inner_selected_fusion']=baseline[va] if c['model']=='baseline' else (1-c['blend'])*baseline[va]+c['blend']*outs[c['model']]
        for name,p in outs.items():
            if name not in predictions:predictions[name]=np.full(len(y),np.nan)
            predictions[name][va]=p
        rec=dict(fold=fold,training_subjects=aa.tolist(),validation_subjects=bb.tolist(),choice=c,pure_choice=pure,candidates=rows);records.append(rec);r.save(out/f'fold{fold}.json',rec);np.savez_compressed(out/f'fold{fold}_inner.npz',labels=iy,subjects=ig,baseline_probability=ip,**source);np.savez_compressed(out/f'fold{fold}_outer.npz',validation_indices=va,**outs);print('CLINICAL CONTEXT FOLD',fold,c,round(time.time()-start,1),flush=True)
    assert np.all(counts==1);summary=dict(folds=records)
    for name,p in {**predictions,'baseline':baseline}.items():summary[name]=r.cal.r.summarize(y,p,g,keys,rep);np.savez_compressed(out/(name+'_oof.npz'),labels=y,subjects=g,group_ids=keys,representative=rep,probability=p)
    r.save(out/'summary.json',summary);r.save(out/'bootstrap.json',{name:r.boot.compare(y,p,baseline,g,rep,keys) for name,p in predictions.items() if name in ['pure_selected','inner_selected_fusion']});assert maxreload<1e-9 and permutation<1e-8;r.save(out/'verification.json',dict(checks_passed=True,all_inner_outer_models_reloaded=True,max_prediction_delta=maxreload,max_permutation_error=permutation,source_sets_verified=True,source_only=True,actual_query_diagnosis_input=False,holdout_loaded=False,official_test_loaded=False,submissions_performed=False,not_fresh_validation=True));print('CLINICAL CONTEXT COMPLETE',out,flush=True)
if __name__=='__main__':main()
