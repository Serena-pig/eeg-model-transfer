"""Independently recompute source-only choices for clinical/reference experiments."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import json,numpy as np
from threadpoolctl import threadpool_limits
import run_v279_transfer as r

def main():
    limits=threadpool_limits(limits=1);d,split,_,rep=r.load();g=d['g'];keys=d['keys'];results={}
    for family,pointer in [('clinical','CURRENT_CLINICAL_CONTEXT_ROUND.txt'),('reference','CURRENT_REFERENCE_VIEWS_ROUND.txt')]:
        if not (r.ROOT/pointer).exists():continue
        root=Path((r.ROOT/pointer).read_text().strip())
        if not (root/'verification.json').exists():continue
        assert json.loads((root/'verification.json').read_text())['checks_passed'];count=np.zeros(len(g),int);outermax=0.
        for fold,(aa,bb) in enumerate(r.cal.r.r.base.folds(split['development']),1):
            rec=json.loads((root/f'fold{fold}.json').read_text());assert rec['training_subjects']==aa.tolist() and rec['validation_subjects']==bb.tolist();va=np.flatnonzero(np.isin(g,bb));count[va]+=1
            with np.load(root/f'fold{fold}_inner.npz') as a:
                iy=a['labels'];ig=a['subjects'];ik=r.cal.r.r.group_ids(ig);assert set(ig)==set(aa)
                def score(p):return float(np.mean([r.boot.evaluation(iy[np.isin(ig,b)],p[np.isin(ig,b)],ig[np.isin(ig,b)],ik[np.isin(ig,b)])['auc'] for _,b in r.cal.r.r.base.folds(aa,n=3)]))
                for row in rec['candidates']:
                    name=row['model'];p=a['baseline_probability'] if name=='baseline' else (1-row['blend'])*a['baseline_probability']+row['blend']*a[name+('__'+row['post'] if family=='reference' else '')];assert abs(score(p)-row['score'])<1e-14
                assert max(rec['candidates'],key=lambda v:v['score'])==rec['choice']
            with np.load(root/f'fold{fold}_outer.npz') as a:
                assert np.array_equal(a['validation_indices'],va)
                with np.load(root/'inner_selected_fusion_oof.npz') as b:outermax=max(outermax,float(abs(a['inner_selected_fusion']-b['probability'][va]).max()))
        assert np.all(count==1) and outermax==0;results[family]=dict(source_choices_recomputed=True,all_outer_rows_covered_once=True,outer_oof_max_error=outermax);r.save(root/'independent_selection_review.json',dict(checks_passed=True,**results[family]))
    print('NEW CPU ROUND CHOICES VERIFIED',results)
if __name__=='__main__':main()
