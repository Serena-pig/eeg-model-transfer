"""Compatible supplied FACED temporal encoder and real low-rank classifier-head adaptation.

The supplied external checkpoint is positive/neutral, not DAEST's positive/negative
paper head. Only external pretraining reused; no69-person competition model used.
"""
import copy,random
import numpy as np,torch
from torch import nn
from torch.nn import functional as F
import v279_transfer_models as groups

class EmotionNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.project=nn.Sequential(nn.Linear(120,96),nn.LayerNorm(96),nn.GELU(),nn.Dropout(.25))
        self.conv=nn.Sequential(nn.Conv1d(96,96,3,padding=1,groups=8),nn.GELU(),nn.Dropout(.25))
        self.gru=nn.GRU(96,32,batch_first=True,bidirectional=True);self.attention=nn.Linear(64,1)
        self.static=nn.Sequential(nn.Linear(120,64),nn.LayerNorm(64),nn.GELU(),nn.Dropout(.35))
        self.head=nn.Sequential(nn.Linear(192,64),nn.LayerNorm(64),nn.GELU(),nn.Dropout(.4),nn.Linear(64,1))
    def latent(self,x):
        b,k,t,h=x.shape;x=x-x.mean((1,2),keepdim=True);sd=x.mean(2).std(1,unbiased=False).clamp_min(.2);x=(x/sd[:,None,None]).clamp(-10,10).reshape(b*k,t,h)
        z=self.project(x);z=z+self.conv(z.transpose(1,2)).transpose(1,2);z,_=self.gru(z);pooled=(z*self.attention(z).softmax(1)).sum(1)
        return torch.cat([pooled,z.std(1,unbiased=False),self.static(x.mean(1))],1).reshape(b,k,192)
    def forward(self,x):
        latent=self.latent(x);z=self.head(latent.reshape(-1,192)).reshape(x.shape[0],x.shape[1]);return z-z.mean(1,keepdim=True)

class LowRankLinear(nn.Module):
    def __init__(self,base,rank):
        super().__init__();self.base=copy.deepcopy(base).requires_grad_(False);self.A=nn.Parameter(torch.empty(rank,base.in_features));self.B=nn.Parameter(torch.zeros(base.out_features,rank));nn.init.kaiming_uniform_(self.A,a=np.sqrt(5));self.factor=1.
    def forward(self,x):return self.base(x)+self.factor*F.linear(F.linear(x,self.A),self.B)

class Head(nn.Module):
    def __init__(self,state,kind):
        super().__init__();model=EmotionNet();model.load_state_dict(state,strict=True);self.head=copy.deepcopy(model.head)
        if kind.startswith('lora'):
            self.head.requires_grad_(False);rank=int(kind[4:]);self.head[0]=LowRankLinear(self.head[0],rank);self.head[4]=LowRankLinear(self.head[4],rank)
        self.kind=kind
    def forward(self,x):return self.head(x).squeeze(-1)

def train(latent,y,g,keys,good,tr,state,kind,seed,path,maximum=30):
    from pathlib import Path
    path=Path(path);path.mkdir(parents=True,exist_ok=True);random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.set_num_threads(1)
    model=Head(state,kind);opt=torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],lr=.0007,weight_decay=.03);rng=np.random.default_rng(seed)
    people=np.unique(g[tr[good[tr]]]);cohorts=[people[np.char.startswith(people,'HC')],people[np.char.startswith(people,'DEP')]];panels={s:[np.flatnonzero(keys==k) for k in np.unique(keys[g==s])] for s in people};xx=torch.from_numpy(latent.astype('float32'));yy=torch.from_numpy(y.astype('float32'));assign=torch.from_numpy(groups.ASSIGN.astype('float32'));epochs=[5,15,30];start=0
    existing=sorted(path.glob('epoch_*.pt'),key=lambda p:int(p.stem.split('_')[1]))
    if existing:
        ck=torch.load(existing[-1],map_location='cpu',weights_only=False);assert np.array_equal(ck['training_indices'],tr) and ck['kind']==kind and ck['seed']==seed;model.load_state_dict(ck['model']);opt.load_state_dict(ck['optimizer']);rng.bit_generator.state=ck['numpy_rng'];torch.set_rng_state(ck['torch_rng']);random.setstate(ck['python_rng']);start=ck['epoch']
    for epoch in range(start+1,maximum+1):
        model.train();losses=[]
        for step in range(int(np.ceil(len(people)*5/10))):
            chosen=np.r_[rng.choice(cohorts[0],5,replace=False),rng.choice(cohorts[1],5,replace=False)];rr=np.stack([panels[s][rng.integers(5)] for s in chosen]);index=torch.from_numpy(rr);a=xx[index];labels=yy[index];z=model(a+torch.randn_like(a)*.01);z=z-z.mean(1,keepdim=True)
            conditional=(torch.logsumexp(z@assign.T,1)-(z*labels).sum(1)).mean()/4;flat=z.flatten();target=labels.flatten();pair=F.softplus(flat[target==0][None,:]-flat[target==1][:,None]).mean();loss=.5*conditional+.5*F.binary_cross_entropy_with_logits(z,labels*.98+.01)+.2*pair
            opt.zero_grad(set_to_none=True);loss.backward();nn.utils.clip_grad_norm_(model.parameters(),3.);opt.step();losses.append(float(loss.detach()))
        for param in opt.param_groups:param['lr']=.00003+(.0007-.00003)*(.5+.5*np.cos(np.pi*epoch/30))
        if epoch in epochs:
            torch.save(dict(model=model.state_dict(),optimizer=opt.state_dict(),numpy_rng=rng.bit_generator.state,torch_rng=torch.get_rng_state(),python_rng=random.getstate(),epoch=epoch,kind=kind,seed=seed,training_indices=tr,training_subjects=people.tolist(),last_loss=float(np.mean(losses))),path/f'epoch_{epoch}.pt')
    return path

def predict(latent,keys,ix,state,kind,path,epoch):
    model=Head(state,kind);ck=torch.load(path/f'epoch_{epoch}.pt',map_location='cpu',weights_only=False);model.load_state_dict(ck['model']);model.eval();parts=[]
    with torch.inference_mode():
        for j in range(0,len(ix),256):parts.append(model(torch.from_numpy(latent[ix[j:j+256]].astype('float32'))).numpy())
    return groups.posterior(np.concatenate(parts),keys[ix])
