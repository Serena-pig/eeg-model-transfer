"""Meaningful pretrained-head invariance and optimizer/RNG continuation checks."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import tempfile,torch,numpy as np
from threadpoolctl import threadpool_limits
import run_faced_transfer_round as r

def main():
    limits=threadpool_limits(limits=1);torch.set_num_threads(1);d,split,latent,zero,good,baseline,rep,parent,state,manifest=r.load();ids=np.r_[np.unique(d['g'][np.char.startswith(d['g'],'HC')])[:5],np.unique(d['g'][np.char.startswith(d['g'],'DEP')])[:5]];tr=np.flatnonzero(np.isin(d['g'],ids));assert good[tr].all();parts=[]
    base=r.models.EmotionNet();base.load_state_dict(state);base.eval();value=torch.from_numpy(latent[tr][:80].astype('float32'))
    for kind in ['lora4','lora16']:
        model=r.models.Head(state,kind);model.eval()
        with torch.inference_mode():err=float(abs(model(value)-base.head(value).squeeze(-1)).max())
        assert err<1e-6
        model.train();loss=model(value).square().mean();loss.backward();grads=[float(p.grad.abs().sum()) for name,p in model.named_parameters() if name.endswith('.B')];assert any(v>0 for v in grads);assert all(not p.requires_grad for name,p in model.named_parameters() if '.base.' in name)
        parts.append(dict(kind=kind,zero_delta_pretraining_max_error=err,lowrank_gradients_nonzero=True,frozen_base_unchanged=True))
    with tempfile.TemporaryDirectory(prefix='faced_head_resume_') as tmp:
        a=Path(tmp)/'continuous';b=Path(tmp)/'resumed';r.models.train(latent,d['y'],d['g'],d['keys'],good,tr,state,'lora4',771,a,15);r.models.train(latent,d['y'],d['g'],d['keys'],good,tr,state,'lora4',771,b,5);r.models.train(latent,d['y'],d['g'],d['keys'],good,tr,state,'lora4',771,b,15);ca=torch.load(a/'epoch_15.pt',weights_only=False);cb=torch.load(b/'epoch_15.pt',weights_only=False);difference=max(float(abs(ca['model'][k]-cb['model'][k]).max()) for k in ca['model']);assert difference==0
    r.r.save(r.r.ROOT/'FACED_TRANSFER_UNIT_VERIFICATION.json',dict(checks_passed=True,pretraining_preservation=parts,source_only_resume_test=True,optimizer_rng_resume_model_max_delta=difference,scientific_auc_not_tested_by_unit=True,official_test_loaded=False));print('FACED UNIT CHECK PASSED',difference)
if __name__=='__main__':main()
