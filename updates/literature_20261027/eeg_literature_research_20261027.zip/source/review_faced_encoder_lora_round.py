"""Replay source-only choices and selected seed checkpoints, never partial scores."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import json,numpy as np,torch
from threadpoolctl import threadpool_limits
import run_faced_encoder_lora_round as r

def main():
    limits=threadpool_limits(limits=1);torch.set_num_threads(1);out=Path((r.r.ROOT/'CURRENT_FACED_ENCODER_LORA_ROUND.txt').read_text().strip());plan=json.loads((out/'plan.json').read_text());assert plan['script_sha256']==r.r.digest(r.__file__) and plan['models_sha256']==r.r.digest(r.r.ROOT/'faced_encoder_lora_round.py');d,split,latent,zero,good,baseline,rep,parent,state,manifest=r.load();y=d['y'];g=d['g'];keys=d['keys'];maximum=0.;permutation=0.;outer_reloads=0
    for fold,(aa,bb) in enumerate(r.r.cal.r.r.base.folds(split['development']),1):
        tr=np.flatnonzero(np.isin(g,aa));va=np.flatnonzero(np.isin(g,bb));record=json.loads((out/f'fold{fold}.json').read_text());assert record['training_subjects']==aa.tolist() and record['validation_subjects']==bb.tolist();per=np.random.default_rng(fold).permutation(len(va))
        with np.load(out/f'fold{fold}_inner.npz') as a:
            iy=a['labels'];ig=a['subjects'];ik=keys[np.concatenate([np.flatnonzero(np.isin(g,b)) for _,b in r.r.cal.r.r.base.folds(aa,n=3)])]
            def score(p):return float(np.mean([r.r.boot.evaluation(iy[np.isin(ig,b)],p[np.isin(ig,b)],ig[np.isin(ig,b)],ik[np.isin(ig,b)])['auc'] for _,b in r.r.cal.r.r.base.folds(aa,n=3)]))
            rows=[dict(kind='baseline',epoch=0,blend=0.,score=score(a['baseline_probability']))]
            for kind,epochs in [('zeroshot',[0])]+[(k,r.EPOCHS) for k in r.KINDS]:
                for epoch in epochs:
                    p=a[kind+'__'+str(epoch)]
                    for blend in [.1,.25,.5,1.]:rows.append(dict(kind=kind,epoch=epoch,blend=blend,score=score((1-blend)*a['baseline_probability']+blend*p)))
            assert rows==record['candidates'];assert max(rows,key=lambda v:v['score'])==record['choice'];assert set(ig)==set(aa) and set(ig).isdisjoint(bb)
        with np.load(out/f'fold{fold}_outer.npz') as cache:
            values={}
            for kind,c in record['pure_choices'].items():
                if kind=='zeroshot':p=r.r.m.posterior(zero[va],keys[va]);p[~good[va]]=.5
                else:
                    parts=[];permuted=[]
                    for seed in r.SEEDS:
                        path=out/f'checkpoints/fold{fold}_{kind}_outer/seed{seed}';ck=torch.load(path/f'epoch_{c["epoch"]}.pt',weights_only=False);assert np.array_equal(ck['training_indices'],tr);assert set(ck['training_subjects'])==set(g[tr[good[tr]]]);assert set(ck['training_subjects']).isdisjoint(bb) and set(ck['training_subjects']).isdisjoint(split['holdout']);parts.append(r.models.predict(latent,keys,va,state,path,c['epoch']));permuted.append(r.models.predict(latent,keys,va[per],state,path,c['epoch']));outer_reloads+=1
                    p=np.mean(parts,0);p[~good[va]]=.5;pp=np.mean(permuted,0);pp[~good[va[per]]]=.5;permutation=max(permutation,float(abs(p[per]-pp).max()))
                values[kind]=p;maximum=max(maximum,float(abs(p-cache['pure_'+kind]).max()))
            c=record['choice']
            if c['kind']=='baseline':p=baseline[va]
            else:
                pure=record['pure_choices'][c['kind']]
                if pure['epoch']==c['epoch']:q=values[c['kind']]
                else:
                    q=np.mean([r.models.predict(latent,keys,va,state,out/f'checkpoints/fold{fold}_{c["kind"]}_outer/seed{seed}',c['epoch']) for seed in r.SEEDS],0);q[~good[va]]=.5
                p=(1-c['blend'])*baseline[va]+c['blend']*q
            maximum=max(maximum,float(abs(p-cache['inner_selected_fusion']).max()))
        for j,(a,b) in enumerate(r.r.cal.r.r.base.folds(aa,n=3)):
            it=np.flatnonzero(np.isin(g,a))
            for kind in r.KINDS:
                for seed in r.SEEDS:
                    ck=torch.load(out/f'checkpoints/fold{fold}_{kind}_inner{j}/seed{seed}/epoch_15.pt',weights_only=False);assert np.array_equal(it,ck['training_indices']);assert set(ck['training_subjects'])==set(g[it[good[it]]]);assert set(ck['training_subjects']).isdisjoint(bb) and set(ck['training_subjects']).isdisjoint(b)
    assert maximum<1e-9 and permutation<1e-5,(maximum,permutation)
    r.r.save(out/'verification.json',dict(checks_passed=True,source_sets_and_choices_recomputed=True,selected_seed_outer_checkpoints_replayed=outer_reloads,max_prediction_delta=maximum,max_permutation_error=permutation,external_weight_hash=plan['weight_sha256'],source_only=True,genuine_encoder_lora=True,official_test_loaded=False,holdout_loaded=False,submissions_performed=False,not_fresh_validation=True));print('FACED ENCODER ROUND VERIFIED',out,maximum,permutation)
if __name__=='__main__':main()
