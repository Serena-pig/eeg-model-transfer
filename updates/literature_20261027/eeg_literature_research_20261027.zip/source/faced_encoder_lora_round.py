"""Actual pretrained temporal encoder LoRA with source asynchronous video crops."""
import random
from pathlib import Path
import numpy as np,torch
from torch import nn
from torch.nn import functional as F
from torch.nn.utils import parametrize
import faced_transfer_round as original
import v279_transfer_models as groups

class LowRankWeight(nn.Module):
    def __init__(self,weight,rank=8):
        super().__init__();self.A=nn.Parameter(torch.empty(rank,weight.shape[1]));self.B=nn.Parameter(torch.zeros(weight.shape[0],rank));nn.init.kaiming_uniform_(self.A,a=np.sqrt(5))
    def forward(self,weight):return weight+self.B@self.A

class Model(nn.Module):
    def __init__(self,state):
        super().__init__();self.model=original.EmotionNet();self.model.load_state_dict(state,strict=True);self.model.requires_grad_(False)
        self.model.project[0]=original.LowRankLinear(self.model.project[0],8)
        for name in ['weight_ih_l0','weight_hh_l0','weight_ih_l0_reverse','weight_hh_l0_reverse']:parametrize.register_parametrization(self.model.gru,name,LowRankWeight(getattr(self.model.gru,name),8))
        self.model.head[0]=original.LowRankLinear(self.model.head[0],8);self.model.head[4]=original.LowRankLinear(self.model.head[4],8)
    def forward(self,x):return self.model(x)

def train(sequence,y,g,good,tr,state,seed,path,maximum=15):
    random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.set_num_threads(1);rng=np.random.default_rng(seed);path=Path(path);path.mkdir(parents=True,exist_ok=True);m=Model(state);opt=torch.optim.AdamW([p for p in m.parameters() if p.requires_grad],lr=.0003,weight_decay=.03);people=np.unique(g[tr[good[tr]]]);cohorts=[people[np.char.startswith(people,'HC')],people[np.char.startswith(people,'DEP')]];rows={s:np.flatnonzero(g==s).reshape(8,5) for s in people};x=torch.from_numpy(sequence.astype('float32'));labels=torch.from_numpy(y.astype('float32'));assign=torch.from_numpy(groups.ASSIGN.astype('float32'));start=0
    files=sorted(path.glob('epoch_*.pt'),key=lambda p:int(p.stem.split('_')[1]))
    if files:
        c=torch.load(files[-1],weights_only=False);assert np.array_equal(c['training_indices'],tr) and c['seed']==seed;m.load_state_dict(c['model']);opt.load_state_dict(c['optimizer']);rng.bit_generator.state=c['numpy_rng'];torch.set_rng_state(c['torch_rng']);random.setstate(c['python_rng']);start=c['epoch']
    for epoch in range(start+1,maximum+1):
        m.train();values=[]
        for step in range(int(np.ceil(len(people)*5/10))):
            chosen=np.r_[rng.choice(cohorts[0],5,replace=False),rng.choice(cohorts[1],5,replace=False)];ix=np.stack([rows[s][np.arange(8),rng.integers(5,size=8)] for s in chosen]);index=torch.from_numpy(ix);xx=x[index]+torch.randn_like(x[index])*.03;yy=labels[index];z=m(xx);cond=(torch.logsumexp(z@assign.T,1)-(z*yy).sum(1)).mean()/4;flat=z.flatten();target=yy.flatten();pair=F.softplus(flat[target==0][None,:]-flat[target==1][:,None]).mean();loss=.5*cond+.5*F.binary_cross_entropy_with_logits(z,yy*.98+.01)+.2*pair+.002*z.square().mean();opt.zero_grad(set_to_none=True);loss.backward();nn.utils.clip_grad_norm_(m.parameters(),3.);opt.step();values.append(float(loss.detach()))
        for p in opt.param_groups:p['lr']=.00003+(.0003-.00003)*(.5+.5*np.cos(np.pi*epoch/15))
        if epoch in [5,15]:torch.save(dict(model=m.state_dict(),optimizer=opt.state_dict(),numpy_rng=rng.bit_generator.state,torch_rng=torch.get_rng_state(),python_rng=random.getstate(),epoch=epoch,training_indices=tr,training_subjects=people.tolist(),seed=seed,loss=float(np.mean(values))),path/f'epoch_{epoch}.pt')
    return path

def predict(sequence,keys,ix,state,path,epoch):
    m=Model(state);c=torch.load(path/f'epoch_{epoch}.pt',map_location='cpu',weights_only=False);m.load_state_dict(c['model']);m.eval();groups_ix=[np.flatnonzero(keys[ix]==key) for key in np.unique(keys[ix])];out=np.empty(len(ix))
    with torch.inference_mode():
        for j in range(0,len(groups_ix),8):
            rr=np.stack(groups_ix[j:j+8]);z=m(torch.from_numpy(sequence[ix[rr]].astype('float32'))).numpy();out[rr.ravel()]=z.ravel()
    return groups.posterior(out,keys[ix])
