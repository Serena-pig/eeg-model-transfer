"""Frozen external traits condition source-fitted emotion classifiers, no query diagnosis."""
import numpy as np
from scipy.optimize import minimize
from scipy.special import expit,logsumexp
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.svm import SVC
import v279_transfer_models as base

class TraitContext:
    def __init__(self,mode):self.mode=mode
    def fit(self,d,tr):
        self.training_subjects=np.unique(d['g'][tr]).tolist();self.physiology=base.Context().fit(d,tr) if self.mode=='both' else None;return self
    def predict(self,d,ix):return d['traits'][ix] if self.mode=='clinical' else np.c_[self.physiology.predict(d,ix),d['traits'][ix]]

class ClinicalLogistic(base.ContextLogistic):
    def __init__(self,mode,normalization,objective,alpha):super().__init__(normalization,objective,alpha);self.mode=mode
    def fit(self,d,tr):
        self.training_subjects=np.unique(d['g'][tr]).tolist();tr=np.asarray(tr)[np.argsort(d['keys'][tr],kind='stable')];w=base.weights(d['g'][tr]);w/=w.sum();gw=w.reshape(-1,8).sum(1);self.scaler=StandardScaler().fit(self.matrix(d,tr),sample_weight=w);x=self.scaler.transform(self.matrix(d,tr));self.context=TraitContext(self.mode).fit(d,tr);c=self.context.predict(d,tr);self.cs=StandardScaler().fit(c,sample_weight=w);c=self.cs.transform(c);xx=np.c_[x,(x[:,:,None]*c[:,None,:]).reshape(len(x),-1)];alpha=np.r_[np.full(x.shape[1],.03),np.full(xx.shape[1]-x.shape[1],self.alpha)];y=d['y'][tr].astype(float);assert np.all(y.reshape(-1,8).sum(1)==4)
        def objective(coef):
            z=xx@coef
            if self.objective=='conditional':
                zz=z.reshape(-1,8);energy=zz@base.ASSIGN.T;pp=np.exp(energy-logsumexp(energy,axis=1,keepdims=True));loss=np.dot(gw,logsumexp(energy,axis=1)-(zz*y.reshape(-1,8)).sum(1))/4;grad=((pp@base.ASSIGN-y.reshape(-1,8))*gw[:,None]/4).ravel()
            else:loss=np.dot(w,np.logaddexp(0,z)-y*z);grad=w*(expit(z)-y)
            return float(loss+.5*np.dot(alpha*coef,coef)),xx.T@grad+alpha*coef
        result=minimize(objective,np.zeros(xx.shape[1]),jac=True,method='L-BFGS-B',options=dict(maxiter=400,ftol=1e-11,gtol=1e-7));assert result.success or abs(result.jac).max()<1e-5;(setattr(self,'coef',result.x));self.optimization=dict(loss=float(result.fun),gradient_max=float(abs(result.jac).max()),iterations=int(result.nit));return self

class ClinicalKernel(base.ContextKernel):
    def __init__(self,mode,feature,beta):super().__init__(feature,beta,1.);self.mode=mode
    def fit(self,d,tr):
        self.training_subjects=np.unique(d['g'][tr]).tolist();self.context=TraitContext(self.mode).fit(d,tr);w=base.weights(d['g'][tr]);x=d[self.feature][tr];self.scaler=StandardScaler().fit(x,sample_weight=w);x=self.scaler.transform(x);self.pca=PCA(n_components=min(128,len(tr)-1,x.shape[1]),svd_solver='randomized',random_state=88031).fit(x*np.sqrt(w[:,None]));x=self.pca.transform(x);self.scale=max(np.mean(x*x),.01)**.5;self.tx=x/self.scale;c=self.context.predict(d,tr);self.cs=StandardScaler().fit(c,sample_weight=w);self.tc=self.cs.transform(c);self.model=SVC(C=1.,kernel='precomputed',cache_size=128).fit(self.kernel(self.tx,self.tc),d['y'][tr],sample_weight=w);return self

def configs():
    result=[]
    for mode in ['clinical','both']:
        for norm in ['center','z']:
            for obj in ['bce','conditional']:
                for alpha in [.3,3.]:result.append(dict(name=f'{mode}_{norm}_{obj}_{alpha}',kind='logistic',mode=mode,normalization=norm,objective=obj,alpha=alpha))
        for feature in ['de_z','spec_rank']:
            for beta in [.3,3.]:result.append(dict(name=f'{mode}_{feature}_kernel_{beta}',kind='kernel',mode=mode,feature=feature,beta=beta))
    return result
def factory(cfg):return ClinicalLogistic(cfg['mode'],cfg['normalization'],cfg['objective'],cfg['alpha']) if cfg['kind']=='logistic' else ClinicalKernel(cfg['mode'],cfg['feature'],cfg['beta'])
