"""Finite, source-inner-selected probability/logit family fusion with person bags.

No rank-model in-sample predictions are reused as meta validation. The expensive
fixed ranker is compared separately when its full5fold run is verified.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from datetime import datetime
import itertools,json,numpy as np
from scipy.special import expit,logit
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits
import run_v279_transfer as r
from run_faced_transfer_round import baseline_source

def main():
    limits=threadpool_limits(limits=1);d,split,_,rep=r.load();y=d['y'];g=d['g'];keys=d['keys'];pointers=dict(reference='CURRENT_REFERENCE_VIEWS_ROUND.txt',clinical='CURRENT_CLINICAL_CONTEXT_ROUND.txt',head='CURRENT_FACED_TRANSFER_ROUND.txt',encoder='CURRENT_FACED_ENCODER_LORA_ROUND.txt');sources={k:Path((r.ROOT/p).read_text().strip()) for k,p in pointers.items()};assert all(json.loads((p/'verification.json').read_text())['checks_passed'] for p in sources.values());parent=Path((r.ROOT/'CURRENT_V279_QUALITY_TRANSFER.txt').read_text().strip())
    with np.load(parent/'inner_selected_fusion_oof.npz') as a:baseline=a['probability'];assert np.array_equal(g,a['subjects'])
    out=r.ROOT/'runs'/('literature_family_fusion_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'));out.mkdir();(r.ROOT/'CURRENT_LITERATURE_FAMILY_FUSION.txt').write_text(str(out));grid=[tuple(a) for a in itertools.product([0.,.1,.25,.5],[0.,.1],[0.,.1],[0.,.1]) if sum(a)<=.500001];r.save(out/'plan.json',dict(primary='source_person_bagged',sources={k:v.name for k,v in sources.items()},baseline=parent.name,weights=grid,modes=['probability','logit'],minimum_source_increment=.001,bags=12,cohort_stratified_person_bootstrap=True,rank_model_excluded='Its source predictions would be in-sample for the fitted rank meta learner; no fake inner validation.',script_sha256=r.digest(__file__),holdout_not_loaded=split['holdout'],official_test_loaded=False,submissions_performed=False,not_fresh_validation=True,limitation='Source OOF candidate settings and baseline recipe themselves use source labels; selection loss optimistic; all outer persons excluded. Extensive reused development, not independent confirmation.'))
    predictions={name:np.full(len(y),np.nan) for name in ['source_selected','source_person_bagged']};records=[];reload=0.
    for fold,(aa,bb) in enumerate(r.cal.r.r.base.folds(split['development']),1):
        va=np.isin(g,bb);iy,ig,ip=baseline_source(parent,fold);columns=[];outer=[];choices={}
        for family,p in sources.items():
            rec=json.loads((p/f'fold{fold}.json').read_text());rows=rec['candidates'];pure=[z for z in rows if z['blend']==1. and z.get('kind')!='zeroshot'];c=max(pure,key=lambda v:v['score']);choices[family]=c
            if family in ['reference','clinical']:key=c['model']+('__'+c['post'] if family=='reference' else '')
            else:key=c['kind']+'__'+str(c['epoch'])
            with np.load(p/f'fold{fold}_inner.npz') as a:assert np.array_equal(ig,a['subjects']) and np.array_equal(iy,a['labels']) and np.array_equal(ip,a['baseline_probability']);columns.append(a[key])
            if family in ['reference','clinical']:
                with np.load(p/f'fold{fold}_outer.npz') as a:outer.append(a[key])
            else:
                # Pure overall source winner is among the per-kind selected heads.
                with np.load(p/f'fold{fold}_outer.npz') as a:outer.append(a['pure_'+c['kind']])
                assert c['epoch']==rec['pure_choices'][c['kind']]['epoch']
        columns=np.array(columns);outer=np.array(outer);fold_masks=[np.isin(ig,b) for _,b in r.cal.r.r.base.folds(aa,n=3)];ids,person=np.unique(ig,return_inverse=True);clinical_weight=np.where(np.char.startswith(ig,'DEP'),2.,1.)
        def mix(anchor,cols,weights,mode):
            if mode=='probability':return (1-sum(weights))*anchor+np.asarray(weights)@cols
            return expit((1-sum(weights))*logit(np.clip(anchor,1e-8,1-1e-8))+np.asarray(weights)@logit(np.clip(cols,1e-8,1-1e-8)))
        specs=[dict(weights=list(w),mode=mode) for w in grid for mode in ['probability','logit']];source=np.array([mix(ip,columns,c['weights'],c['mode']) for c in specs]);base_rows=np.where(clinical_weight>0,1.,1.)
        def best(count):
            ww=clinical_weight*count[person]
            def objective(p):return float(np.mean([roc_auc_score(iy[m],p[m],sample_weight=ww[m]) for m in fold_masks]))
            base=objective(ip);scores=[objective(p) for p in source];j=int(np.argmax(scores));return dict(**(specs[j] if scores[j]>=base+.001 else specs[0]),source_auc=float(scores[j] if scores[j]>=base+.001 else base),source_baseline_auc=base)
        rng=np.random.default_rng(20261027+fold);counts=[np.ones(len(ids))]
        for _ in range(12):
            c=np.zeros(len(ids))
            for mask in [np.char.startswith(ids,'HC'),np.char.startswith(ids,'DEP')]:
                ix=np.flatnonzero(mask);c+=np.bincount(rng.choice(ix,len(ix),replace=True),minlength=len(ids))
            counts.append(c)
        selected=[best(c) for c in counts];predictions['source_selected'][va]=mix(baseline[va],outer,selected[0]['weights'],selected[0]['mode']);predictions['source_person_bagged'][va]=np.mean([mix(baseline[va],outer,c['weights'],c['mode']) for c in selected[1:]],0);rec=dict(fold=fold,training_subjects=aa.tolist(),validation_subjects=bb.tolist(),source_pure_choices=choices,choices=selected);records.append(rec);r.save(out/f'fold{fold}.json',rec);np.savez_compressed(out/f'fold{fold}_replay.npz',validation_indices=np.flatnonzero(va),prior=baseline[va],components=outer);print('LITERATURE FAMILY FUSION',fold,selected[0],flush=True)
        with np.load(out/f'fold{fold}_replay.npz') as a:
            q=mix(a['prior'],a['components'],selected[0]['weights'],selected[0]['mode']);reload=max(reload,float(abs(q-predictions['source_selected'][a['validation_indices']]).max()));q=np.mean([mix(a['prior'],a['components'],c['weights'],c['mode']) for c in selected[1:]],0);reload=max(reload,float(abs(q-predictions['source_person_bagged'][a['validation_indices']]).max()))
    summary=dict(folds=records)
    for name,p in {**predictions,'baseline':baseline}.items():summary[name]=r.cal.r.summarize(y,p,g,keys,rep);np.savez_compressed(out/(name+'_oof.npz'),labels=y,subjects=g,group_ids=keys,representative=rep,probability=p)
    r.save(out/'summary.json',summary);r.save(out/'bootstrap.json',{name:r.boot.compare(y,p,baseline,g,rep,keys) for name,p in predictions.items()});assert reload<1e-12;r.save(out/'verification.json',dict(checks_passed=True,source_only_choices=True,source_only_bag_weights=True,max_replay_delta=reload,actual_query_diagnosis_input=False,holdout_loaded=False,official_test_loaded=False,submissions_performed=False,not_fresh_validation=True));print('LITERATURE FAMILY FUSION COMPLETE',out,flush=True)
if __name__=='__main__':main()
