"""Five-by-three same-person-split experiment; all selection source inner only."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from datetime import datetime
import json,time,numpy as np,joblib
from scipy.special import expit
from threadpoolctl import threadpool_limits
import run_v279_transfer as r
from run_faced_transfer_round import baseline_source
import reference_views_models_round as models

def main():
    limits=threadpool_limits(limits=1);d,split,_,rep=r.load();y=d['y'];g=d['g'];keys=d['keys'];feature_root=r.ROOT/'reference_views_round/development';manifest=json.loads((feature_root/'manifest.json').read_text());assert manifest['complete'];parts={}
    for s in split['development']:
        p=feature_root/(s+'.npz');assert r.digest(p)==manifest['files'][s]
        with np.load(p) as a:
            for name in a.files:parts.setdefault(name,[]).append(a[name])
    d['views']={k:r.m.group_transform(np.concatenate(v).reshape(len(y),-1),keys,'rank' if k.endswith('_spec') else 'z') for k,v in parts.items()}
    import run_group_auc as raw
    x,_,_,_=raw.load();good=np.exp(np.median(x['absolute_de']-.5*np.log(2*np.pi*np.e),axis=1))>=1e-5;parent=Path((r.ROOT/'CURRENT_V279_QUALITY_TRANSFER.txt').read_text().strip())
    with np.load(parent/'inner_selected_fusion_oof.npz') as a:baseline=a['probability'];assert np.array_equal(g,a['subjects'])
    out=r.ROOT/'runs'/('reference_views_round_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'));out.mkdir();(r.ROOT/'CURRENT_REFERENCE_VIEWS_ROUND.txt').write_text(str(out));configs=models.configs();r.save(out/'plan.json',dict(primary='inner_selected_fusion',configs=configs,postprocess=['posterior','logistic'],reference=parent.name,feature_manifest=manifest,script_sha256=r.digest(__file__),models_sha256=r.digest(r.ROOT/'reference_views_models_round.py'),source_only=True,holdout_not_loaded=split['holdout'],official_test_loaded=False,submissions_performed=False,not_fresh_validation=True,limitation='Existing source OOF baseline settings use source labels; long-term reused development. No independent confirmation.'))
    outputs={};records=[];count=np.zeros(len(y),int);maximum=0.;permerror=0.;clean={k:v for k,v in d.items() if k not in ['g','y','crop']}
    def post(z,kk,how):return r.m.posterior(z,kk) if how=='posterior' else expit(z)
    def fit(a,b,cfg,path):
        nonlocal maximum,permerror
        tr=a[good[a]];m=models.Model(cfg).fit(d,tr);joblib.dump(m,path,compress=3);z=m.predict(clean,b);z[~good[b]]=0.;loaded=joblib.load(path);q=loaded.predict(clean,b);q[~good[b]]=0.;assert set(loaded.training_subjects)==set(g[tr]) and set(g[tr]).isdisjoint(g[b]) and set(g[tr]).isdisjoint(split['holdout']);maximum=max(maximum,float(abs(z-q).max()));per=np.random.default_rng(123).permutation(len(b));q=loaded.predict(clean,b[per]);q[~good[b[per]]]=0.;permerror=max(permerror,float(abs(z[per]-q).max()));return z
    for fold,(aa,bb) in enumerate(r.cal.r.r.base.folds(split['development']),1):
        start=time.time();tr=np.flatnonzero(np.isin(g,aa));va=np.flatnonzero(np.isin(g,bb));count[va]+=1;inner=[(np.flatnonzero(np.isin(g,a)),np.flatnonzero(np.isin(g,b))) for a,b in r.cal.r.r.base.folds(aa,n=3)];ii=np.concatenate([b for _,b in inner]);iy,ig,ip=baseline_source(parent,fold);ik=keys[ii];assert np.array_equal(g[ii],ig)
        def objective(p):return float(np.mean([r.boot.evaluation(iy[np.isin(ig,b)],p[np.isin(ig,b)],ig[np.isin(ig,b)],ik[np.isin(ig,b)])['auc'] for _,b in r.cal.r.r.base.folds(aa,n=3)]))
        rows=[dict(model='baseline',post='raw',blend=0.,score=objective(ip))];source={};outer={}
        for cfg in configs:
            name=cfg['name'];zz=np.concatenate([fit(a,b,cfg,out/f'fold{fold}_inner{j}_{name}.joblib') for j,(a,b) in enumerate(inner)]);z=fit(tr,va,cfg,out/f'fold{fold}_outer_{name}.joblib')
            for how in ['posterior','logistic']:
                p=post(zz,ik,how);q=post(z,keys[va],how);p[~good[ii]]=.5;q[~good[va]]=.5;source[name+'__'+how]=p;outer[name+'__'+how]=q
                for blend in [.1,.25,.5,1.]:rows.append(dict(model=name,post=how,blend=blend,score=objective((1-blend)*ip+blend*p)))
        c=max(rows,key=lambda z:z['score']);pure=max([z for z in rows if z['blend']==1.],key=lambda z:z['score']);outer['pure_selected']=outer[pure['model']+'__'+pure['post']];outer['inner_selected_fusion']=baseline[va] if c['model']=='baseline' else (1-c['blend'])*baseline[va]+c['blend']*outer[c['model']+'__'+c['post']]
        for name,p in outer.items():
            if name not in outputs:outputs[name]=np.full(len(y),np.nan)
            outputs[name][va]=p
        record=dict(fold=fold,training_subjects=aa.tolist(),validation_subjects=bb.tolist(),choice=c,pure_choice=pure,candidates=rows);records.append(record);r.save(out/f'fold{fold}.json',record);np.savez_compressed(out/f'fold{fold}_inner.npz',labels=iy,subjects=ig,baseline_probability=ip,**source);np.savez_compressed(out/f'fold{fold}_outer.npz',validation_indices=va,**outer);print('REFERENCE VIEW FOLD',fold,c,round(time.time()-start,1),flush=True)
    assert np.all(count==1);summary=dict(folds=records)
    for name,p in {**outputs,'baseline':baseline}.items():summary[name]=r.cal.r.summarize(y,p,g,keys,rep);np.savez_compressed(out/(name+'_oof.npz'),labels=y,subjects=g,group_ids=keys,representative=rep,probability=p)
    r.save(out/'summary.json',summary);r.save(out/'bootstrap.json',{name:r.boot.compare(y,p,baseline,g,rep,keys) for name,p in outputs.items() if name in ['pure_selected','inner_selected_fusion']});assert maximum<1e-9 and permerror<1e-7;r.save(out/'verification.json',dict(checks_passed=True,all_inner_outer_models_reloaded=True,max_prediction_delta=maximum,max_permutation_error=permerror,source_sets_verified=True,holdout_loaded=False,official_test_loaded=False,submissions_performed=False,not_fresh_validation=True));print('REFERENCE VIEWS COMPLETE',out,flush=True)
if __name__=='__main__':main()
