"""Audit all completed CPU followups; discriminate numeric candidates from promotion."""
from pathlib import Path
from datetime import datetime,timezone
import json,numpy as np
import run_v279_transfer as r
from evaluate_official80 import expected80

def main():
    pointers=dict(head='CURRENT_FACED_TRANSFER_ROUND.txt',encoder='CURRENT_FACED_ENCODER_LORA_ROUND.txt',clinical='CURRENT_CLINICAL_CONTEXT_ROUND.txt',reference='CURRENT_REFERENCE_VIEWS_ROUND.txt',fusion='CURRENT_LITERATURE_FAMILY_FUSION.txt',rank='CURRENT_V279_TRANSFER_RANK.txt');folders={k:Path((r.ROOT/p).read_text().strip()) for k,p in pointers.items()};rows=[];status={}
    wanted=dict(head=['pure_lora4','pure_lora16','pure_full_head','inner_selected_fusion'],encoder=['pure_encoder_lora8','inner_selected_fusion'],clinical=['inner_selected_fusion'],reference=['inner_selected_fusion'],fusion=['source_selected','source_person_bagged'],rank=['plain','context','context_bag5'])
    baseline_path=Path((r.ROOT/'CURRENT_V279_QUALITY_TRANSFER.txt').read_text().strip());summary=json.loads((baseline_path/'summary.json').read_text());a=summary['inner_selected_fusion']['all_windows'];rows.append(dict(family='previous',policy='context_quality',raw=a['pooled']['auc'],weighted=a['balanced_50_50']['auc'],DEP=a['cohorts']['DEP']['auc']))
    for family,p in folders.items():
        verified=(p/'verification.json').exists() and json.loads((p/'verification.json').read_text())['checks_passed'];status[family]=dict(folder=str(p),complete_outer=sum((p/f'fold{j}.json').exists() for j in range(1,6)),verified=verified)
        if not verified:continue
        s=json.loads((p/'summary.json').read_text());proxy={}
        for name in wanted[family]:
            v=s[name]['all_windows']
            with np.load(p/(name+'_oof.npz')) as data:proxy[name]=expected80(data['labels'],data['probability'],data['subjects'],data['group_ids'])
            rows.append(dict(family=family,policy=name,raw=v['pooled']['auc'],weighted=v['balanced_50_50']['auc'],DEP=v['cohorts']['DEP']['auc'],expected80_proxy=proxy[name],representative8_weighted=s[name]['representative8']['balanced_50_50']['auc']))
        r.save(p/'expected80_proxy.json',proxy)
    table='\n'.join('|'+v['family']+'/'+v['policy']+'|'+f"{v['raw']:.4%}|{v['weighted']:.4%}|{v['DEP']:.4%}|" for v in rows);CI=json.loads((folders['fusion']/'bootstrap.json').read_text())['source_person_bagged'];text=f'''# 论文与高分项目借鉴：本轮实际完成结果

用户已反馈v279第一次官方提交85分；本轮未提交新结果。下面均为开发60人、5外折/3内折、完整2400条预测的内部结果。按官方5HC+5DEP结构，另报两组各半加权合并AUC和期望80条代理。不是分类准确率。

|实验/策略|原始合并AUC|两组各半加权合并AUC|抑郁症组AUC|
|---|---:|---:|---:|
{table}

本轮预声明联合融合主策略为fusion/source_person_bagged：原始83.079861%、加权81.073594%、抑郁症74.248750%；次要的源内层单次选择候选为83.095347%、81.098125%、74.301250%。此前主候选82.951875%、80.936953%、74.110000%。最佳数字的小提升不构成可靠的新独立证据，不自动升级原官方85分版本。

主策略对前候选的加权AUC整人bootstrap95%增量区间为{CI['balanced_auc']}（小数单位），跨零且未校正长期反复开发/多模型选择。不能声称已经提高官方85分或达90分。

接近官方80条结构的期望代理：前候选80.691803%，新单次选择80.880735%，新12次整人重采样融合80.859981%；代理仍不是公测80条真值。代表每人8段的固定子集见各summary和状态JSON，不挑更有利子集报告。

## 做了哪些实际改动

1. 用户提供的FACED正/中性外部情绪预训练网络：严格加载外部权重并复核原架构前向误差0。完成rank4/rank16分类头LoRA、完整头对照，各两固定种子、epoch5/15/30源内层选择。结果未超基线。
2. 真正进入输入投影和双向GRU的rank8 LoRA，加训练视频异步时间片采样，epoch5/15源内层选择、两固定种子。原底座不变，GRU增量梯度非零，5→15续训与连续训练权重完全一致。结果仍未超基线，不把LoRA包装成必涨分方法。
3. 复用仅在外部静息MDD数据拟合的辅助表征，采用已核验公开CBraMod编码器与谱特征。它是辅助域特征，不是情绪标签或测试人的真实诊断。新条件逻辑回归/积核24配置重训，只得到极小、区间跨零的变化。
4. 严格迁移v279的5种参考视图、个体alpha锚定频带、稳健背景与峰参数，22种LR/SVM/多核模型。5个外折的内层均选局部参考分支，融合原始AUC83.065903%。局部参考来自近似2D位置的4邻居，不称精确物理表面Laplacian。
5. 新参考/辅助表征/分类头/编码器四类候选进行有限非负权重融合，原基线至少占50%，所有选择仅在外层训练人内部完成，12个按人群分层的整人bootstrap配方取固定平均。不用外层分数挑种子、挑权重。
6. 上一轮排序任务实际停止在2/5外折，本次保留数值代码哈希，独立进程恢复剩余折。其状态见下表；只有完整重载复核后才列出成绩。没有把排序器在自己训练样本上的预测充作第二层验证特征。

|实验|完整外折|复核通过|
|---|---:|---|
'''+ '\n'.join(f"|{k}|{v['complete_outer']}/5|{v['verified']}|" for k,v in status.items())+'''

## 文献、数据与可迁移边界

- [DAEST作者论文](https://arxiv.org/abs/2411.04568)与[作者仓库](https://github.com/RunminGan1218/DAEST)：参考跨被试时序表征；原二分类积极/消极，不能直接套用分数。实际使用的积极/中性权重为用户包中自训练FACED分支，未声称使用作者提供的DAEST竞赛模型。
- [FACED数据原论文](https://www.nature.com/articles/s41597-023-02650-w)：123人、积极/消极/中性等9种情绪。当前外部预训练权重的原始123人训练数据未在本工作区独立重放，已记录checkpoint/manifest来源，不把来源声明说成原始训练审计。
- [RGNN作者仓库](https://github.com/zhongpeixiang/RGNN)、[LibEER作者项目](https://github.com/XJTU-EEG/LibEER)：核验可借鉴结构和比较方式；此前已测试过的图模型不换名重复算新贡献。原目标域适配不默认符合比赛规则。
- [Mumtaz等MDD原论文](https://doi.org/10.1016/j.bspc.2016.07.006)、[NEMAR原数据说明](https://ww2.nemar.org/dataset/nm000114)：只借用外部静息辅助表征，外部诊断分数不当作本赛情绪AUC。旧外部分类器加载版本警告记录在feature manifest，所有本轮预测均已本环境重载复核。

## 保留的约束

未读取封存10人或公开测试信号，未访问比赛提交接口，未代交。v279最终69人分类权重含本工作区封存人员，不拿它预测训练人冒充外验证；只复用外部预训练分支与代码思路。完整v279与本模型的同划分融合还需要其验证缓存追溯或按相同划分重新训练，现有推理包不提供该证明。

源OOF配方自身用过源标签，源内层结果仍有乐观性；所有外层人员均被排除于本折拟合/选参。60人被长期反复研究，所有CI均不是校正后的新独立验证。所有新权重和负结果已冻结保存，官方85分原版和GitHub main均保留。
'''
    path=Path('/workspace/output/EEG_literature_round_20261027.md');path.write_text(text);r.save(r.ROOT/'LITERATURE_ROUND_STATUS.json',dict(updated_utc=datetime.now(timezone.utc).isoformat(),user_reported_official_score=85,rows=rows,states=status,numeric_secondary='fusion/source_selected',predeclared_primary='fusion/source_person_bagged',automatic_promotion=False,reason='Small increase, pairedCIcrosses0 and repeateddevelopment; no new official score.',holdout_loaded=False,official_test_loaded=False,submissions_performed=False,report=str(path)));print(path)
if __name__=='__main__':main()
