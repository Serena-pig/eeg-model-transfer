"""Recover independent remaining folds, preserving immutable numerical functions.

The AST wrapper adds only an outer-fold filter and returns before aggregation.
Original __file__ and file hashes are retained; original runner aggregates once
every independent fold is complete. No partial scores are revealed.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import ast,copy,inspect,json,subprocess,sys
from concurrent.futures import ProcessPoolExecutor,as_completed
import multiprocessing
from pathlib import Path
import run_v279_transfer as r

def worker(folder,fold):
    source=Path(r.__file__).read_text();tree=ast.parse(source);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run');found=0
    for item in node.body:
        if isinstance(item,ast.For) and isinstance(item.target,ast.Tuple) and ast.unparse(item.target).startswith('(fold,'):
            item.body.insert(0,ast.If(test=ast.Compare(left=ast.Name(id='fold',ctx=ast.Load()),ops=[ast.NotEq()],comparators=[ast.Constant(fold)]),body=[ast.Continue()],orelse=[]));found+=1
    assert found==1
    cut=next(j for j,n in enumerate(node.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='names' for t in n.targets));node.body.insert(cut,ast.Return(value=ast.Constant(None)));module=ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[]));namespace=dict(r.__dict__);exec(compile(module,r.__file__,'exec'),namespace);namespace['run'](folder,'rank');return fold

def main():
    root=r.ROOT;folder=Path((root/'CURRENT_V279_TRANSFER_RANK.txt').read_text().strip());plan=json.loads((folder/'plan.json').read_text());assert plan['script_sha256']==r.digest(r.__file__) and plan['models_sha256']==r.digest(root/'v279_transfer_models.py');missing=[i for i in range(1,6) if not (folder/f'fold{i}.json').exists()]
    r.save(folder/'RECOVERY_EXECUTION.json',dict(reason='Prior execution stopped after2completeouterfolds, original process defunct; do not claim background continuation.',missing_at_start=missing,independent_processes=2,numerical_functions_unchanged=True,wrapper_sha256=r.digest(__file__),original_runner_sha256=plan['script_sha256'],original_models_sha256=plan['models_sha256']))
    with ProcessPoolExecutor(2,mp_context=multiprocessing.get_context('spawn')) as pool:
        for future in as_completed([pool.submit(worker,str(folder),i) for i in missing]):print('RECOVERED RANK FOLD',future.result(),flush=True)
    r.run(folder,'rank')
    subprocess.run([sys.executable,str(root/'review_v279_transfer.py'),str(folder)],cwd=root,check=True)
    subprocess.run([sys.executable,str(root/'report_v279_transfer.py')],cwd=root,check=True)
    print('RANK RECOVERY COMPLETE VERIFIED',folder,flush=True)
if __name__=='__main__':main()
