"""5x3 source-only comparison of true external-emotion head LoRA and controls."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from datetime import datetime
import json,time,numpy as np,torch
from threadpoolctl import threadpool_limits
import run_v279_transfer as r
import faced_transfer_round as models
from extract_faced_transfer_round import WEIGHT,PKG

KINDS=['lora4','lora16','full_head'];EPOCHS=[5,15,30];SEEDS=[42,173]

def load():
    d,split,old,rep=r.load();folder=r.ROOT/'foundation_features/faced_transfer_round/development';manifest=json.loads((folder/'manifest.json').read_text());assert manifest['complete'] and manifest['development_subjects']==split['development'];latent=[];zero=[]
    for person in split['development']:
        path=folder/(person+'.npz');assert r.digest(path)==manifest['files'][person]
        with np.load(path) as a:latent.append(a['latent']);zero.append(a['logits'])
    import run_group_auc as raw
    x,_,_,_=raw.load();good=np.exp(np.median(x['absolute_de']-.5*np.log(2*np.pi*np.e),axis=1))>=1e-5
    parent=Path((r.ROOT/'CURRENT_V279_QUALITY_TRANSFER.txt').read_text().strip());assert json.loads((parent/'verification.json').read_text())['checks_passed']
    with np.load(parent/'inner_selected_fusion_oof.npz') as a:assert np.array_equal(a['subjects'],d['g']);baseline=a['probability']
    state=torch.load(WEIGHT,map_location='cpu',weights_only=True)['state'];return d,split,np.concatenate(latent),np.concatenate(zero),good,baseline,rep,parent,state,manifest

def baseline_source(parent,fold):
    rec=json.loads((parent/f'fold{fold}.json').read_text());c=rec['choice']
    with np.load(parent/f'fold{fold}_inner.npz') as a:
        p=a['baseline_probability'] if c['model']=='baseline' else (1-c['blend'])*a['baseline_probability']+c['blend']*a[c['model']]
        return a['labels'],a['subjects'],p

def fits(latent,d,good,it,iv,state,kind,out):
    parts=[]
    for seed in SEEDS:
        path=out/f'seed{seed}';models.train(latent,d['y'],d['g'],d['keys'],good,it,state,kind,seed,path)
        pp={}
        for epoch in EPOCHS:
            pp[epoch]=models.predict(latent,d['keys'],iv,state,kind,path,epoch);pp[epoch][~good[iv]]=.5
        parts.append(pp)
    return {epoch:np.mean([a[epoch] for a in parts],axis=0) for epoch in EPOCHS}

def main(folder=None):
    limits=threadpool_limits(limits=1);torch.set_num_threads(1);torch.use_deterministic_algorithms(True);d,split,latent,zero,good,baseline,rep,parent,state,manifest=load();y=d['y'];g=d['g'];keys=d['keys'];out=Path(folder) if folder else r.ROOT/'runs'/('faced_transfer_round_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'));out.mkdir(parents=True,exist_ok=True);(r.ROOT/'CURRENT_FACED_TRANSFER_ROUND.txt').write_text(str(out))
    plan=dict(primary='inner_selected_fusion',kinds=KINDS,epochs=EPOCHS,seeds=SEEDS,adaptation='Genuine rank4/rank16 low-rank delta on frozen pretrained192->64 and64->1 emotion classifier; fullheadAdamWcontrol. Temporal encoder frozen/cacheexact. Not fullencoderLoRA.',loss='.5conditional4of8+.5labelsmoothedBCE+.2global80pairwise; balanced5HC5DEPsourceepisodes, Gaussianlatentnoise.01, lr.0007cosine->.00003wd.03',baseline=parent.name,pretraining_manifest=manifest,source_only=True,holdout_not_loaded=split['holdout'],official_test_loaded=False,submissions_performed=False,script_sha256=r.digest(__file__),models_sha256=r.digest(r.ROOT/'faced_transfer_round.py'),weight_sha256=r.digest(WEIGHT),not_fresh_validation=True,limitation='Long reused development; source OOF baseline recipe itself uses source labels. Source fitting/selection is optimistic, outer people remain excluded. Raw external pretraining corpus not independently replayed.')
    if (out/'plan.json').exists():assert json.loads((out/'plan.json').read_text())==plan
    else:r.save(out/'plan.json',plan)
    counts=np.zeros(len(y),int);records=[]
    for fold,(aa,bb) in enumerate(r.cal.r.r.base.folds(split['development']),1):
        if (out/f'fold{fold}.json').exists():records.append(json.loads((out/f'fold{fold}.json').read_text()));continue
        start=time.time();tr=np.flatnonzero(np.isin(g,aa));va=np.flatnonzero(np.isin(g,bb));inner=[(np.flatnonzero(np.isin(g,a)),np.flatnonzero(np.isin(g,b))) for a,b in r.cal.r.r.base.folds(aa,n=3)];ii=np.concatenate([b for _,b in inner]);iy,ig,ip=baseline_source(parent,fold);assert np.array_equal(y[ii],iy) and np.array_equal(g[ii],ig);ik=keys[ii]
        def objective(p):return float(np.mean([r.boot.evaluation(iy[np.isin(ig,b)],p[np.isin(ig,b)],ig[np.isin(ig,b)],ik[np.isin(ig,b)])['auc'] for _,b in r.cal.r.r.base.folds(aa,n=3)]))
        sourcep={};rows=[dict(kind='baseline',epoch=0,blend=0.,score=objective(ip))];z=r.m.posterior(zero[ii],ik);z[~good[ii]]=.5;sourcep['zeroshot__0']=z
        for blend in [.1,.25,.5,1.]:rows.append(dict(kind='zeroshot',epoch=0,blend=blend,score=objective((1-blend)*ip+blend*z)))
        for kind in KINDS:
            parts=[fits(latent,d,good,a,b,state,kind,out/f'checkpoints/fold{fold}_{kind}_inner{j}') for j,(a,b) in enumerate(inner)]
            for epoch in EPOCHS:
                p=np.concatenate([a[epoch] for a in parts]);sourcep[kind+'__'+str(epoch)]=p
                for blend in [.1,.25,.5,1.]:rows.append(dict(kind=kind,epoch=epoch,blend=blend,score=objective((1-blend)*ip+blend*p)))
            print('FACED INNER COMPLETE',fold,kind,round(time.time()-start,1),flush=True)
        pure={kind:max([v for v in rows if v['kind']==kind and v['blend']==1.],key=lambda v:v['score']) for kind in KINDS+['zeroshot']};choice=max(rows,key=lambda v:v['score']);wanted={k:set([c['epoch']]) for k,c in pure.items() if k!='zeroshot'}
        if choice['kind'] not in ['baseline','zeroshot']:wanted[choice['kind']].add(choice['epoch'])
        outs={};outputs={};z=r.m.posterior(zero[va],keys[va]);z[~good[va]]=.5;outs['zeroshot__0']=z
        for kind in wanted:
            pp=fits(latent,d,good,tr,va,state,kind,out/f'checkpoints/fold{fold}_{kind}_outer')
            for epoch,p in pp.items():outs[kind+'__'+str(epoch)]=p
        for kind,c in pure.items():outputs['pure_'+kind]=outs[kind+'__'+str(c['epoch'])]
        outputs['inner_selected_fusion']=baseline[va] if choice['kind']=='baseline' else (1-choice['blend'])*baseline[va]+choice['blend']*outs[choice['kind']+'__'+str(choice['epoch'])]
        rec=dict(fold=fold,training_subjects=aa.tolist(),validation_subjects=bb.tolist(),choice=choice,pure_choices=pure,candidates=rows);records.append(rec);np.savez_compressed(out/f'fold{fold}_inner.npz',labels=iy,subjects=ig,baseline_probability=ip,**sourcep);np.savez_compressed(out/f'fold{fold}_outer.npz',validation_indices=va,**outputs);r.save(out/f'fold{fold}.json',rec);print('FACED OUTER COMPLETE',fold,choice,round(time.time()-start,1),flush=True)
    pred={};counts=np.zeros(len(y),int)
    for fold in range(1,6):
        with np.load(out/f'fold{fold}_outer.npz') as a:
            va=a['validation_indices'];counts[va]+=1
            for name in a.files:
                if name=='validation_indices':continue
                if name not in pred:pred[name]=np.full(len(y),np.nan)
                pred[name][va]=a[name]
    assert np.all(counts==1);summary=dict(folds=records)
    for name,p in {**pred,'baseline':baseline}.items():summary[name]=r.cal.r.summarize(y,p,g,keys,rep);np.savez_compressed(out/(name+'_oof.npz'),labels=y,subjects=g,group_ids=keys,representative=rep,probability=p)
    r.save(out/'summary.json',summary);r.save(out/'bootstrap.json',{name:r.boot.compare(y,p,baseline,g,rep,keys) for name,p in pred.items()});print('FACED ROUND COMPLETE',out,flush=True)
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path);a=p.parse_args();main(a.root)
