"""Matched cached group fusion; inner selected weights apply to exactly the same
weighted prediction rule on outer subjects. Frozen84.57 is benchmark only.
No source meta in-sample CV, no proxy transfer, no base model training.
"""
import os
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import json,traceback
import numpy as np
from scipy.special import logit
from sklearn.metrics import roc_auc_score
import driver
from common import batches
from confidence_fusion_v11 import probability_bank
from inner_calibration_round import calibrate
from postflight import pair_matrix
OUT=driver.JOB/'cached_matched_members_20261030';OUT.mkdir(exist_ok=True)
NEW=['de_cnn','raw_de_cnn','raw_de_bigru']
MODES=['identity','conditional','standardized_logit']
ALPHAS=[.05,.1,.2,.35]
def measure(y,q,diag,parts):
 aucs=[roc_auc_score(y[m],q[m]) for m in parts];deps=[roc_auc_score(y[m&(diag==1)],q[m&(diag==1)]) for m in parts]
 return dict(pooled=float(roc_auc_score(y,q)),DEP=float(roc_auc_score(y[diag==1],q[diag==1])),fold_mean=float(np.mean(aucs)),fold_std=float(np.std(aucs)),DEP_folds=deps,score=float(np.mean(aucs)-.2*np.std(aucs)))
def main():
 p=driver.protocol();pool=json.loads((driver.JOB/'completed_pool/protocol.json').read_text());old=pool['member_positions'];extra=[i for i in range(104) if i not in old];positions=old+extra
 cs=[p['members'][i] for i in positions]+[dict(name=n,family='new_dualbranch',config={}) for n in NEW];baseix=np.r_[np.arange(83),np.arange(104,107)]
 families={}
 for j,c in enumerate(cs):families.setdefault(c['family'],[]).append(j)
 spec=dict(total_available_members=107,individual_and_family_candidates=True,selector='Matched weighted group ensemble, clean3inner queries',selector_proxy_mismatch=False,frozen845656_used_only_as_benchmark=True,alphas=ALPHAS,calibrations=MODES,max_greedy_steps=4,minimum_score_gain=.0005,DEP_tolerance=.001,objective='mean3pooledAUC minus.2std with DEPfloor',base_models_retrained=0,script_sha256=driver.sha(__file__),source_protocol_sha256=driver.sha(driver.CONTROL/'protocol.json'),cohort_reused=True)
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==spec
 else:driver.save(OUT/'protocol.json',spec)
 with np.load(driver.ART/'features.npz') as a:d={k:a[k] for k in ['subject','trial','crop','label','diagnosis','train']}
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:full={k:a[k] for k in a.files}
 with np.load(driver.JOB/'dualbranch_source_stack_20261028/clinical_stack_calibrated_oof.npz') as a:anchor=a['probability'];assert np.array_equal(a['labels'],full['label']) and np.array_equal(a['subjects'],full['subject'])
 mapping=full['model_row_to_full_row'];reverse={v:j for j,v in enumerate(mapping)};out=anchor.copy();selected=[];audits=[]
 for f in p['folds']:
  tr=np.flatnonzero(np.isin(d['subject'],f['training_subjects']));va=np.flatnonzero(np.isin(d['subject'],f['validation_subjects']));lookup={v:j for j,v in enumerate(tr)};inside=np.zeros((107,len(tr)));outside=np.zeros((107,len(va)));seen=np.zeros_like(inside,dtype=bool)
  for j,pos in enumerate(positions):
   m=p['members'][pos]
   for part in ['inner0','inner1','inner2','outer']:
    t=dict(fold=f['fold'],part=part,index=m['candidate_index'],name=m['name'],family=m['family'],member_position=pos);path,_=driver.paths(t)
    with np.load(path) as a:
     assert str(a['task_signature'])==driver.task_signature(t)
     if part=='outer':assert np.array_equal(a['query_indices'],va);outside[j]=a['logits']
     else:
      ix=[lookup[v] for v in a['query_indices']];inside[j,ix]=a['logits'];seen[j,ix]=True
  for j,name in enumerate(NEW,start=104):
   for part in ['inner0','inner1','inner2','outer']:
    with np.load(driver.JOB/'leaderboard_dualbranch_20261028'/f'{name}_fold{f["fold"]}_{part}.npz') as a:
     rows=a['validation'];good=np.array([int(v) in reverse for v in rows]);ix=np.array([reverse[int(v)] for v in rows[good]]);z=logit(np.clip(a['probability'][good],1e-6,1-1e-6))
     if part=='outer':assert np.array_equal(ix,va);outside[j]=z
     else:jj=[lookup[v] for v in ix];inside[j,jj]=z;seen[j,jj]=True
  assert seen.all()
  blind=dict(d);blind['label']=np.full_like(d['label'],-1);blind['diagnosis']=np.full_like(d['diagnosis'],-1)
  bank,scales=probability_bank(blind,tr,inside,cs);outerbank,_=probability_bank(blind,va,outside,cs,scales)
  proxy=bank[baseix].mean(0);groups=batches(d)[tr];parts=[np.isin(d['subject'][tr],sp['validation_subjects']) for sp in f['inner']];y=d['label'][tr];diag=d['diagnosis'][tr];reference=measure(y,proxy,diag,parts)
  proposals=[]
  for family,ix in families.items():
   ix=np.array(ix);proposals.append(('family_'+family,ix))
   removed=np.setdiff1d(baseix,ix)
   if len(removed)>=20 and len(removed)<86:proposals.append(('without_'+family,removed))
  proposals.extend([('member_'+c['name'],np.array([j])) for j,c in enumerate(cs)])
  candidates=[dict(group=name,member_indices=ix.tolist(),mode=mode) for name,ix in proposals for mode in MODES]
  ip=np.array([calibrate(bank[c['member_indices']].mean(0),groups,c['mode']) for c in candidates]);gv=batches(d)[va];op=np.array([calibrate(outerbank[c['member_indices']].mean(0),gv,c['mode']) for c in candidates])
  from scipy.stats import rankdata
  def auc_matrix(pred,yy):
   yy=np.asarray(yy,dtype=bool);rank=rankdata(pred,axis=1,method='average');n=int(yy.sum());m=len(yy)-n;return (rank[:,yy].sum(1)-n*(n+1)/2)/(n*m)
  def metrics(pred):
   allauc=auc_matrix(pred,y);da=auc_matrix(pred[:,diag==1],y[diag==1]);ff=np.array([auc_matrix(pred[:,m],y[m]) for m in parts]);return allauc,da,ff.mean(0)-.2*ff.std(0)
  aa,dd,ss=metrics(ip);eligible=dd>=reference['DEP']-.001
  if eligible.any():
   first=int(np.argmax(np.where(eligible,ss,-np.inf)));current=ip[first].copy();query=op[first].copy();weights=np.zeros(len(candidates));weights[first]=1.;current_score=float(ss[first]);current_dep=float(dd[first])
  else:current=proxy.copy();query=outerbank[baseix].mean(0);weights=np.zeros(len(candidates));first=None;current_score=reference['score'];current_dep=reference['DEP']
  steps=[]
  for step in range(4):
   mixes=np.concatenate([(1-alpha)*current[None]+alpha*ip for alpha in ALPHAS],axis=0);ma,md,ms=metrics(mixes);ok=(md>=current_dep-.001)&(ms>=current_score+.0005)
   if not ok.any():break
   best=int(np.argmax(np.where(ok,ms,-np.inf)));alpha=ALPHAS[best//len(candidates)];member=best%len(candidates);current=mixes[best].copy();query=(1-alpha)*query+alpha*op[member];weights*=1-alpha;weights[member]+=alpha;current_score=float(ms[best]);current_dep=float(md[best]);steps.append(dict(step=step+1,alpha=alpha,candidate=candidates[member],inner_score=current_score,inner_DEP_auc=current_dep))
  rec=dict(fold=f['fold'],initial_candidate=None if first is None else candidates[first],steps=steps,candidates=[dict(**c,weight=float(w)) for c,w in zip(candidates,weights) if w],initial_fallback_base86_weight=float(1-weights.sum()),final_inner_metrics=measure(y,current,diag,parts),reference_inner_metrics=reference,selection_labels_only_source_inner=True,proxy_mismatch=False)
  replay=rec['initial_fallback_base86_weight']*outerbank[baseix].mean(0)
  for c in rec['candidates']:replay+=c['weight']*calibrate(outerbank[c['member_indices']].mean(0),gv,c['mode'])
  assert np.max(abs(replay-query))<1e-12
  perm=np.random.default_rng(1030+f['fold']).permutation(len(va));order=rec['initial_fallback_base86_weight']*outerbank[baseix][:,perm].mean(0)
  for c in rec['candidates']:order+=c['weight']*calibrate(outerbank[c['member_indices']][:,perm].mean(0),np.char.add('opaque_',gv[perm]),c['mode'])
  error=float(abs(order-query[perm]).max());assert error<1e-10
  driver.save(OUT/f'fold{f["fold"]}_selection.json',rec);out[mapping[va]]=np.round(query,12);audits.append(dict(fold=f['fold'],query_metadata_permutation_delta=error,matched_inner_outer_rule=True));driver.save(OUT/'progress.json',dict(stage='screening',completed_outer_folds=f['fold'],total_outer_folds=5));print('MATCHED CACHED FUSION OUTER',f['fold'],'greedy_steps',len(steps),flush=True)
 y=full['label'];g=full['subject'];dep=full['diagnosis']==1;ids=np.unique(g);ref=pair_matrix(y,anchor,g,ids);new=pair_matrix(y,out,g,ids);rng=np.random.default_rng(1030);counts=np.zeros((2000,len(ids)))
 for j in range(len(counts)):
  for mask in [np.char.startswith(ids,'DEP'),np.char.startswith(ids,'HC')]:
   ix=np.flatnonzero(mask);counts[j]+=np.bincount(rng.choice(ix,len(ix),replace=True),minlength=len(ids))
 boot=np.einsum('bi,ij,bj->b',counts,new-ref,counts,optimize=True)/counts.sum(1)**2
 summary=dict(pooled_auc=float(roc_auc_score(y,out)),DEP_auc=float(roc_auc_score(y[dep],out[dep])),anchor_pooled_auc=float(roc_auc_score(y,anchor)),anchor_DEP_auc=float(roc_auc_score(y[dep],anchor[dep])),paired_person_delta_95CI=np.quantile(boot,[.025,.975]).tolist(),outer_model_selection_not_used=True,selector_proxy_mismatch=False,cohort_reused=True,multiple_search_uncorrected=True,base_models_retrained=0,official_score_unknown=True,baseline_promoted=False)
 np.savez_compressed(OUT/'selected_oof.npz',labels=y,subjects=g,probability=out);driver.save(OUT/'summary.json',summary);driver.save(OUT/'verification.json',dict(checks_passed=True,all5outer_complete=True,source_inner_selection_only=True,meta_in_sample_validation_not_used=True,matched_inner_outer_fusion_rule=True,no_proxy_transfer=True,audits=audits,holdout_and_official_test_not_read=True,submissions_performed=False));driver.save(OUT/'progress.json',dict(stage='complete',completed_outer_folds=5,total_outer_folds=5));print('MATCHED CACHED FUSION COMPLETE',json.dumps(summary),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException:driver.save(OUT/'failure.json',dict(traceback=traceback.format_exc()));raise
