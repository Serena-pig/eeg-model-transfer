"""Refit only lightweight fusion using group/alpha chosen by clean inner proxy.
Uses the frozen86-member clinical LR design with source-selected group priors.
No base training, no outer selection. Proxy mismatch remains explicitly declared.
"""
import os
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='1'
import json,traceback
import numpy as np,joblib
from scipy.special import logit
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits
import driver
from nonlinear_rank_v18 import features
from context_rank_v34 import fit_context,context_features
from inner_calibration_round import calibrate
from postflight import pair_matrix
OUT=driver.JOB/'cached_group_prior_20261030';OUT.mkdir(exist_ok=True)
NEW=['de_cnn','raw_de_cnn','raw_de_bigru']
def weight(diag):
 w=np.ones(len(diag))
 for v in (0,1):w[diag==v]=len(diag)/(2*np.sum(diag==v))
 return w
def main():
 threadpool_limits(limits=1);p=driver.protocol();pool=json.loads((driver.JOB/'completed_pool/protocol.json').read_text());old=pool['member_positions'];extra=[i for i in range(104) if i not in old];positions=old+extra;allcs=[p['members'][i] for i in positions]+[dict(name=n,family='new_dualbranch',config={}) for n in NEW];baseix=np.r_[np.arange(83),np.arange(104,107)]
 spec=dict(base_members=86,source_selected_extra_members=True,C_fixed=.01,group_penalty_prior='sqrt(desired_fraction/previous_fraction), other source features sqrt(1-alpha)',no_new_hyperparameter_grid=True,selector='Frozen clean-source-inner proxy group screen',selector_proxy_mismatch_remains=True,calibration='Inherited existing source-inner calibration; no new outer calibration choice',source_context_CF=True,clinical_neural_interaction_scale=.5,script_sha256=driver.sha(__file__))
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==spec
 else:driver.save(OUT/'protocol.json',spec)
 with np.load(driver.ART/'features.npz') as a:d={k:a[k] for k in ['subject','trial','crop','label','diagnosis','train','powers','quality']}
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:full={k:a[k] for k in a.files}
 with np.load(driver.JOB/'dualbranch_source_stack_20261028/clinical_stack_calibrated_oof.npz') as a:anchor=a['probability'];assert np.array_equal(a['labels'],full['label'])
 mapping=full['model_row_to_full_row'];reverse={v:j for j,v in enumerate(mapping)};out={name:anchor.copy() for name in ['group_prior','group_prior_calibrated']};audits=[]
 for f in p['folds']:
  selection=json.loads((driver.JOB/f'cached_group_screen_20261030/fold{f["fold"]}_selection.json').read_text())['chosen'];alpha=selection['alpha'];chosen=set(selection['member_indices']);allowed=list(baseix)+sorted(chosen-set(baseix)) if alpha else list(baseix);K=len(allowed);cs=[allcs[i] for i in allowed];newix=[j for j,i in enumerate(allowed) if i in (104,105,106)];tr=np.flatnonzero(np.isin(d['subject'],f['training_subjects']));va=np.flatnonzero(np.isin(d['subject'],f['validation_subjects']));lookup={v:j for j,v in enumerate(tr)};inside=np.zeros((K,len(tr)));outside=np.zeros((K,len(va)))
  for j,glob in enumerate(allowed):
   for part in ['inner0','inner1','inner2','outer']:
    if glob<104:
     pos=positions[glob];m=p['members'][pos];t=dict(fold=f['fold'],part=part,index=m['candidate_index'],name=m['name'],family=m['family'],member_position=pos);file,_=driver.paths(t)
     with np.load(file) as a:ix=a['query_indices'];z=a['logits'];assert str(a['task_signature'])==driver.task_signature(t)
    else:
     name=NEW[glob-104]
     with np.load(driver.JOB/'leaderboard_dualbranch_20261028'/f'{name}_fold{f["fold"]}_{part}.npz') as a:
      rr=a['validation'];good=np.array([int(v) in reverse for v in rr]);ix=np.array([reverse[int(v)] for v in rr[good]]);z=logit(np.clip(a['probability'][good],1e-6,1-1e-6))
    if part=='outer':assert np.array_equal(ix,va);outside[j]=z
    else:inside[j,[lookup[v] for v in ix]]=z
  source=dict(d);source['label']=np.full_like(d['label'],-1);source['diagnosis']=np.full_like(d['diagnosis'],-1);source['label'][tr]=d['label'][tr];source['diagnosis'][tr]=d['diagnosis'][tr];raw,scales=features(source,tr,inside,cs);context,e=fit_context(source,tr);scaler=StandardScaler().fit(np.column_stack([raw,e]));x=scaler.transform(np.column_stack([raw,e]));multipliers=np.ones(x.shape[1]);picked=[j for j,i in enumerate(allowed) if i in chosen]
  if alpha and picked:
   fraction=len(picked)/K;mult=np.full(K,np.sqrt(1-alpha));mult[picked]=np.sqrt((alpha+(1-alpha)*fraction)/fraction);multipliers[:K]=mult;multipliers[K:2*K]=mult
  x=x*multipliers;gx=np.column_stack([x,.5*(2*e[:,6]-1)[:,None]*x[:,newix]]);model=LogisticRegression(C=.01,max_iter=2000).fit(gx,d['label'][tr],sample_weight=weight(d['diagnosis'][tr]));artifact=dict(model=model,scaler=scaler,multipliers=multipliers,context=context,scales=scales,candidates=cs,newix=newix,selection=selection,training_subjects=f['training_subjects']);path=OUT/f'fold{f["fold"]}.joblib';joblib.dump(artifact,path,compress=3);saved=joblib.load(path);blind=dict(d);blind['label']=np.full_like(d['label'],-1);blind['diagnosis']=np.full_like(d['diagnosis'],-1)
  def predict(q,rows,z,art):
   raw,_=features(q,rows,z,art['candidates'],art['scales']);e=context_features(q,rows,art['context']);xx=art['scaler'].transform(np.column_stack([raw,e]))*art['multipliers'];xx=np.column_stack([xx,.5*(2*e[:,6]-1)[:,None]*xx[:,art['newix']]]);return art['model'].predict_proba(xx)[:,1]
  q=predict(blind,va,outside,artifact);perm=np.random.default_rng(f['fold']).permutation(len(va));blind['subject']=np.char.add('opaque_',d['subject']);blind['trial']=np.zeros_like(d['trial']);check=predict(blind,va[perm],outside[:,perm],saved);error=float(abs(check-q[perm]).max());assert error<1e-10;g=np.char.add(np.char.add(d['subject'][va],':'),d['crop'][va].astype(str));mode=json.loads((driver.JOB/f'inner_calibration_20261028/fold{f["fold"]}_selection.json').read_text())['chosen'];out['group_prior'][mapping[va]]=np.round(q,12);out['group_prior_calibrated'][mapping[va]]=np.round(calibrate(q,g,mode),12);audits.append(dict(fold=f['fold'],members=K,group=selection['group'],native_metadata_order_delta=error));print('CACHED PRIOR FUSION OUTER',f['fold'],'/5',flush=True)
 y=full['label'];g=full['subject'];dep=full['diagnosis']==1;ids=np.unique(g);ref=pair_matrix(y,anchor,g,ids);rng=np.random.default_rng(1030);counts=np.zeros((2000,len(ids)))
 for j in range(len(counts)):
  for mask in [np.char.startswith(ids,'DEP'),np.char.startswith(ids,'HC')]:
   ix=np.flatnonzero(mask);counts[j]+=np.bincount(rng.choice(ix,len(ix),replace=True),minlength=len(ids))
 results={}
 for name,q in out.items():
  delta=pair_matrix(y,q,g,ids)-ref;boot=np.einsum('bi,ij,bj->b',counts,delta,counts,optimize=True)/counts.sum(1)**2;results[name]=dict(pooled_auc=float(roc_auc_score(y,q)),DEP_auc=float(roc_auc_score(y[dep],q[dep])),paired_person_delta_95CI=np.quantile(boot,[.025,.975]).tolist());np.savez_compressed(OUT/(name+'_oof.npz'),labels=y,subjects=g,probability=q)
 driver.save(OUT/'summary.json',dict(results=results,anchor_auc=float(roc_auc_score(y,anchor)),anchor_DEP_auc=float(roc_auc_score(y[dep],anchor[dep])),base_models_retrained=0,baseline_preserved=True,proxy_mismatch_declared=True,cohort_reused=True,multiple_search_uncorrected=True,official_score_unknown=True));driver.save(OUT/'verification.json',dict(checks_passed=True,all5outer_complete=True,native_metadata_permutation_audits=audits,source_only_group_selection_and_refit=True,exact_nested_tuning_of_final_stacker=False,holdout_and_official_test_not_read=True,submissions_performed=False));print('CACHED GROUP PRIOR COMPLETE',json.dumps(results),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException:driver.save(OUT/'failure.json',dict(traceback=traceback.format_exc()));raise
