"""Source-inner group/weight/calibration screening using existing predictions only.
Important: selector anchor is UNFITTED mean86, not in-sample learned meta scores.
Final transfer to frozen84.5656 anchor has a declared proxy mismatch; it is an
exploratory outer-held-subject experiment, not exact nested CV of that stacker.
"""
import os
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import json,traceback
import numpy as np
from scipy.special import logit
from sklearn.metrics import roc_auc_score
import driver
from common import batches
from confidence_fusion_v11 import probability_bank
from inner_calibration_round import calibrate
from postflight import pair_matrix
OUT=driver.JOB/'cached_group_screen_20261030';OUT.mkdir(exist_ok=True)
NEW=['de_cnn','raw_de_cnn','raw_de_bigru']
MODES=['identity','conditional','standardized_logit']
ALPHAS=[.05,.1,.2,.35]
def measure(y,q,diag,parts):
 aucs=[roc_auc_score(y[m],q[m]) for m in parts];deps=[roc_auc_score(y[m&(diag==1)],q[m&(diag==1)]) for m in parts]
 return dict(pooled=float(roc_auc_score(y,q)),DEP=float(roc_auc_score(y[diag==1],q[diag==1])),fold_mean=float(np.mean(aucs)),fold_std=float(np.std(aucs)),DEP_folds=deps,score=float(np.mean(aucs)-.2*np.std(aucs)))
def main():
 p=driver.protocol();pool=json.loads((driver.JOB/'completed_pool/protocol.json').read_text());old=pool['member_positions'];extra=[i for i in range(104) if i not in old];positions=old+extra
 cs=[p['members'][i] for i in positions]+[dict(name=n,family='new_dualbranch',config={}) for n in NEW];baseix=np.r_[np.arange(83),np.arange(104,107)]
 families={}
 for j,c in enumerate(cs):families.setdefault(c['family'],[]).append(j)
 spec=dict(anchor_auc=.84565625,baseline_members=86,total_available_members=107,source_selection='Three clean inner held-subject predictions; no learned-meta CV on contaminated OOF features',selector_anchor='UNFITTED mean86 probabilities',final_anchor='Previously frozen84.5656 clinical_stack_calibrated',proxy_final_distribution_mismatch=True,alphas=ALPHAS,calibrations=MODES,minimum_inner_score_gain=.0005,minimum_DEP_gain=.001,minimum_improved_DEP_folds=2,group_removal_and_addition=True,final_transfer_is_exploratory=True,base_models_retrained=0,script_sha256=driver.sha(__file__),source_protocol_sha256=driver.sha(driver.CONTROL/'protocol.json'),cohort_reused=True)
 if (OUT/'protocol.json').exists():assert json.loads((OUT/'protocol.json').read_text())==spec
 else:driver.save(OUT/'protocol.json',spec)
 with np.load(driver.ART/'features.npz') as a:d={k:a[k] for k in ['subject','trial','crop','label','diagnosis','train']}
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:full={k:a[k] for k in a.files}
 with np.load(driver.JOB/'dualbranch_source_stack_20261028/clinical_stack_calibrated_oof.npz') as a:anchor=a['probability'];assert np.array_equal(a['labels'],full['label']) and np.array_equal(a['subjects'],full['subject'])
 mapping=full['model_row_to_full_row'];reverse={v:j for j,v in enumerate(mapping)};out=anchor.copy();selected=[];audits=[]
 for f in p['folds']:
  tr=np.flatnonzero(np.isin(d['subject'],f['training_subjects']));va=np.flatnonzero(np.isin(d['subject'],f['validation_subjects']));lookup={v:j for j,v in enumerate(tr)};inside=np.zeros((107,len(tr)));outside=np.zeros((107,len(va)));seen=np.zeros_like(inside,dtype=bool)
  for j,pos in enumerate(positions):
   m=p['members'][pos]
   for part in ['inner0','inner1','inner2','outer']:
    t=dict(fold=f['fold'],part=part,index=m['candidate_index'],name=m['name'],family=m['family'],member_position=pos);path,_=driver.paths(t)
    with np.load(path) as a:
     assert str(a['task_signature'])==driver.task_signature(t)
     if part=='outer':assert np.array_equal(a['query_indices'],va);outside[j]=a['logits']
     else:
      ix=[lookup[v] for v in a['query_indices']];inside[j,ix]=a['logits'];seen[j,ix]=True
  for j,name in enumerate(NEW,start=104):
   for part in ['inner0','inner1','inner2','outer']:
    with np.load(driver.JOB/'leaderboard_dualbranch_20261028'/f'{name}_fold{f["fold"]}_{part}.npz') as a:
     rows=a['validation'];good=np.array([int(v) in reverse for v in rows]);ix=np.array([reverse[int(v)] for v in rows[good]]);z=logit(np.clip(a['probability'][good],1e-6,1-1e-6))
     if part=='outer':assert np.array_equal(ix,va);outside[j]=z
     else:jj=[lookup[v] for v in ix];inside[j,jj]=z;seen[j,jj]=True
  assert seen.all()
  blind=dict(d);blind['label']=np.full_like(d['label'],-1);blind['diagnosis']=np.full_like(d['diagnosis'],-1)
  bank,scales=probability_bank(blind,tr,inside,cs);outerbank,_=probability_bank(blind,va,outside,cs,scales)
  proxy=bank[baseix].mean(0);groups=batches(d)[tr];parts=[np.isin(d['subject'][tr],sp['validation_subjects']) for sp in f['inner']];y=d['label'][tr];diag=d['diagnosis'][tr];reference=measure(y,proxy,diag,parts)
  proposals=[]
  for family,ix in families.items():
   ix=np.array(ix);proposals.append(('family_'+family,ix))
   removed=np.setdiff1d(baseix,ix)
   if len(removed)>=20 and len(removed)<86:proposals.append(('without_'+family,removed))
  rows=[];best=None
  for name,ix in proposals:
   expert=bank[ix].mean(0)
   for mode in MODES:
    q=calibrate(expert,groups,mode);expert_metrics=measure(y,q,diag,parts)
    for alpha in ALPHAS:
     blend=(1-alpha)*proxy+alpha*q;met=measure(y,blend,diag,parts);wins=int(np.sum(np.array(met['DEP_folds'])>np.array(reference['DEP_folds'])))
     eligible=met['score']>=reference['score']+.0005 and met['DEP']>=reference['DEP']+.001 and wins>=2
     rec=dict(group=name,member_indices=ix.tolist(),mode=mode,alpha=alpha,metrics=met,expert_metrics=expert_metrics,eligible=eligible,improved_DEP_folds=wins);rows.append(rec)
     if eligible and (best is None or met['score']>best['metrics']['score']):best=rec
  if best is None:best=dict(group='keep_frozen_anchor',member_indices=[],mode='identity',alpha=0.,metrics=reference)
  chosen=dict(fold=f['fold'],reference_inner_proxy=reference,chosen=best,all_choices_used_source_inner_labels_only=True,query_labels_not_used=True,proxy_mismatch_declared=True);driver.save(OUT/f'fold{f["fold"]}_selection.json',chosen);driver.save(OUT/f'fold{f["fold"]}_inner_diagnostics.json',dict(source_subjects=f['training_subjects'],trials=rows))
  rowsfull=mapping[va];alpha=best['alpha']
  if alpha:
   expert=outerbank[best['member_indices']].mean(0);g=batches(d)[va];expert=calibrate(expert,g,best['mode']);q=(1-alpha)*anchor[rowsfull]+alpha*expert
   perm=np.random.default_rng(1030+f['fold']).permutation(len(va));qq=calibrate(outerbank[best['member_indices']][:,perm].mean(0),np.char.add('opaque_',g[perm]),best['mode']);error=float(abs(qq-expert[perm]).max());assert error<1e-10
  else:q=anchor[rowsfull];error=0.
  out[rowsfull]=np.round(q,12);selected.append(chosen);audits.append(dict(fold=f['fold'],query_metadata_permutation_delta=error,source_subjects_disjoint=True));driver.save(OUT/'progress.json',dict(stage='screening',completed_outer_folds=f['fold'],total_outer_folds=5));print('CACHED GROUP OUTER',f['fold'],'chosen',best['group'],'alpha',alpha,flush=True)
 y=full['label'];g=full['subject'];dep=full['diagnosis']==1;ids=np.unique(g);ref=pair_matrix(y,anchor,g,ids);new=pair_matrix(y,out,g,ids);rng=np.random.default_rng(1030);counts=np.zeros((2000,len(ids)))
 for j in range(len(counts)):
  for mask in [np.char.startswith(ids,'DEP'),np.char.startswith(ids,'HC')]:
   ix=np.flatnonzero(mask);counts[j]+=np.bincount(rng.choice(ix,len(ix),replace=True),minlength=len(ids))
 boot=np.einsum('bi,ij,bj->b',counts,new-ref,counts,optimize=True)/counts.sum(1)**2
 summary=dict(pooled_auc=float(roc_auc_score(y,out)),DEP_auc=float(roc_auc_score(y[dep],out[dep])),anchor_pooled_auc=float(roc_auc_score(y,anchor)),anchor_DEP_auc=float(roc_auc_score(y[dep],anchor[dep])),paired_person_delta_95CI=np.quantile(boot,[.025,.975]).tolist(),outer_model_selection_not_used=True,selector_proxy_mismatch=True,cohort_reused=True,multiple_search_uncorrected=True,base_models_retrained=0,official_score_unknown=True,baseline_promoted=False)
 np.savez_compressed(OUT/'selected_oof.npz',labels=y,subjects=g,probability=out);driver.save(OUT/'summary.json',summary);driver.save(OUT/'verification.json',dict(checks_passed=True,all5outer_complete=True,source_inner_selection_only=True,meta_in_sample_validation_not_used=True,exact_nested_validation_of_final_stacker=False,proxy_mismatch_disclosed=True,audits=audits,holdout_and_official_test_not_read=True,submissions_performed=False));driver.save(OUT/'progress.json',dict(stage='complete',completed_outer_folds=5,total_outer_folds=5));print('CACHED GROUP SCREEN COMPLETE',json.dumps(summary),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException:driver.save(OUT/'failure.json',dict(traceback=traceback.format_exc()));raise
