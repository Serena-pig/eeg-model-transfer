"""Descriptive group error complementarity, never used to select outer weights."""
import os
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='1'
import ast,json
from pathlib import Path
import numpy as np
from sklearn.metrics import roc_auc_score
import cached_group_screen_20261030 as screen
import driver
OUT=driver.JOB/'cached_group_diagnostics_20261030';OUT.mkdir(exist_ok=True)
def load_all_banks():
 # Reuse the exact already-reviewed bank alignment code, not a second implementation.
 tree=ast.parse((driver.JOB/'cached_group_screen_20261030.py').read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main');loop=next(n for n in fn.body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='f');prefix=[]
 for n in loop.body:
  prefix.append(n)
  if isinstance(n,ast.Assign) and any(isinstance(t,ast.Tuple) and any(isinstance(e,ast.Name) and e.id=='outerbank' for e in t.elts) for t in n.targets):break
 # bank and outerbank occur in the same semicolon-separated line: include through outerbank assignment.
 assert any('outerbank' in ast.unparse(n) and 'probability_bank' in ast.unparse(n) for n in prefix)
 prefix.append(ast.parse("return tr,va,bank,outerbank,scales").body[0]);func=ast.FunctionDef(name='extract',args=ast.arguments(posonlyargs=[],args=[ast.arg(arg=n) for n in ['f','p','positions','cs','d','mapping','reverse']],kwonlyargs=[],kw_defaults=[],defaults=[]),body=prefix,decorator_list=[]);mod=ast.fix_missing_locations(ast.Module(body=[func],type_ignores=[]));env=screen.__dict__.copy();exec(compile(mod,'cached_bank_alignment','exec'),env)
 p=driver.protocol();pool=json.loads((driver.JOB/'completed_pool/protocol.json').read_text());old=pool['member_positions'];positions=old+[i for i in range(104) if i not in old];cs=[p['members'][i] for i in positions]+[dict(name=n,family='new_dualbranch',config={}) for n in screen.NEW]
 with np.load(driver.ART/'features.npz') as a:d={k:a[k] for k in ['subject','trial','crop','label','diagnosis','train']}
 with np.load(driver.CONTROL/'full_evaluation_rows.npz') as a:full={k:a[k] for k in a.files}
 mapping=full['model_row_to_full_row'];reverse={v:j for j,v in enumerate(mapping)};bankout=np.full((107,len(full['label'])),.5)
 for f in p['folds']:
  tr,va,inside,outside,scales=env['extract'](f,p,positions,cs,d,mapping,reverse);bankout[:,mapping[va]]=outside
  np.savez_compressed(OUT/f'fold{f["fold"]}_aligned_banks.npz',inner_indices=tr,outer_indices=va,inner_probability=inside,outer_probability=outside,source_only_scales=scales)
 return cs,bankout,full

def main():
 cs,bank,full=load_all_banks();y=full['label'];g=full['subject'];dep=full['diagnosis']==1
 with np.load(driver.JOB/'dualbranch_source_stack_20261028/clinical_stack_calibrated_oof.npz') as a:anchor=a['probability'];assert np.array_equal(a['labels'],y)
 families={}
 for j,c in enumerate(cs):families.setdefault(c['family'],[]).append(j)
 def pair_scores(q,mask):
  a=q[mask&(y==1)][:,None];b=q[mask&(y==0)][None];return (a>b).astype(float)+.5*(a==b)
 ref=pair_scores(anchor,dep);records=[]
 for name,ix in families.items():
  q=bank[ix].mean(0);score=pair_scores(q,dep);gain=float(np.maximum(score-ref,0).mean());loss=float(np.maximum(ref-score,0).mean());records.append(dict(family=name,members=[cs[i]['name'] for i in ix],pooled_auc=float(roc_auc_score(y,q)),DEP_auc=float(roc_auc_score(y[dep],q[dep])),DEP_corrected_pair_mass=gain,DEP_broken_pair_mass=loss))
 receipt=dict(descriptive_only=True,not_used_for_member_weight_or_calibration_selection=True,outer_diagnosis_used_only_for_descriptive_metrics=True,anchor_pooled_auc=float(roc_auc_score(y,anchor)),anchor_DEP_auc=float(roc_auc_score(y[dep],anchor[dep])),families=records)
 driver.save(OUT/'error_complementarity.json',receipt);print('GROUP DIAGNOSTICS',json.dumps(sorted(records,key=lambda r:r['DEP_auc'],reverse=True)[:7]),flush=True)
if __name__=='__main__':main()
